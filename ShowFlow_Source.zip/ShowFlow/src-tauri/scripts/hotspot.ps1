# ShowFlow: Windows Mobile Hotspot helper (WinRT NetworkOperatorTetheringManager).
# Usage: powershell -File hotspot.ps1 -Action status|start|stop
# ASCII only. Requires an active internet connection profile (a Windows limitation).
param([string]$Action = 'status')
$ErrorActionPreference = 'Stop'

function Out-Json($o) { Write-Output ($o | ConvertTo-Json -Compress) }

try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
      $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
  }
  $null = [Windows.Networking.Connectivity.NetworkInformation, Windows.Networking.Connectivity, ContentType = WindowsRuntime]
  $null = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager, Windows.Networking.NetworkOperators, ContentType = WindowsRuntime]

  $profile = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
  if ($null -eq $profile) {
    Out-Json @{ ok = $false; supported = $false; error = 'No internet connection profile. Windows can only create a hotspot while it has a connection to share. Use Settings > Network > Mobile hotspot, or a LAN/router instead.' }
    exit 0
  }
  $cap = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::GetTetheringCapabilityFromConnectionProfile($profile)
  if ($cap -ne 'Enabled') {
    Out-Json @{ ok = $false; supported = $false; error = "Tethering capability: $cap" }
    exit 0
  }
  $mgr = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($profile)

  switch ($Action) {
    'start' {
      if ($mgr.TetheringOperationalState -ne 'On') {
        $res = Await ($mgr.StartTetheringAsync()) ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult])
        if ($res.Status -ne 'Success') { Out-Json @{ ok = $false; supported = $true; error = "Start failed: $($res.Status) $($res.AdditionalErrorMessage)" }; exit 0 }
      }
    }
    'stop' {
      if ($mgr.TetheringOperationalState -ne 'Off') {
        $res = Await ($mgr.StopTetheringAsync()) ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult])
        if ($res.Status -ne 'Success') { Out-Json @{ ok = $false; supported = $true; error = "Stop failed: $($res.Status) $($res.AdditionalErrorMessage)" }; exit 0 }
      }
    }
  }
  $cfg = $mgr.GetCurrentAccessPointConfiguration()
  # The hotspot password is intentionally NOT returned or logged.
  Out-Json @{ ok = $true; supported = $true; state = [string]$mgr.TetheringOperationalState; ssid = [string]$cfg.Ssid; clients = [int]$mgr.ClientCount }
} catch {
  Out-Json @{ ok = $false; supported = $false; error = $_.Exception.Message }
}

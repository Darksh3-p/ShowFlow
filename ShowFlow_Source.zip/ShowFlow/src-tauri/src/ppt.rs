//! PowerPoint control through an isolated PowerShell helper process (COM automation).
//! No COM call ever runs on the UI thread; a hung helper is killed and respawned.
use std::collections::HashMap;
use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::mpsc::{self, Receiver};
use std::time::{Duration, Instant};

use serde::Serialize;
use serde_json::{json, Value};

use crate::display::Bounds;

const SCRIPT: &str = include_str!("../scripts/ppt_host.ps1");

#[derive(Debug, Clone, Serialize)]
pub struct PptStatus {
    pub running: bool,
    pub position: i64,
    pub count: i64,
    pub state: i64,
}

enum CallErr {
    /// Helper died or timed out; it must be restarted.
    Dead(String),
    /// PowerPoint reported an error for this command; helper is fine.
    Failed(String),
}

struct PptHost {
    child: Child,
    stdin: ChildStdin,
    rx: Receiver<String>,
    next_id: u64,
}

/// Escape non-ASCII characters so file paths survive the PowerShell stdin code page.
fn ascii_json(s: &str) -> String {
    let mut o = String::with_capacity(s.len());
    for c in s.chars() {
        if c.is_ascii() {
            o.push(c);
        } else {
            let mut buf = [0u16; 2];
            for u in c.encode_utf16(&mut buf).iter() {
                o.push_str(&format!("\\u{:04x}", u));
            }
        }
    }
    o
}

pub fn hide_window(cmd: &mut Command) {
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }
    #[cfg(not(windows))]
    {
        let _ = cmd;
    }
}

impl PptHost {
    fn spawn(script: &Path) -> Result<PptHost, String> {
        let mut cmd = Command::new("powershell.exe");
        cmd.args(["-NoProfile", "-NonInteractive", "-STA", "-ExecutionPolicy", "Bypass", "-File"])
            .arg(script)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null());
        hide_window(&mut cmd);
        let mut child = cmd
            .spawn()
            .map_err(|e| format!("cannot start PowerShell for the PowerPoint helper: {e}"))?;
        let stdin = child.stdin.take().ok_or("PowerPoint helper has no stdin")?;
        let stdout = child.stdout.take().ok_or("PowerPoint helper has no stdout")?;
        let (tx, rx) = mpsc::channel::<String>();
        std::thread::spawn(move || {
            let mut r = BufReader::new(stdout);
            let mut buf: Vec<u8> = Vec::new();
            loop {
                buf.clear();
                match r.read_until(b'\n', &mut buf) {
                    Ok(0) | Err(_) => break,
                    Ok(_) => {
                        let line = String::from_utf8_lossy(&buf)
                            .trim()
                            .trim_start_matches('\u{feff}')
                            .to_string();
                        if tx.send(line).is_err() {
                            break;
                        }
                    }
                }
            }
        });
        Ok(PptHost { child, stdin, rx, next_id: 0 })
    }

    fn call(&mut self, mut cmd: Value, timeout: Duration) -> Result<Value, CallErr> {
        self.next_id += 1;
        let id = self.next_id;
        cmd["id"] = json!(id);
        let line = ascii_json(&cmd.to_string());
        self.stdin
            .write_all(line.as_bytes())
            .and_then(|_| self.stdin.write_all(b"\n"))
            .and_then(|_| self.stdin.flush())
            .map_err(|e| CallErr::Dead(format!("PowerPoint helper write failed: {e}")))?;
        let deadline = Instant::now() + timeout;
        loop {
            let left = deadline.saturating_duration_since(Instant::now());
            let line = self
                .rx
                .recv_timeout(left)
                .map_err(|_| CallErr::Dead("PowerPoint helper timed out or exited".to_string()))?;
            let v: Value = match serde_json::from_str(&line) {
                Ok(v) => v,
                Err(_) => continue,
            };
            if v.get("id").and_then(|x| x.as_u64()) != Some(id) {
                continue;
            }
            if v.get("ok").and_then(|x| x.as_bool()) == Some(true) {
                return Ok(v);
            }
            let msg = v
                .get("error")
                .and_then(|x| x.as_str())
                .unwrap_or("unknown PowerPoint error")
                .to_string();
            return Err(CallErr::Failed(msg));
        }
    }

    fn kill(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

pub struct PptService {
    host: Option<PptHost>,
    script_path: PathBuf,
    thumb_dir: PathBuf,
    thumb_counter: u64,
    last_thumb: HashMap<String, PathBuf>,
}

impl PptService {
    pub fn new(data_dir: &Path) -> PptService {
        let script_path = data_dir.join("ppt_host.ps1");
        let _ = std::fs::create_dir_all(data_dir);
        let _ = std::fs::write(&script_path, SCRIPT);
        let thumb_dir = data_dir.join("thumbs");
        let _ = std::fs::create_dir_all(&thumb_dir);
        PptService {
            host: None,
            script_path,
            thumb_dir,
            thumb_counter: 0,
            last_thumb: HashMap::new(),
        }
    }

    fn call(&mut self, cmd: Value, timeout: Duration) -> Result<Value, String> {
        if self.host.is_none() {
            // Refresh the script on disk each time a helper starts (in case it was removed).
            let _ = std::fs::write(&self.script_path, SCRIPT);
            self.host = Some(PptHost::spawn(&self.script_path)?);
        }
        let res = match self.host.as_mut() {
            Some(h) => h.call(cmd, timeout),
            None => return Err("PowerPoint helper unavailable".into()),
        };
        match res {
            Ok(v) => Ok(v),
            Err(CallErr::Failed(m)) => Err(m),
            Err(CallErr::Dead(m)) => {
                if let Some(mut h) = self.host.take() {
                    h.kill();
                }
                Err(m)
            }
        }
    }

    pub fn detect(&mut self) -> Result<Value, String> {
        self.call(json!({ "cmd": "detect" }), Duration::from_secs(20))
    }

    /// Open a presentation read-only and start the slide show inside `b`. Returns slide count.
    pub fn open(&mut self, path: &str, b: &Bounds, looped: bool) -> Result<i64, String> {
        let v = self.call(
            json!({ "cmd": "open", "path": path, "x": b.x, "y": b.y, "w": b.w, "h": b.h, "loop": looped }),
            Duration::from_secs(90),
        )?;
        Ok(v.get("count").and_then(|c| c.as_i64()).unwrap_or(0))
    }

    fn status_of(v: &Value) -> PptStatus {
        PptStatus {
            running: v.get("running").and_then(|x| x.as_bool()).unwrap_or(false),
            position: v.get("position").and_then(|x| x.as_i64()).unwrap_or(0),
            count: v.get("count").and_then(|x| x.as_i64()).unwrap_or(0),
            state: v.get("state").and_then(|x| x.as_i64()).unwrap_or(0),
        }
    }

    pub fn status(&mut self) -> Result<PptStatus, String> {
        let v = self.call(json!({ "cmd": "status" }), Duration::from_secs(8))?;
        Ok(Self::status_of(&v))
    }

    pub fn simple(&mut self, name: &str) -> Result<PptStatus, String> {
        let v = self.call(json!({ "cmd": name }), Duration::from_secs(15))?;
        Ok(Self::status_of(&v))
    }

    pub fn goto(&mut self, n: i64) -> Result<PptStatus, String> {
        let v = self.call(json!({ "cmd": "goto", "n": n }), Duration::from_secs(15))?;
        Ok(Self::status_of(&v))
    }

    /// Export slide `n` as a PNG in the thumbs folder. `slot` ("cur"/"next") keeps at most one file per slot.
    pub fn thumb(&mut self, n: i64, slot: &str) -> Result<String, String> {
        self.thumb_counter += 1;
        let path = self.thumb_dir.join(format!("{}_{}.png", slot, self.thumb_counter));
        let p = path.to_string_lossy().to_string();
        self.call(json!({ "cmd": "thumb", "n": n, "path": p }), Duration::from_secs(20))?;
        if let Some(old) = self.last_thumb.insert(slot.to_string(), path) {
            let _ = std::fs::remove_file(old);
        }
        Ok(p)
    }

    /// Close only the presentation ShowFlow opened. Never touches other presentations.
    pub fn stop(&mut self) -> Result<(), String> {
        if self.host.is_none() {
            return Ok(());
        }
        self.call(json!({ "cmd": "stop" }), Duration::from_secs(20)).map(|_| ())
    }

    pub fn shutdown(&mut self) {
        if let Some(mut h) = self.host.take() {
            let _ = h.call(json!({ "cmd": "quit" }), Duration::from_secs(5));
            h.kill();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ascii_json_escapes_non_ascii() {
        let s = ascii_json("{\"path\":\"C:\\\\Pr\u{e4}sentation \u{1F600}.pptx\"}");
        assert!(s.is_ascii());
        let v: Value = serde_json::from_str(&s).unwrap();
        assert_eq!(v["path"].as_str().unwrap(), "C:\\Pr\u{e4}sentation \u{1F600}.pptx");
    }
}

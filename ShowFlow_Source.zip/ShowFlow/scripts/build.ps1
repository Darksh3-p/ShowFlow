# Build the ShowFlow installer (run from the repo root in PowerShell)
$ErrorActionPreference = 'Stop'
cargo test -p showflow-core -p showflow-sharing
npm install
npm run build
Write-Host "Installer: target\release\bundle\nsis\"

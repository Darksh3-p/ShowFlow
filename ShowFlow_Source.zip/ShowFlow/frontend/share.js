// Operator-side screen-share client. Receives the speaker's WebRTC stream (preview) inside WebView2.
// Signaling goes through the local control socket of the Rust sharing hub; media never touches Rust.
(function () {
  'use strict';

  function ShareClient(onChange) {
    this.onChange = onChange || function () {};
    this.conn = null;
    this.ws = null;
    this.pc = null;
    this.phase = 'off';      // off | waiting | connected | pending | accepted
    this.speaker = null;
    this.reconnect = null;
    this.video = document.createElement('video');
    this.video.autoplay = true;
    this.video.muted = true;   // operator preview is always silent
    this.video.playsInline = true;
    this.video.className = 'share-video';
    this.onProjectorLost = function () {};
  }

  ShareClient.prototype.setPhase = function (p) { this.phase = p; this.onChange(); };

  ShareClient.prototype.connect = function (conn) {
    this.disconnect(true);
    this.conn = conn;
    this.setPhase('waiting');
    this._open();
  };

  ShareClient.prototype._open = function () {
    var self = this;
    if (!this.conn) return;
    var ws = new WebSocket(this.conn.ws_url);
    this.ws = ws;
    ws.onopen = function () { ws.send(JSON.stringify({ type: 'hello', role: 'admin', token: self.conn.token })); };
    ws.onmessage = function (ev) { self._onMessage(JSON.parse(ev.data)); };
    ws.onclose = function () {
      if (self.conn) { self.reconnect = setTimeout(function () { self._open(); }, 2000); }
    };
    this._pingTimer && clearInterval(this._pingTimer);
    this._pingTimer = setInterval(function () { self._send({ type: 'ping' }); }, 20000);
  };

  ShareClient.prototype._send = function (o) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(o));
  };

  ShareClient.prototype.disconnect = function (silent) {
    this.conn = null;
    if (this.reconnect) { clearTimeout(this.reconnect); this.reconnect = null; }
    if (this._pingTimer) { clearInterval(this._pingTimer); this._pingTimer = null; }
    this._closePc();
    if (this.ws) { try { this.ws.close(); } catch (e) {} this.ws = null; }
    this.speaker = null;
    if (!silent) this.setPhase('off'); else this.phase = 'off';
  };

  ShareClient.prototype._closePc = function () {
    if (this.pc) { try { this.pc.close(); } catch (e) {} this.pc = null; }
    this.video.srcObject = null;
  };

  ShareClient.prototype._onMessage = function (m) {
    var self = this;
    if (m.type === 'event') {
      if (m.event === 'speaker_connected') {
        this.speaker = m.label || 'Speaker';
        if (this.phase === 'waiting') this.setPhase('connected'); else this.onChange();
      } else if (m.event === 'speaker_disconnected') {
        var was = this.phase;
        this._closePc();
        this.speaker = null;
        this.setPhase('waiting');
        if (was === 'accepted') this.onProjectorLost('The speaker disconnected.');
      }
      return;
    }
    if (m.type === 'share_request') {
      this.speaker = m.label || this.speaker || 'Speaker';
      if (this.phase !== 'accepted') this.setPhase('pending');
      return;
    }
    if (m.type === 'share_stopped') {
      var was2 = this.phase;
      this._closePc();
      this.setPhase(this.speaker ? 'connected' : 'waiting');
      if (was2 === 'accepted') this.onProjectorLost('The speaker stopped sharing.');
      return;
    }
    if (m.type === 'signal' && m.channel === 'preview') {
      this._onSignal(m.data || {});
    }
    void self;
  };

  ShareClient.prototype._onSignal = async function (d) {
    var self = this;
    try {
      if (d.kind === 'offer') {
        this._closePc();
        var pc = new RTCPeerConnection({ iceServers: [] });
        this.pc = pc;
        pc.ontrack = function (e) {
          self.video.srcObject = e.streams[0];
          self.video.play().catch(function () {});
          self.onChange();
        };
        pc.onicecandidate = function (e) {
          if (e.candidate) self._send({ type: 'signal', to: 'speaker', channel: 'preview', data: { kind: 'candidate', candidate: e.candidate } });
        };
        await pc.setRemoteDescription(d.sdp);
        var ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        this._send({ type: 'signal', to: 'speaker', channel: 'preview', data: { kind: 'answer', sdp: pc.localDescription } });
      } else if (d.kind === 'candidate' && this.pc && d.candidate) {
        await this.pc.addIceCandidate(d.candidate);
      }
    } catch (e) { console.warn('preview signal failed', e); }
  };

  /** Tell the speaker to go live on the projector (caller must have routed the output first). */
  ShareClient.prototype.accept = function () { this._send({ type: 'accept' }); this.setPhase('accepted'); };
  ShareClient.prototype.reject = function () { this._send({ type: 'reject' }); this._closePc(); this.setPhase(this.speaker ? 'connected' : 'waiting'); };
  ShareClient.prototype.stop = function () { this._send({ type: 'stop' }); this._closePc(); this.setPhase(this.speaker ? 'connected' : 'waiting'); };
  /** Projector moved on to something else but the speaker keeps previewing. */
  ShareClient.prototype.leftProjector = function () { if (this.phase === 'accepted') this.setPhase(this.pc ? 'pending' : 'connected'); };
  ShareClient.prototype.hasPreview = function () { return !!this.video.srcObject; };

  window.ShareClient = ShareClient;
})();

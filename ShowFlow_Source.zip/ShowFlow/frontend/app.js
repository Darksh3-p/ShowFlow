// ShowFlow operator UI (vanilla JS, no build step). Talks to the Rust backend via Tauri commands.
(function () {
  'use strict';
  var T = window.__TAURI__;
  var invoke = T.core.invoke;
  var convert = T.core.convertFileSrc;

  // ------------------------------------------------------------ utils
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDur(ms) {
    if (!ms || ms <= 0) return '';
    var s = Math.round(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    function p(n) { return n < 10 ? '0' + n : '' + n; }
    return p(h) + ':' + p(m) + ':' + p(x);
  }
  function fmtSecs(s) { return fmtDur(Math.round((s || 0) * 1000)) || '00:00:00'; }
  function fmtSize(b) {
    if (b > 1073741824) return (b / 1073741824).toFixed(1) + ' GB';
    if (b > 1048576) return (b / 1048576).toFixed(1) + ' MB';
    return Math.max(1, Math.round(b / 1024)) + ' KB';
  }
  function baseName(p) { return String(p || '').split(/[\\/]/).pop(); }
  function typeLabel(t) { return t === 'presentation' ? 'PPT' : t === 'video' ? 'VID' : 'IMG'; }
  function toast(msg, kind) {
    var d = document.createElement('div');
    d.className = 'toast ' + (kind || '');
    d.textContent = String(msg);
    $('#toasts').appendChild(d);
    setTimeout(function () { d.remove(); }, kind === 'err' ? 9000 : 4000);
  }
  /** invoke + toast on error. Resolves to undefined on failure, otherwise the command result (null for unit). */
  function call(cmd, args) {
    return invoke(cmd, args || {}).catch(function (e) { toast(String(e), 'err'); return undefined; });
  }
  function ask(msg, title) {
    try { return T.dialog.ask(msg, { title: title || 'ShowFlow', kind: 'warning' }); }
    catch (e) { return Promise.resolve(window.confirm(msg)); }
  }

  // ------------------------------------------------------------ state
  var S = {
    page: 'dashboard',
    folder: { root: null, files: [] },
    playlists: [], plId: null, entries: [], selItem: null,
    scope: 'playlist', filter: 'all', query: '',
    libSel: {}, libQuery: '', libFilter: 'all',
    displays: [], settings: {}, idle: {},
    out: { state: { source: 'none', playback: 'idle', item_id: null, message: null }, live_index: null, live_total: 0, playlist_id: null },
    slide: { position: 0, count: 0 }, thumbs: { current: null, next: null },
    video: { t: 0, d: 0, paused: false, muted: false, volume: 1 },
    shareInfo: null, ifaces: [], hotspot: null, pptInfo: null, diag: null,
    keys: {}, capturing: null, dragId: null
  };
  var share = new window.ShareClient(function () { renderShareCard(); renderPreview(); if (S.page === 'share') renderPage(); });
  var KEYDEFAULT = { pause: 'Space', prevSlide: 'ArrowLeft', nextSlide: 'ArrowRight', prevItem: 'Ctrl+ArrowLeft', nextItem: 'Ctrl+ArrowRight', goLive: 'Enter', black: 'b', stop: 'Escape' };
  var KEYLABEL = { pause: 'Play / Pause', prevSlide: 'Previous slide', nextSlide: 'Next slide', prevItem: 'Previous item', nextItem: 'Next item', goLive: 'Go live (selected item)', black: 'Black screen', stop: 'Stop all (asks to confirm)' };

  function loadKeys() {
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem('showflow.keys') || '{}'); } catch (e) {}
    S.keys = Object.assign({}, KEYDEFAULT, saved);
  }

  // ------------------------------------------------------------ data loading
  function loadPlaylists() {
    return call('list_playlists').then(function (r) {
      if (!r) return;
      S.playlists = r;
      if (S.plId == null || !r.some(function (p) { return p.id === S.plId; })) {
        var last = S.settings.last_playlist_id;
        S.plId = (r.some(function (p) { return p.id === last; }) ? last : (r[0] ? r[0].id : null));
      }
      renderPlaylistSelect();
      return loadEntries();
    });
  }
  function loadEntries() {
    if (S.plId == null) { S.entries = []; renderLists(); return Promise.resolve(); }
    return call('get_playlist_entries', { playlistId: S.plId }).then(function (r) {
      if (r) { S.entries = r; probeDurations(); }
      renderLists();
    });
  }
  function loadFolder() {
    return call('get_folder').then(function (r) { if (r) { S.folder = r; renderLists(); } });
  }
  function loadDisplays() {
    return call('list_displays').then(function (r) { if (r) { S.displays = r; renderOutputCard(); renderStatus(); } });
  }
  function loadSharingInfo() {
    return call('sharing_info').then(function (r) { S.shareInfo = r || null; renderSideNet(); });
  }

  // Video durations are read lazily from the media element and cached in the database.
  var probing = {};
  function probeDurations() {
    S.entries.forEach(function (e) {
      var m = e.media;
      if (m.media_type !== 'video' || m.duration_ms || !m.available || probing[m.id]) return;
      probing[m.id] = true;
      var v = document.createElement('video');
      v.preload = 'metadata';
      v.onloadedmetadata = function () {
        if (isFinite(v.duration) && v.duration > 0) {
          var ms = Math.round(v.duration * 1000);
          m.duration_ms = ms;
          call('set_media_duration', { id: m.id, durationMs: ms }).then(function () { renderPlaylistRows(); });
        }
        v.removeAttribute('src');
      };
      v.src = convert(m.path);
    });
  }

  // ------------------------------------------------------------ derived
  function liveEntry() {
    var id = S.out.state.item_id;
    if (id == null) return null;
    for (var i = 0; i < S.entries.length; i++) if (S.entries[i].item.id === id) return S.entries[i];
    return null;
  }
  function liveIndex() {
    var id = S.out.state.item_id;
    for (var i = 0; i < S.entries.length; i++) if (S.entries[i].item.id === id) return i;
    return -1;
  }
  function nextEntry() {
    var i = liveIndex();
    if (i < 0) return S.entries[0] || null;
    return S.entries[i + 1] || null;
  }
  function isPlaylistSource(src) { return src === 'powerpoint' || src === 'video' || src === 'image'; }
  function displayName() {
    var sel = S.settings.audience_display;
    var d = S.displays.filter(function (x) { return x.id === sel; })[0] || S.displays.filter(function (x) { return !x.primary; })[0];
    return d ? d : null;
  }

  // ------------------------------------------------------------ rendering: chrome
  function renderPlaylistSelect() {
    var sel = $('#playlist-select');
    sel.innerHTML = S.playlists.length ? S.playlists.map(function (p) {
      return '<option value="' + p.id + '"' + (p.id === S.plId ? ' selected' : '') + '>' + esc(p.name) + ' (' + p.item_count + ')</option>';
    }).join('') : '<option value="">No playlists yet</option>';
  }
  function renderSideNet() {
    var el = $('#side-net');
    var i = S.shareInfo;
    if (i) {
      el.innerHTML = '<div class="small mut">Speaker sharing</div><b>' + esc(i.ip) + ':' + i.port + '</b>' +
        '<div class="qr" style="width:120px;height:120px;margin:8px auto">' + i.qr_svg + '</div>' +
        '<div class="small mut" style="text-align:center">Scan to connect for screen sharing</div>';
    } else {
      el.innerHTML = '<div class="small mut">Speaker sharing</div><b>Off</b><div class="small mut" style="margin:6px 0">Let speakers show their laptop on the projector.</div>' +
        '<button class="b sm" data-action="nav" data-page="share">Set up</button>';
    }
  }
  function renderStatus() {
    var st = S.out.state, d = displayName();
    var msg = 'Ready to present', dot = 'dot';
    if (st.playback === 'error') { msg = 'Output error: ' + (st.message || 'unknown'); dot = 'dot bad'; }
    else if (st.playback === 'live') { msg = 'LIVE: ' + sourceLabel(); }
    else if (st.playback === 'paused') { msg = 'Paused: ' + sourceLabel(); dot = 'dot warn'; }
    else if (st.playback === 'completed') { msg = 'Item finished. Press Next to continue.'; dot = 'dot warn'; }
    else if (st.playback === 'loading') { msg = 'Loading...'; dot = 'dot warn'; }
    $('#st-left').innerHTML = '<span class="' + dot + '"></span> ' + esc(msg);
    $('#st-mid').textContent = d ? ('Output: ' + d.name + ' - ' + d.width + ' x ' + d.height) : 'Output: simulation window (no second display)';
    var n = new Date();
    $('#st-right').textContent = n.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + '   ' + n.toLocaleDateString();
    $('#conn-dot').className = 'dot' + (st.playback === 'error' ? ' bad' : (d ? '' : ' warn'));
    $('#conn-text').textContent = d ? 'Display connected' : 'Simulation mode';
  }
  function sourceLabel() {
    var s = S.out.state.source;
    var e = liveEntry();
    var map = { none: 'Nothing', black: 'Black screen', speaker_share: 'Speaker screen share', idle_video: 'Idle screen', idle_powerpoint: 'Idle screen', idle_image: 'Idle screen' };
    if (isPlaylistSource(s)) return e ? e.media.filename : 'playlist item';
    return map[s] || s;
  }

  // ------------------------------------------------------------ rendering: dashboard
  function entryRow(e, idx, opts) {
    var live = S.out.state.item_id === e.item.id && isPlaylistSource(S.out.state.source);
    var cls = 'pl-row' + (live ? ' live' : '') + (S.selItem === e.item.id ? ' sel' : '') + (e.media.available ? '' : ' missing');
    var dur = e.media.media_type === 'image' ? (e.item.image_duration_secs ? e.item.image_duration_secs + 's' : '') : fmtDur(e.media.duration_ms);
    return '<div class="' + cls + '" draggable="true" data-item="' + e.item.id + '" data-idx="' + idx + '" data-action="select-item">' +
      '<div class="ico ' + e.media.media_type + '">' + typeLabel(e.media.media_type) + '</div>' +
      '<div class="name" title="' + esc(e.media.path) + '">' + esc(e.media.filename) + (e.media.available ? '' : ' <span class="badge bad">missing</span>') + '</div>' +
      '<div class="dur">' + dur + '</div>' +
      '<button class="b sm" data-action="play-item" data-item="' + e.item.id + '" title="Go live with this item">&#9654;</button></div>';
  }
  function mediaRow(m) {
    return '<div class="pl-row' + (m.available ? '' : ' missing') + '" data-action="add-media" data-media="' + m.id + '" title="Add to playlist">' +
      '<div class="ico ' + m.media_type + '">' + typeLabel(m.media_type) + '</div>' +
      '<div class="name" title="' + esc(m.path) + '">' + esc(m.filename) + '</div><div class="dur">' + fmtSize(m.size_bytes) + '</div>' +
      '<button class="b sm" data-action="add-media" data-media="' + m.id + '">+</button></div>';
  }
  function matchesFilter(t) {
    return S.filter === 'all' || (S.filter === 'presentations' && t === 'presentation') || (S.filter === 'videos' && t === 'video') || (S.filter === 'images' && t === 'image');
  }
  function filteredEntries() {
    var toks = S.query.toLowerCase().split(/\s+/).filter(Boolean);
    return S.entries.map(function (e, i) { return { e: e, i: i }; }).filter(function (x) {
      var n = x.e.media.filename.toLowerCase();
      return matchesFilter(x.e.media.media_type) && toks.every(function (t) { return n.indexOf(t) >= 0; });
    });
  }
  function filteredMedia(q, f) {
    var toks = q.toLowerCase().split(/\s+/).filter(Boolean);
    return S.folder.files.filter(function (m) {
      var n = m.filename.toLowerCase();
      var okType = f === 'all' || (f === 'presentations' && m.media_type === 'presentation') || (f === 'videos' && m.media_type === 'video') || (f === 'images' && m.media_type === 'image');
      return okType && toks.every(function (t) { return n.indexOf(t) >= 0; });
    });
  }
  function counts(list, getType) {
    var c = { all: list.length, presentations: 0, videos: 0, images: 0 };
    list.forEach(function (x) { var t = getType(x); if (t === 'presentation') c.presentations++; else if (t === 'video') c.videos++; else c.images++; });
    return c;
  }

  function renderDashboard() {
    $('#view').innerHTML =
      '<div class="dash">' +
      '<section class="card c-preview"><h3><span id="pv-title">Live Output Preview</span></h3><div class="preview-stage" id="preview"></div><div class="ctx" id="ctx"></div></section>' +
      '<section class="card c-playlist" id="pl-card"></section>' +
      '<section class="card c-next" id="next-card"></section>' +
      '<section class="c-transport"><div class="transport">' +
        '<button class="b big" data-action="prev-item">&#9198;<br>Previous</button>' +
        '<button class="b big" data-action="black">&#9790;<br>Black Screen</button>' +
        '<button class="b big pri" data-action="go-live">&#9654;<br>Go Live</button>' +
        '<button class="b big" data-action="next-item" id="btn-next">&#9197;<br>Next</button></div></section>' +
      '<section class="card c-quick"><h3>Quick Actions</h3><div class="quick">' +
        '<button class="b" data-action="idle">Idle Screen</button><button class="b" data-action="black">Black Screen</button>' +
        '<button class="b" data-action="toggle-pause" id="btn-pause">Pause</button><button class="b bad" data-action="stop-all">Stop All</button></div></section>' +
      '<section class="card c-share" id="share-card"></section>' +
      '<section class="card c-idle" id="idle-card"></section>' +
      '<section class="card c-output" id="out-card"></section>' +
      '<section class="card c-net" id="net-card"></section></div>';
    renderLists(); renderPreview(); renderShareCard(); renderIdleCard(); renderOutputCard(); renderNetCard();
  }

  function renderLists() { renderPlaylistPanel(); renderNextCard(); if (S.page === 'playlists') renderPage(); if (S.page === 'library') renderPage(); }

  function renderPlaylistPanel() {
    var el = $('#pl-card'); if (!el) return;
    var inPl = S.scope === 'playlist';
    var list = inPl ? S.entries.map(function (e) { return e.media; }) : S.folder.files;
    var c = counts(list, function (m) { return m.media_type; });
    var tabs = [['all', 'All'], ['presentations', 'Presentations'], ['videos', 'Videos'], ['images', 'Images']].map(function (t) {
      return '<button class="' + (S.filter === t[0] ? 'active' : '') + '" data-action="filter" data-filter="' + t[0] + '">' + t[1] + ' (' + c[t[0]] + ')</button>';
    }).join('');
    el.innerHTML =
      '<h3>Playlist <span class="grow"></span><span class="small mut">' + (inPl ? S.entries.length + ' items' : esc(baseName(S.folder.root || '') || 'no folder')) + '</span></h3>' +
      '<div class="pl-tabs"><button class="' + (inPl ? 'active' : '') + '" data-action="scope" data-scope="playlist">In playlist</button>' +
      '<button class="' + (!inPl ? 'active' : '') + '" data-action="scope" data-scope="folder">Folder: ' + esc(baseName(S.folder.root || '') || 'none') + '</button></div>' +
      '<input type="search" id="pl-search" placeholder="Search files..." value="' + esc(S.query) + '">' +
      '<div class="pl-tabs">' + tabs + '</div><div class="pl-list" id="pl-rows"></div>' +
      '<div class="row wrap">' +
      (inPl ? '<button class="b sm" data-action="choose-folder">+ Add</button><button class="b sm" data-action="remove-sel">Remove</button><button class="b sm" data-action="clear-playlist">Clear</button><button class="b sm" data-action="move-up">&uarr;</button><button class="b sm" data-action="move-down">&darr;</button>'
            : '<button class="b sm" data-action="choose-folder">Change folder</button><button class="b sm pri" data-action="add-all-filtered">Add all shown</button>') +
      '</div>';
    renderPlaylistRows();
  }
  function renderPlaylistRows() {
    var el = $('#pl-rows'); if (!el) return;
    if (S.scope === 'playlist') {
      var rows = filteredEntries();
      el.innerHTML = rows.length ? rows.map(function (x) { return entryRow(x.e, x.i); }).join('') :
        '<div class="mut small" style="padding:10px">' + (S.entries.length ? 'No matches.' : 'This playlist is empty. Switch to "Folder" to add files, or use Add.') + '</div>';
    } else {
      var f = filteredMedia(S.query, S.filter);
      el.innerHTML = f.length ? f.map(mediaRow).join('') : '<div class="mut small" style="padding:10px">' + (S.folder.root ? 'No matching files in this folder.' : 'Choose a folder first.') + '</div>';
    }
  }
  function renderNextCard() {
    var el = $('#next-card'); if (!el) return;
    var n = nextEntry();
    el.innerHTML = '<h3>Next Item</h3>' + (n ? '<div class="row"><div class="ico pl-row ' + n.media.media_type + '" style="width:44px;height:44px;padding:0;display:grid;place-items:center">' + typeLabel(n.media.media_type) + '</div><div><b>' + esc(n.media.filename) + '</b><div class="small mut">' + (fmtDur(n.media.duration_ms) || n.media.media_type) + '</div></div></div>' : '<div class="mut">End of playlist</div>');
  }
  function renderIdleCard() {
    var el = $('#idle-card'); if (!el) return;
    var i = S.idle, mode = { none: 'Black', power_point: 'PowerPoint', video: 'Video loop', image: 'Image' }[i.mode] || i.mode;
    var configured = i.mode && i.mode !== 'none';
    el.innerHTML = '<h3>Idle Screen <span class="badge ' + (configured ? '' : 'off') + '">' + (configured ? 'Configured' : 'Not set') + '</span></h3>' +
      '<div class="small">Mode: ' + esc(mode) + '</div><div class="small mut">' + (i.path ? esc(baseName(i.path)) : 'Shows black when idle') + '</div>' +
      '<div class="small mut">' + (i.auto_after_minutes ? 'Auto after ' + i.auto_after_minutes + ' min' : 'Manual only') + '</div>' +
      '<div class="row" style="margin-top:8px"><button class="b sm" data-action="nav" data-page="idle">Edit</button><button class="b sm" data-action="idle">Show now</button></div>';
  }
  function renderOutputCard() {
    var el = $('#out-card'); if (!el) return;
    var cur = displayName();
    el.innerHTML = '<h3>Output Control <span class="badge ' + (cur ? '' : 'warn') + '">' + (cur ? 'Connected' : 'Simulation') + '</span></h3>' +
      (S.displays.length ? S.displays.map(function (d) {
        var on = cur && cur.id === d.id;
        return '<label class="row small" style="margin:3px 0"><input type="radio" name="disp" data-action="pick-display" data-id="' + esc(d.id) + '"' + (on ? ' checked' : '') + '> ' + esc(d.name) + (d.primary ? ' (operator)' : '') + '</label>';
      }).join('') : '<div class="mut small">No displays found.</div>') +
      '<button class="b sm" style="margin-top:6px" data-action="nav" data-page="displays">Manage</button>';
  }
  function renderNetCard() {
    var el = $('#net-card'); if (!el) return;
    var st = share.phase;
    el.innerHTML = '<h3>Network &amp; Devices</h3>' +
      '<div class="small">Connected devices: <b>' + (share.speaker ? 1 : 0) + '</b></div>' +
      (share.speaker ? '<div class="row small"><span class="dot"></span> ' + esc(share.speaker) + '</div>' : '<div class="mut small">' + (st === 'off' ? 'Speaker sharing is off.' : 'Waiting for a speaker...') + '</div>');
  }
  function renderShareCard() {
    renderNetCard();
    var el = $('#share-card'); if (!el) return;
    var ph = share.phase, who = esc(share.speaker || 'Speaker');
    var badge = { off: ['Off', 'off'], waiting: ['Waiting', 'warn'], connected: ['Connected', ''], pending: ['Request', 'warn'], accepted: ['Active', ''] }[ph];
    var body = '';
    if (ph === 'off') body = '<div class="small mut">Not running.</div><button class="b sm" data-action="nav" data-page="share">Set up</button>';
    else if (ph === 'waiting') body = '<div class="small mut">Waiting for a speaker to connect.</div>';
    else if (ph === 'connected') body = '<div class="small">Speaker: <b>' + who + '</b></div><div class="small mut">Connected, not sharing yet.</div>';
    else if (ph === 'pending') body = '<div class="small"><b>' + who + '</b> wants to share</div><div class="row" style="margin-top:6px"><button class="b sm" data-action="nav" data-page="share">Preview</button><button class="b sm pri" data-action="share-accept">Accept &amp; Show</button></div>';
    else body = '<div class="small">Speaker: <b>' + who + '</b></div><div class="row" style="margin-top:6px"><button class="b sm bad" data-action="share-stop">Stop Sharing</button><button class="b sm" data-action="nav" data-page="share">Preview</button></div>';
    el.innerHTML = '<h3>Screen Share <span class="badge ' + badge[1] + '">' + badge[0] + '</span></h3>' + body;
  }

  // ------------------------------------------------------------ rendering: live preview
  var pv = { key: null, video: null };
  function renderPreview() {
    var stage = $('#preview'); if (!stage) return;
    var st = S.out.state, src = st.source, e = liveEntry();
    var label = { none: 'No output', black: 'Black screen', speaker_share: 'Speaker share' }[src] || sourceLabel();
    var dot = st.playback === 'live' ? 'dot' : (st.playback === 'error' ? 'dot bad' : st.playback === 'idle' ? 'dot off' : 'dot warn');
    var d = displayName();
    var key = src + '|' + (st.item_id || '') + '|' + (S.idle.path || '') + '|' + share.phase + '|' + share.hasPreview();
    var chip = '<div class="chip"><span class="' + dot + '"></span>' + esc(st.playback === 'live' ? 'LIVE' : st.playback.toUpperCase()) + '</div><div class="chip2">' + esc(d ? d.name : 'Simulation') + '</div>';

    if (pv.key !== key) {
      pv.key = key; pv.video = null;
      stage.innerHTML = '';
      var body = null;
      if (src === 'none') { body = document.createElement('div'); body.className = 'mut'; body.textContent = 'Nothing on the output. Pick an item and press Go Live.'; }
      else if (src === 'black') { body = document.createElement('div'); body.style.cssText = 'width:100%;height:100%;background:#000'; }
      else if (src === 'speaker_share') {
        if (share.hasPreview()) { body = share.video; } else { body = document.createElement('div'); body.className = 'mut'; body.textContent = 'Speaker share is on the projector (preview unavailable).'; }
      }
      else if (src === 'powerpoint' || src === 'idle_powerpoint') { body = document.createElement('img'); body.id = 'pv-img'; if (S.thumbs.current) body.src = convert(S.thumbs.current); }
      else if (src === 'video' || src === 'idle_video') {
        var path = src === 'video' ? (e && e.media.path) : S.idle.path;
        body = document.createElement('video'); body.muted = true; body.playsInline = true; pv.video = body; if (path) body.src = convert(path);
      } else if (src === 'image' || src === 'idle_image') {
        var ip = src === 'image' ? (e && e.media.path) : S.idle.path; body = document.createElement('img'); if (ip) body.src = convert(ip);
      }
      if (body) stage.appendChild(body);
      var holder = document.createElement('div'); holder.id = 'pv-chips'; stage.appendChild(holder);
    }
    var chips = $('#pv-chips'); if (chips) chips.innerHTML = chip;
    var img = $('#pv-img'); if (img && S.thumbs.current) img.src = convert(S.thumbs.current);
    if (pv.video) { syncPreviewVideo(); }
    $('#pv-title').textContent = 'Live Output Preview' + (st.playback === 'error' && st.message ? ' - ' + st.message : '');
    renderCtx();
  }
  function syncPreviewVideo() {
    var v = pv.video; if (!v) return;
    if (Math.abs(v.currentTime - S.video.t) > 1.2) { try { v.currentTime = S.video.t; } catch (e) {} }
    if (S.video.paused) v.pause(); else v.play().catch(function () {});
  }
  function renderCtx() {
    var el = $('#ctx'); if (!el) return;
    var src = S.out.state.source, st = S.out.state.playback;
    var html = '';
    if (src === 'powerpoint' || src === 'idle_powerpoint') {
      html = '<button class="b sm" data-action="slide" data-do="first">|&lt;</button><button class="b sm" data-action="slide" data-do="prev">&#9664; Slide</button>' +
        '<b id="slide-pos">Slide ' + S.slide.position + ' / ' + S.slide.count + '</b>' +
        '<button class="b sm pri" data-action="slide" data-do="next">Slide &#9654;</button><button class="b sm" data-action="slide" data-do="last">&gt;|</button>';
    } else if (src === 'video' || src === 'idle_video') {
      html = '<button class="b sm" data-action="toggle-pause">' + (st === 'paused' || S.video.paused ? '&#9654; Play' : '&#10074;&#10074; Pause') + '</button>' +
        '<button class="b sm" data-action="vid-restart">&#8634;</button>' +
        '<span class="small mut" id="vid-time">' + fmtSecs(S.video.t) + ' / ' + fmtSecs(S.video.d) + '</span>' +
        '<input type="range" id="vid-seek" min="0" max="' + Math.max(1, Math.round(S.video.d)) + '" value="' + Math.round(S.video.t) + '" class="grow">' +
        '<button class="b sm" data-action="vid-mute">' + (S.video.muted ? 'Unmute' : 'Mute') + '</button>' +
        '<input type="range" id="vid-vol" min="0" max="100" value="' + Math.round(S.video.volume * 100) + '" style="width:90px">';
    } else if (st === 'completed') {
      html = '<span class="small mut">Finished. Press Next to continue.</span>';
    } else if (isShareBackable()) {
      html = '<button class="b sm" data-action="return-playlist">Return to playlist</button>';
    }
    // do not rebuild the range inputs while the operator drags them
    if (document.activeElement && (document.activeElement.id === 'vid-seek' || document.activeElement.id === 'vid-vol')) return;
    el.innerHTML = html;
  }
  function isShareBackable() {
    var s = S.out.state.source;
    return (s === 'black' || s === 'speaker_share' || s === 'idle_video' || s === 'idle_image' || s === 'idle_powerpoint') && S.out.live_total > 0;
  }
  function updateVideoProgress() {
    var t = $('#vid-time'); if (t) t.textContent = fmtSecs(S.video.t) + ' / ' + fmtSecs(S.video.d);
    var sk = $('#vid-seek');
    if (sk && document.activeElement !== sk) { sk.max = Math.max(1, Math.round(S.video.d)); sk.value = Math.round(S.video.t); }
    syncPreviewVideo();
  }
  var thumbTimer = null;
  function refreshThumbs() {
    clearTimeout(thumbTimer);
    thumbTimer = setTimeout(function () {
      var s = S.out.state.source;
      if (s !== 'powerpoint' && s !== 'idle_powerpoint') return;
      call('ppt_thumbs').then(function (r) {
        if (!r) return;
        S.thumbs = { current: r.current, next: r.next };
        S.slide = { position: r.position, count: r.count };
        var img = $('#pv-img'); if (img && r.current) img.src = convert(r.current);
        var sp = $('#slide-pos'); if (sp) sp.textContent = 'Slide ' + r.position + ' / ' + r.count;
      });
    }, 150);
  }

  // ------------------------------------------------------------ rendering: other pages
  function shell(title, inner) { return '<h2 class="page-title">' + esc(title) + '</h2>' + inner; }

  function pagePlaylists() {
    var left = '<div class="card"><h3>Playlists</h3><div class="row wrap" style="margin-bottom:8px">' +
      '<button class="b sm pri" data-action="pl-new">New</button><button class="b sm" data-action="pl-rename">Rename</button>' +
      '<button class="b sm" data-action="pl-dup">Duplicate</button><button class="b sm bad" data-action="pl-del">Delete</button></div>' +
      '<div class="pl-list">' + (S.playlists.length ? S.playlists.map(function (p) {
        return '<div class="pl-row' + (p.id === S.plId ? ' sel' : '') + '" data-action="pl-select" data-id="' + p.id + '"><div class="name">' + esc(p.name) + '</div><div class="dur">' + p.item_count + ' items</div></div>';
      }).join('') : '<div class="mut small">No playlists yet. Click New.</div>') + '</div></div>';
    var right;
    if (S.plId == null) right = '<div class="card mut">Create a playlist to start.</div>';
    else right = '<div class="card"><h3>Items <span class="grow"></span><button class="b sm" data-action="choose-folder">+ Add files from folder</button></h3>' +
      (S.entries.length ? '<table class="table"><tr><th>#</th><th>File</th><th>Auto-advance</th><th>Loop</th><th>Volume</th><th>Start (s)</th><th>Image (s)</th><th></th></tr>' +
        S.entries.map(function (e, i) {
          var vid = e.media.media_type === 'video', img = e.media.media_type === 'image';
          return '<tr class="pl-row-t" draggable="true" data-item="' + e.item.id + '" data-idx="' + i + '">' +
            '<td>' + (i + 1) + '</td><td>' + esc(e.media.filename) + (e.media.available ? '' : ' <span class="badge bad">missing</span>') + '<div class="small mut">' + typeLabel(e.media.media_type) + ' ' + fmtDur(e.media.duration_ms) + '</div></td>' +
            '<td><input type="checkbox" data-f="auto_advance"' + (e.item.auto_advance ? ' checked' : '') + '></td>' +
            '<td>' + (vid ? '<input type="checkbox" data-f="looped"' + (e.item.looped ? ' checked' : '') + '>' : '') + '</td>' +
            '<td>' + (vid ? '<input type="range" data-f="volume" min="0" max="100" value="' + Math.round(e.item.volume * 100) + '" style="width:90px">' : '') + '</td>' +
            '<td>' + (vid ? '<input type="number" data-f="start_s" min="0" step="1" style="width:70px" value="' + (e.item.start_position_ms ? e.item.start_position_ms / 1000 : '') + '">' : '') + '</td>' +
            '<td>' + (img ? '<input type="number" data-f="image_secs" min="1" step="1" style="width:70px" placeholder="' + (S.settings.default_image_secs || 10) + '" value="' + (e.item.image_duration_secs || '') + '">' : '') + '</td>' +
            '<td class="row">' + (e.media.available ? '' : '<button class="b sm" data-action="relink" data-media="' + e.media.id + '">Relink</button>') +
            '<button class="b sm" data-action="item-up" data-item="' + e.item.id + '">&uarr;</button><button class="b sm" data-action="item-down" data-item="' + e.item.id + '">&darr;</button>' +
            '<button class="b sm" data-action="item-dup" data-item="' + e.item.id + '">Copy</button><button class="b sm bad" data-action="item-del" data-item="' + e.item.id + '">&times;</button></td></tr>';
        }).join('') + '</table><div class="small mut" style="margin-top:8px">Tip: drag rows to reorder. Per-item auto-advance overrides the global "end of item" setting.</div>'
        : '<div class="mut">Empty. Use "Add files from folder" or the Media Library.</div>') + '</div>';
    return shell('Playlist Manager', '<div class="grid2" style="grid-template-columns:320px 1fr">' + left + right + '</div>');
  }

  function pageLibrary() {
    var list = filteredMedia(S.libQuery, S.libFilter);
    var selCount = Object.keys(S.libSel).length;
    var bar = '<div class="card row wrap" style="margin-bottom:12px"><b>Folder:</b> <span class="mut">' + esc(S.folder.root || 'none selected') + '</span><span class="grow"></span>' +
      '<button class="b" data-action="choose-folder">Choose folder</button><button class="b" data-action="rescan"' + (S.folder.root ? '' : ' disabled') + '>Rescan</button></div>' +
      '<div class="row wrap" style="margin-bottom:12px"><input type="search" id="lib-search" placeholder="Search files..." value="' + esc(S.libQuery) + '" style="min-width:280px">' +
      '<select id="lib-filter">' + [['all', 'All types'], ['presentations', 'Presentations'], ['videos', 'Videos'], ['images', 'Images']].map(function (o) { return '<option value="' + o[0] + '"' + (S.libFilter === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>' +
      '<span class="mut">' + list.length + ' of ' + S.folder.files.length + ' files</span><span class="grow"></span>' +
      '<button class="b" data-action="lib-select-all">Select shown</button><button class="b" data-action="lib-clear">Clear</button>' +
      '<button class="b pri" data-action="lib-add"' + (selCount && S.plId != null ? '' : ' disabled') + '>Add ' + selCount + ' to playlist</button></div>';
    var grid = list.length ? '<div class="media-grid" id="lib-grid">' + list.map(libCard).join('') + '</div>' : '<div class="card mut">' + (S.folder.root ? 'No files match.' : 'Choose a folder with presentations, videos and images.') + '</div>';
    return shell('Media Library', bar + grid);
  }
  function libCard(m) {
    var thumb = m.media_type === 'image' && m.available ? '<img loading="lazy" src="' + convert(m.path) + '">' :
      (m.media_type === 'video' && m.available ? '<video preload="metadata" muted src="' + convert(m.path) + '#t=0.5"></video>' : '<div class="ico ' + m.media_type + '" style="width:60px;height:40px;display:grid;place-items:center;border-radius:8px;font-weight:700">' + typeLabel(m.media_type) + '</div>');
    return '<div class="media-card' + (S.libSel[m.id] ? ' sel' : '') + (m.available ? '' : ' missing') + '" data-action="lib-toggle" data-media="' + m.id + '"><div class="thumb">' + thumb + '</div>' +
      '<div class="name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + esc(m.path) + '">' + esc(m.filename) + '</div><div class="small mut">' + typeLabel(m.media_type) + ' &bull; ' + fmtSize(m.size_bytes) + '</div></div>';
  }

  function pageShare() {
    var i = S.shareInfo, ifaceOpts = S.ifaces.map(function (n) {
      return '<option value="' + esc(n.ip) + '"' + (S.ifaceSel === n.ip ? ' selected' : '') + '>' + esc(n.ip) + ' - ' + esc(n.name) + ' (' + esc(n.kind) + ')</option>';
    }).join('');
    var setup = '<div class="card"><h3>1. Network</h3>' +
      '<div class="small mut" style="margin-bottom:6px">Pick the adapter speakers will join. Use the ShowFlow/Windows hotspot, or a shared router/LAN. Internet is not required.</div>' +
      '<div class="row"><select id="iface" class="grow">' + (ifaceOpts || '<option value="">No private network found</option>') + '</select><button class="b sm" data-action="refresh-ifaces">Refresh</button></div>' +
      '<div class="row" style="margin-top:10px">' + (i ? '<button class="b bad" data-action="sharing-stop">Stop speaker sharing</button>' : '<button class="b pri" data-action="sharing-start"' + (S.ifaces.length ? '' : ' disabled') + '>Start speaker sharing</button>') + '</div>' +
      '<h3 style="margin-top:14px">Windows Mobile Hotspot</h3><div class="row wrap"><button class="b sm" data-action="hs" data-do="status">Check</button><button class="b sm" data-action="hs" data-do="start">Start</button><button class="b sm" data-action="hs" data-do="stop">Stop</button><button class="b sm" data-action="hs-settings">Open Windows settings</button></div>' +
      '<div class="small mut" id="hs-out" style="margin-top:6px">' + (S.hotspot ? esc(S.hotspot) : '') + '</div>' +
      '<div class="small mut" style="margin-top:8px">If speakers cannot connect, allow the port in Windows Firewall (private networks): <button class="b sm" data-action="fw-add">Add firewall rule (admin prompt)</button></div></div>';
    var conn = '<div class="card"><h3>2. Speaker connection</h3>' + (i ?
      '<div class="row" style="align-items:flex-start;gap:16px"><div class="qr">' + i.qr_svg + '</div><div class="grow">' +
      '<div class="small mut">Scan the QR code, or open</div><div><b>' + esc(i.base_url) + '</b></div>' +
      '<div class="small mut" style="margin-top:8px">Pairing code</div><div class="code">' + esc(i.code) + '</div>' +
      '<div class="row wrap" style="margin-top:8px"><button class="b sm" data-action="new-code">New code</button><button class="b sm" data-action="copy-url">Copy link</button></div></div></div>' +
      '<div class="small mut" style="margin-top:10px">First visit shows a browser certificate warning (self-signed, LAN only). Choose Advanced &rarr; Continue. The warning is expected; no certificate is installed on the speaker laptop. The certificate can be downloaded at <span class="kbd">' + esc(i.cert_url) + '</span>.</div>'
      : '<div class="mut">Start speaker sharing to get a QR code and pairing code.</div>') + '</div>';
    var ph = share.phase, who = esc(share.speaker || 'Speaker');
    var requests = '<div class="card" style="grid-column:1/3"><h3>3. Share requests <span class="badge ' + (ph === 'accepted' ? '' : ph === 'pending' ? 'warn' : 'off') + '">' + ph + '</span></h3>';
    if (ph === 'off') requests += '<div class="mut">Sharing is not running.</div>';
    else if (ph === 'waiting') requests += '<div class="mut">Waiting for a speaker to connect...</div>';
    else {
      requests += '<div class="row"><b>' + who + '</b><span class="mut small">' + (ph === 'connected' ? 'connected, not sharing' : ph === 'pending' ? 'wants to share - preview below (not on projector)' : 'live on the projector') + '</span></div><div id="share-preview-slot" style="max-width:560px;margin:10px 0"></div><div class="row">';
      if (ph === 'pending') requests += '<button class="b pri" data-action="share-accept">Accept &amp; Show</button><button class="b" data-action="share-reject">Reject</button>';
      if (ph === 'accepted') requests += '<button class="b bad" data-action="share-stop">Stop sharing</button>';
      if (ph === 'connected') requests += '<span class="mut small">Waiting for the speaker to press Start sharing.</span>';
      requests += '</div>';
    }
    requests += '</div>';
    return shell('Wireless Share', '<div class="grid2">' + setup + conn + requests + '</div>');
  }

  function pageIdle() {
    var i = S.idle, modes = [['none', 'Black screen'], ['power_point', 'PowerPoint (loops)'], ['video', 'Video loop'], ['image', 'Image']];
    var form = '<div class="card" style="max-width:640px"><h3>Idle screen</h3>' +
      '<div class="small mut" style="margin-bottom:10px">Shown between items, after the playlist ends (if set in Settings), or after inactivity. It never replaces a live item or speaker share on its own.</div>' +
      '<div class="row wrap"><label>Mode</label><select id="idle-mode">' + modes.map(function (m) { return '<option value="' + m[0] + '"' + (i.mode === m[0] ? ' selected' : '') + '>' + m[1] + '</option>'; }).join('') + '</select></div>' +
      '<div class="row" style="margin-top:10px"><span class="grow small mut" id="idle-path">' + esc(i.path || 'No file chosen') + '</span><button class="b" data-action="idle-pick">Choose file...</button></div>' +
      '<div class="row wrap" style="margin-top:10px"><label><input type="checkbox" id="idle-loop"' + (i.loop_video !== false ? ' checked' : '') + '> Loop video</label><label><input type="checkbox" id="idle-muted"' + (i.muted !== false ? ' checked' : '') + '> Muted</label></div>' +
      '<div class="row" style="margin-top:10px"><label>Auto-activate after (minutes of inactivity, 0 = off)</label><input type="number" id="idle-auto" min="0" max="240" style="width:80px" value="' + (i.auto_after_minutes || 0) + '"></div>' +
      '<div class="row" style="margin-top:14px"><button class="b pri" data-action="idle-save">Save</button><button class="b" data-action="idle">Show idle screen now</button><button class="b" data-action="black">Black screen</button></div></div>';
    return shell('Idle Screen Studio', form);
  }

  function pageDisplays() {
    var cur = displayName();
    var rows = S.displays.map(function (d) {
      var on = cur && cur.id === d.id;
      return '<tr><td>' + esc(d.name) + (d.primary ? ' <span class="badge off">operator</span>' : '') + '</td><td>' + d.width + ' x ' + d.height + ' (scale ' + d.scale + ')</td><td>' + d.x + ', ' + d.y + '</td><td>' +
        (on ? '<span class="badge">Audience output</span>' : '<button class="b sm" data-action="use-display" data-id="' + esc(d.id) + '">Use for audience</button>') + '</td></tr>';
    }).join('');
    return shell('Display Manager', '<div class="card"><div class="row" style="margin-bottom:8px"><button class="b" data-action="refresh-displays">Refresh</button><button class="b pri" data-action="test-output">Test output</button><button class="b" data-action="black">Clear (black)</button></div>' +
      '<table class="table"><tr><th>Display</th><th>Resolution</th><th>Position</th><th></th></tr>' + (rows || '<tr><td colspan="4" class="mut">No displays detected.</td></tr>') + '</table>' +
      (cur ? '' : '<div class="banner" style="margin-top:10px">Only one display was found, so the audience output runs in a small simulation window. Connect the projector with HDMI/DisplayPort/USB-C (extended desktop) and press Refresh.</div>') +
      '<div class="small mut" style="margin-top:10px">Audience output follows the chosen display. If the projector is unplugged during a show, output moves back to the simulation window; reconnect and press Refresh, then Go Live again.</div></div>');
  }

  function pageSettings() {
    var s = S.settings;
    function sel(id, val, opts) { return '<select id="' + id + '">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (val === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>'; }
    var form = '<div class="card"><h3>Playback</h3><table class="table">' +
      '<tr><td>When an item finishes</td><td>' + sel('set-end', s.end_policy, [['wait', 'Wait for operator'], ['auto_advance', 'Auto-advance to next']]) + '</td></tr>' +
      '<tr><td>When the playlist ends / Stop</td><td>' + sel('set-after', s.after_stop, [['idle', 'Show idle screen'], ['black', 'Black screen']]) + '</td></tr>' +
      '<tr><td>Images</td><td>' + sel('set-fit', s.image_fit, [['fit', 'Fit (letterbox)'], ['fill', 'Fill (crop)']]) + '</td></tr>' +
      '<tr><td>Default image duration (s, when auto-advancing)</td><td><input type="number" id="set-imgsecs" min="1" max="3600" value="' + (s.default_image_secs || 10) + '" style="width:80px"></td></tr>' +
      '<tr><td>Folder scan depth (0 = folder only)</td><td><input type="number" id="set-depth" min="0" max="5" value="' + (s.scan_depth == null ? 1 : s.scan_depth) + '" style="width:80px"></td></tr>' +
      '<tr><td>Speaker share port</td><td><input type="number" id="set-port" min="1024" max="65535" value="' + (s.share_port || 8443) + '" style="width:90px"></td></tr></table>' +
      '<button class="b pri" data-action="settings-save">Save settings</button></div>';
    var keys = '<div class="card"><h3>Keyboard shortcuts</h3><table class="table">' + Object.keys(KEYLABEL).map(function (k) {
      return '<tr><td>' + KEYLABEL[k] + '</td><td><button class="b sm" data-action="remap" data-key="' + k + '">' + (S.capturing === k ? 'Press a key...' : esc(S.keys[k])) + '</button></td></tr>';
    }).join('') + '</table><button class="b sm" data-action="keys-reset">Reset to defaults</button><div class="small mut" style="margin-top:6px">Shortcuts are ignored while typing in a text field.</div></div>';
    var diag = '<div class="card" style="grid-column:1/3"><h3>Diagnostics</h3><div class="row wrap"><button class="b" data-action="diag">Collect diagnostics</button><button class="b" data-action="open-logs">Open logs folder</button><button class="b" data-action="ppt-detect">Check PowerPoint</button></div>' +
      (S.diag ? '<pre class="diag">' + esc(S.diag) + '</pre>' : '') + '<div class="small mut" style="margin-top:6px">Diagnostics exclude pairing codes, tokens and keys.</div></div>';
    return shell('Settings', '<div class="grid2">' + form + keys + diag + '</div>');
  }

  function renderPage() {
    var v = $('#view');
    if (S.page === 'dashboard') { renderDashboard(); return; }
    var html = { playlists: pagePlaylists, library: pageLibrary, share: pageShare, idle: pageIdle, displays: pageDisplays, settings: pageSettings }[S.page]();
    var keep = document.activeElement && document.activeElement.id === 'lib-search' ? { id: 'lib-search', pos: document.activeElement.selectionStart } : null;
    v.innerHTML = html;
    if (keep) { var el = document.getElementById(keep.id); if (el) { el.focus(); try { el.setSelectionRange(keep.pos, keep.pos); } catch (e) {} } }
    var slot = $('#share-preview-slot');
    if (slot && share.hasPreview()) slot.appendChild(share.video);
  }
  function navigate(page) {
    S.page = page;
    pv.key = null;
    var btns = document.querySelectorAll('#nav button');
    for (var i = 0; i < btns.length; i++) btns[i].classList.toggle('active', btns[i].dataset.page === page);
    if (page === 'share') { call('sharing_interfaces').then(function (r) { if (r) { S.ifaces = r; if (!S.ifaceSel && r[0]) S.ifaceSel = r[0].ip; if (S.page === 'share') renderPage(); } }); }
    if (page === 'displays') loadDisplays();
    renderPage();
  }

  // ------------------------------------------------------------ dialogs
  function promptText(title, initial) {
    return new Promise(function (resolve) {
      var o = document.createElement('div');
      o.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);display:grid;place-items:center;z-index:100';
      o.innerHTML = '<div class="card" style="width:380px"><h3>' + esc(title) + '</h3><input type="text" id="pt-in" style="width:100%" value="' + esc(initial || '') + '"><div class="row" style="margin-top:12px;justify-content:flex-end"><button class="b" id="pt-no">Cancel</button><button class="b pri" id="pt-ok">OK</button></div></div>';
      document.body.appendChild(o);
      var inp = o.querySelector('#pt-in'); inp.focus(); inp.select();
      function done(v) { o.remove(); resolve(v); }
      o.querySelector('#pt-ok').onclick = function () { done(inp.value.trim() || null); };
      o.querySelector('#pt-no').onclick = function () { done(null); };
      inp.onkeydown = function (e) { if (e.key === 'Enter') done(inp.value.trim() || null); if (e.key === 'Escape') done(null); e.stopPropagation(); };
    });
  }
  function pickFolder() {
    return T.dialog.open({ directory: true, multiple: false, title: 'Choose the media folder' });
  }
  function pickFile(title) {
    return T.dialog.open({ multiple: false, title: title, filters: [{ name: 'Presentations, videos, images', extensions: ['pptx', 'ppt', 'ppsx', 'pps', 'mp4', 'm4v', 'mov', 'webm', 'mkv', 'avi', 'wmv', 'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'] }] });
  }

  // ------------------------------------------------------------ actions
  function scanAndShow(path) {
    return call('scan_folder', { path: path }).then(function (r) {
      if (!r) return;
      S.folder = r; S.scope = 'folder'; S.libSel = {};
      S.settings.last_folder = r.root;
      toast('Found ' + r.files.length + ' files.', 'ok');
      if (S.page === 'playlists') navigate('library'); else renderPage();
    });
  }
  function addMedia(ids) {
    if (!ids.length) return Promise.resolve();
    var ensure = S.plId != null ? Promise.resolve(S.plId) : promptText('Name your first playlist', 'Event 1').then(function (name) {
      if (!name) return null;
      return call('create_playlist', { name: name }).then(function (p) { return p ? p.id : null; });
    });
    return ensure.then(function (pid) {
      if (pid == null) return;
      S.plId = pid;
      return call('add_items', { playlistId: pid, mediaIds: ids }).then(function (r) {
        if (r === undefined) return;
        toast('Added ' + ids.length + ' item(s).', 'ok');
        return loadPlaylists();
      });
    });
  }
  function goLive() {
    if (S.plId == null) { toast('Create or select a playlist first.', 'err'); return; }
    if (!S.entries.length) { toast('The playlist is empty.', 'err'); return; }
    if (S.selItem != null) call('go_live_item', { playlistId: S.plId, itemId: S.selItem });
    else call('start_playlist', { playlistId: S.plId });
  }
  function moveSelected(delta) {
    var idx = S.entries.findIndex(function (e) { return e.item.id === S.selItem; });
    var to = idx + delta;
    if (idx < 0 || to < 0 || to >= S.entries.length) return;
    call('move_item', { itemId: S.selItem, newIndex: to }).then(loadEntries);
  }
  function moveItem(id, delta) {
    var idx = S.entries.findIndex(function (e) { return e.item.id === id; });
    var to = idx + delta;
    if (idx < 0 || to < 0 || to >= S.entries.length) return;
    call('move_item', { itemId: id, newIndex: to }).then(loadPlaylists);
  }
  function sharingConnect() {
    return call('sharing_admin_conn').then(function (c) { if (c) share.connect(c); });
  }
  function hotspotText(r) {
    if (!r) return '';
    if (r.ok) return 'Hotspot ' + r.state + (r.ssid ? ' - network "' + r.ssid + '"' : '') + ' - clients: ' + r.clients;
    return r.error || 'Hotspot unavailable';
  }
  function afterProjectorStopped() {
    if (S.out.live_total > 0 && S.out.playlist_id != null) return call('return_to_playlist');
    return call('black_screen');
  }

  var A = {
    nav: function (el) { navigate(el.dataset.page); },
    'select-item': function (el) { S.selItem = +el.dataset.item; renderPlaylistRows(); },
    'play-item': function (el) { S.selItem = +el.dataset.item; call('go_live_item', { playlistId: S.plId, itemId: +el.dataset.item }); },
    filter: function (el) { S.filter = el.dataset.filter; renderPlaylistPanel(); },
    scope: function (el) { S.scope = el.dataset.scope; renderPlaylistPanel(); },
    'choose-folder': function () { pickFolder().then(function (p) { if (p) return scanAndShow(p); }); },
    rescan: function () { if (S.folder.root) scanAndShow(S.folder.root); },
    'add-media': function (el) { addMedia([+el.dataset.media]); },
    'add-all-filtered': function () { addMedia(filteredMedia(S.query, S.filter).filter(function (m) { return m.available; }).map(function (m) { return m.id; })); },
    'remove-sel': function () { if (S.selItem == null) return; call('remove_item', { itemId: S.selItem }).then(function () { S.selItem = null; return loadPlaylists(); }); },
    'clear-playlist': function () { if (S.plId == null) return; ask('Remove all items from this playlist?').then(function (y) { if (y) call('clear_playlist', { playlistId: S.plId }).then(loadPlaylists); }); },
    'move-up': function () { moveSelected(-1); },
    'move-down': function () { moveSelected(1); },
    'prev-item': function () { call('prev_item'); },
    'next-item': function () { call('next_item'); },
    'go-live': goLive,
    black: function () { call('black_screen'); },
    idle: function () { call('activate_idle'); },
    'stop-all': function () {
      ask('Stop everything and go to a black screen? Any speaker share will end.', 'Stop all').then(function (y) {
        if (!y) return;
        if (share.phase === 'accepted' || share.phase === 'pending') share.stop();
        call('stop_all');
      });
    },
    'toggle-pause': function () { call('video_control', { action: S.out.state.playback === 'paused' ? 'play' : 'pause' }); },
    slide: function (el) { call('slide_control', { action: el.dataset.do }); },
    'vid-restart': function () { call('video_control', { action: 'restart' }); },
    'vid-mute': function () { call('video_control', { action: S.video.muted ? 'unmute' : 'mute' }); },
    'return-playlist': function () { call('return_to_playlist'); },
    // playlists page
    'pl-select': function (el) { S.plId = +el.dataset.id; S.selItem = null; renderPlaylistSelect(); loadEntries(); },
    'pl-new': function () { promptText('New playlist name', 'Event ' + (S.playlists.length + 1)).then(function (n) { if (!n) return; call('create_playlist', { name: n }).then(function (p) { if (p) { S.plId = p.id; loadPlaylists(); } }); }); },
    'pl-rename': function () { var p = S.playlists.filter(function (x) { return x.id === S.plId; })[0]; if (!p) return; promptText('Rename playlist', p.name).then(function (n) { if (n) call('rename_playlist', { id: p.id, name: n }).then(loadPlaylists); }); },
    'pl-dup': function () { if (S.plId == null) return; call('duplicate_playlist', { id: S.plId }).then(function (p) { if (p) { S.plId = p.id; loadPlaylists(); } }); },
    'pl-del': function () { var p = S.playlists.filter(function (x) { return x.id === S.plId; })[0]; if (!p) return; ask('Delete playlist "' + p.name + '"? Files on disk are not deleted.').then(function (y) { if (y) call('delete_playlist', { id: p.id }).then(function () { S.plId = null; return loadPlaylists(); }); }); },
    'item-up': function (el) { moveItem(+el.dataset.item, -1); },
    'item-down': function (el) { moveItem(+el.dataset.item, 1); },
    'item-dup': function (el) { call('duplicate_item', { itemId: +el.dataset.item }).then(loadPlaylists); },
    'item-del': function (el) { call('remove_item', { itemId: +el.dataset.item }).then(loadPlaylists); },
    relink: function (el) { pickFile('Locate the moved file').then(function (p) { if (p) call('relink_media', { id: +el.dataset.media, newPath: p }).then(function () { toast('Relinked.', 'ok'); loadEntries(); }); }); },
    // library page
    'lib-toggle': function (el) {
      var id = el.dataset.media; if (S.libSel[id]) delete S.libSel[id]; else S.libSel[id] = true;
      el.classList.toggle('sel'); updateLibBtn();
    },
    'lib-select-all': function () { filteredMedia(S.libQuery, S.libFilter).forEach(function (m) { if (m.available) S.libSel[m.id] = true; }); renderPage(); },
    'lib-clear': function () { S.libSel = {}; renderPage(); },
    'lib-add': function () { var ids = Object.keys(S.libSel).map(Number); addMedia(ids).then(function () { S.libSel = {}; renderPage(); }); },
    // displays
    'pick-display': function (el) { A['use-display'](el); },
    'use-display': function (el) { call('select_display', { id: el.dataset.id }).then(function (r) { if (r === undefined) return; S.settings.audience_display = el.dataset.id; renderOutputCard(); renderStatus(); if (S.page === 'displays') renderPage(); }); },
    'refresh-displays': function () { loadDisplays().then(function () { if (S.page === 'displays') renderPage(); }); },
    'test-output': function () { call('test_output'); },
    // idle
    'idle-pick': function () { pickFile('Choose the idle file').then(function (p) { if (p) { S.idle.path = p; var el = $('#idle-path'); if (el) el.textContent = p; } }); },
    'idle-save': function () {
      var cfg = { mode: $('#idle-mode').value, path: S.idle.path || null, loop_video: $('#idle-loop').checked, muted: $('#idle-muted').checked, auto_after_minutes: (+$('#idle-auto').value) || null };
      call('set_idle', { config: cfg }).then(function (r) { if (r) { S.idle = r; toast('Idle screen saved.', 'ok'); } });
    },
    // sharing
    'refresh-ifaces': function () { call('sharing_interfaces').then(function (r) { if (r) { S.ifaces = r; renderPage(); } }); },
    'sharing-start': function () {
      var ip = $('#iface').value; S.ifaceSel = ip;
      call('sharing_start', { ip: ip }).then(function (r) { if (!r) return; S.shareInfo = r; renderSideNet(); return sharingConnect().then(renderPage); });
    },
    'sharing-stop': function () { share.disconnect(false); call('sharing_stop').then(function () { S.shareInfo = null; renderSideNet(); renderPage(); }); },
    'new-code': function () { call('sharing_new_code').then(function (r) { if (r) { S.shareInfo = r; renderSideNet(); renderPage(); } }); },
    'copy-url': function () { if (S.shareInfo) navigator.clipboard.writeText(S.shareInfo.base_url).then(function () { toast('Link copied.', 'ok'); }); },
    hs: function (el) { call('hotspot_control', { action: el.dataset.do }).then(function (r) { S.hotspot = hotspotText(r); if (S.page === 'share') renderPage(); }); },
    'hs-settings': function () { call('open_hotspot_settings'); },
    'fw-add': function () { ask('Windows will ask for administrator permission to allow ShowFlow speaker sharing on private networks. Continue?').then(function (y) { if (y) call('add_firewall_rule'); }); },
    'share-accept': function () { call('route_share').then(function (r) { if (r !== undefined) share.accept(); }); },
    'share-reject': function () { share.reject(); },
    'share-stop': function () { share.stop(); if (S.out.state.source === 'speaker_share') afterProjectorStopped(); },
    // settings
    'settings-save': function () {
      var s = Object.assign({}, S.settings, {
        end_policy: $('#set-end').value, after_stop: $('#set-after').value, image_fit: $('#set-fit').value,
        default_image_secs: +$('#set-imgsecs').value || 10, scan_depth: +$('#set-depth').value || 0, share_port: +$('#set-port').value || 8443
      });
      call('update_settings', { settings: s }).then(function (r) { if (r) { S.settings = r; toast('Settings saved.', 'ok'); } });
    },
    remap: function (el) { S.capturing = el.dataset.key; renderPage(); },
    'keys-reset': function () { try { localStorage.removeItem('showflow.keys'); } catch (e) {} loadKeys(); renderPage(); },
    diag: function () { call('get_diagnostics').then(function (r) { if (r) { S.diag = JSON.stringify(r, null, 2); renderPage(); } }); },
    'open-logs': function () { call('open_logs_folder'); },
    'ppt-detect': function () { call('ppt_detect').then(function (r) { if (r) toast(r.installed ? 'PowerPoint found (' + (r.progid || 'installed') + ').' : 'PowerPoint is NOT installed.', r.installed ? 'ok' : 'err'); }); }
  };
  function updateLibBtn() {
    var b = $('[data-action="lib-add"]'); if (!b) return;
    var n = Object.keys(S.libSel).length;
    b.textContent = 'Add ' + n + ' to playlist'; b.disabled = !(n && S.plId != null);
  }

  // ------------------------------------------------------------ DOM events
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-action]');
    if (!el) return;
    var fn = A[el.dataset.action];
    if (fn) fn(el, ev);
  });
  document.addEventListener('input', function (ev) {
    var t = ev.target;
    if (t.id === 'pl-search') { S.query = t.value; renderPlaylistRows(); }
    else if (t.id === 'lib-search') { S.libQuery = t.value; renderPage(); }
    else if (t.id === 'vid-vol') {
      var now = Date.now(); if (now - (A._vt || 0) < 80) return; A._vt = now;
      call('video_control', { action: 'volume', value: (+t.value) / 100 });
    }
  });
  document.addEventListener('change', function (ev) {
    var t = ev.target;
    if (t.id === 'playlist-select') { S.plId = t.value ? +t.value : null; S.selItem = null; loadEntries(); return; }
    if (t.id === 'lib-filter') { S.libFilter = t.value; renderPage(); return; }
    if (t.id === 'vid-seek') { call('video_control', { action: 'seek', value: +t.value }); return; }
    if (t.dataset && t.dataset.f) {
      var tr = t.closest('[data-item]'); if (!tr) return;
      var id = +tr.dataset.item;
      var e = S.entries.filter(function (x) { return x.item.id === id; })[0]; if (!e) return;
      function val(f) { var i = tr.querySelector('[data-f="' + f + '"]'); return i; }
      var o = {
        auto_advance: val('auto_advance') ? val('auto_advance').checked : e.item.auto_advance,
        looped: val('looped') ? val('looped').checked : e.item.looped,
        volume: val('volume') ? (+val('volume').value) / 100 : e.item.volume,
        start_position_ms: val('start_s') ? (val('start_s').value ? Math.round(+val('start_s').value * 1000) : null) : e.item.start_position_ms,
        image_duration_secs: val('image_secs') ? (val('image_secs').value ? Math.round(+val('image_secs').value) : null) : e.item.image_duration_secs
      };
      call('update_item_options', { itemId: id, options: o }).then(function (r) {
        if (r === undefined) return;
        e.item.auto_advance = o.auto_advance; e.item.looped = o.looped; e.item.volume = o.volume;
        e.item.start_position_ms = o.start_position_ms; e.item.image_duration_secs = o.image_duration_secs;
      });
    }
  });
  // drag & drop reordering (playlist rows)
  document.addEventListener('dragstart', function (ev) {
    var r = ev.target.closest && ev.target.closest('[data-item][draggable]'); if (!r) return;
    S.dragId = +r.dataset.item; ev.dataTransfer.effectAllowed = 'move';
    try { ev.dataTransfer.setData('text/plain', String(S.dragId)); } catch (e) {}
  });
  document.addEventListener('dragover', function (ev) {
    var r = ev.target.closest && ev.target.closest('[data-item][draggable]');
    if (!r || S.dragId == null) return;
    ev.preventDefault();
    var prev = document.querySelector('.drop'); if (prev && prev !== r) prev.classList.remove('drop');
    r.classList.add('drop');
  });
  document.addEventListener('drop', function (ev) {
    var r = ev.target.closest && ev.target.closest('[data-item][draggable]');
    var d = document.querySelector('.drop'); if (d) d.classList.remove('drop');
    if (!r || S.dragId == null) return;
    ev.preventDefault();
    var to = +r.dataset.idx, id = S.dragId; S.dragId = null;
    if (id === +r.dataset.item) return;
    call('move_item', { itemId: id, newIndex: to }).then(loadPlaylists);
  });
  document.addEventListener('dragend', function () { S.dragId = null; var d = document.querySelector('.drop'); if (d) d.classList.remove('drop'); });

  // keyboard shortcuts
  function combo(e) {
    var k = e.key === ' ' ? 'Space' : (e.key.length === 1 ? e.key.toLowerCase() : e.key);
    return (e.ctrlKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey && e.key.length > 1 ? 'Shift+' : '') + k;
  }
  document.addEventListener('keydown', function (e) {
    if (S.capturing) {
      if (['Control', 'Shift', 'Alt', 'Meta'].indexOf(e.key) >= 0) return;
      e.preventDefault();
      S.keys[S.capturing] = combo(e); S.capturing = null;
      try { localStorage.setItem('showflow.keys', JSON.stringify(S.keys)); } catch (x) {}
      renderPage(); return;
    }
    var tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;
    var c = combo(e), name = null;
    Object.keys(S.keys).forEach(function (k) { if (S.keys[k] === c) name = k; });
    if (!name) return;
    var pptLive = S.out.state.source === 'powerpoint' || S.out.state.source === 'idle_powerpoint';
    e.preventDefault();
    switch (name) {
      case 'pause': A['toggle-pause'](); break;
      case 'prevSlide': if (pptLive) call('slide_control', { action: 'prev' }); break;
      case 'nextSlide': if (pptLive) call('slide_control', { action: 'next' }); break;
      case 'prevItem': call('prev_item'); break;
      case 'nextItem': call('next_item'); break;
      case 'goLive': goLive(); break;
      case 'black': call('black_screen'); break;
      case 'stop': A['stop-all'](); break;
    }
  });

  // ------------------------------------------------------------ backend events
  var lastErr = null;
  function onOutput(p) {
    var prev = S.out.state;
    S.out = p;
    function after() {
      if (prev.source !== p.state.source || prev.item_id !== p.state.item_id) {
        S.video = { t: 0, d: 0, paused: false, muted: false, volume: 1 };
        S.thumbs = { current: null, next: null };
        S.slide = { position: 0, count: 0 };
        pv.key = null;
      }
      if (p.state.source !== 'speaker_share') share.leftProjector();
      if (p.state.source === 'powerpoint' || p.state.source === 'idle_powerpoint') refreshThumbs();
      if (p.state.playback === 'error' && p.state.message && p.state.message !== lastErr) { toast(p.state.message, 'err'); }
      lastErr = p.state.playback === 'error' ? p.state.message : null;
      renderPreview(); renderPlaylistRows(); renderNextCard(); renderStatus();
    }
    if (p.playlist_id != null && p.playlist_id !== S.plId && isPlaylistSource(p.state.source)) {
      S.plId = p.playlist_id; renderPlaylistSelect(); loadEntries().then(after);
    } else after();
  }
  function listen() {
    T.event.listen('output_state_changed', function (ev) { onOutput(ev.payload); });
    T.event.listen('slide_changed', function (ev) { S.slide = ev.payload; refreshThumbs(); var sp = $('#slide-pos'); if (sp) sp.textContent = 'Slide ' + S.slide.position + ' / ' + S.slide.count; });
    T.event.listen('playlist_waiting', function (ev) { toast(ev.payload.has_next ? 'Item finished. Press Next when ready.' : 'End of playlist reached.'); });
    T.event.listen('audience_event', function (ev) {
      var p = ev.payload || {};
      if (p.type === 'time') { S.video = { t: p.t, d: p.d, paused: p.paused, muted: p.muted, volume: p.volume }; updateVideoProgress(); }
      else if (p.type === 'error') { toast(p.message, 'err'); }
    });
    share.onProjectorLost = function (msg) {
      toast(msg + ' Output switched to black. Use "Return to playlist" to continue.', 'err');
      call('black_screen');
    };
  }

  // ------------------------------------------------------------ init
  function init() {
    loadKeys();
    Promise.all([invoke('get_settings'), invoke('get_idle')]).then(function (r) {
      S.settings = r[0]; S.idle = r[1];
      listen();
      return loadDisplays();
    }).then(function () {
      return call('get_output_state');
    }).then(function (snap) {
      if (snap) S.out = snap;
      var last = S.settings.last_folder;
      return last ? invoke('scan_folder', { path: last }).then(function (r) { S.folder = r; }).catch(function () {}) : null;
    }).then(function () {
      return loadPlaylists();
    }).then(function () {
      renderSideNet(); renderStatus(); navigate('dashboard');
      setInterval(renderStatus, 15000);
      if (S.plId != null && S.entries.length) toast('Playlist ready. Nothing is projected until you press Go Live.');
    }).catch(function (e) { toast('Startup problem: ' + e, 'err'); });
  }
  init();
})();

# Third-party components
Rust crates: tauri, tauri-plugin-dialog, axum, axum-server, rustls (ring), rcgen, tokio, serde, rusqlite (bundled SQLite), walkdir, qrcode, local-ip-address, rand, tracing. Tooling: @tauri-apps/cli.
All are permissively licensed (MIT/Apache-2.0/ISC/BSD or public domain at the time of writing); verify with `cargo install cargo-license && cargo license` before distribution.
No libVLC/GPL media components are used; media decoding is provided by the Microsoft WebView2 runtime.

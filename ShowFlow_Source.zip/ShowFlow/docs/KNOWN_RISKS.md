# Known risks and first-compile checklist

The code has not been compiled. These are the places most likely to need attention, in rough order.

## Likely compile-time items
1. **`axum-server` feature name.** `crates/showflow-sharing/Cargo.toml` uses `tls-rustls-no-provider` so the `ring` crypto provider is used (no CMake/NASM needed). If Cargo reports the feature does not exist, switch to `tls-rustls` and install CMake + NASM, or pin an `axum-server` 0.7.x release that has it.
2. **`rcgen` 0.13 API** (`CertificateParams::new`, `self_signed`, `date_time_ymd`). If a newer minor changed names, adjust `crates/showflow-sharing/src/cert.rs` (about 10 lines).
3. **Tauri 2.x minor-version API drift** in `src-tauri/src/display.rs` (`available_monitors`, `Monitor::name`, window builder methods) and `main.rs` (`Listener`). Fix as the compiler suggests.
4. **`rusqlite` 0.32**: if you bump it, `execute_batch`/`query_row` usage in `storage.rs` should still compile.
5. Warnings about unused items are expected.

## Likely runtime items (need real Windows hardware)
- **PowerPoint window placement.** `ppt_host.ps1` runs the show *windowed*, strips the frame, and moves it with `SetWindowPos` to the audience display bounds (the process is made DPI-aware so pixel coordinates match Tauri's). Some PowerPoint builds may behave differently (e.g. Protected View, presenter view settings, multi-monitor DPI mixes). Verify on the projector.
- **WebRTC across the LAN.** Chromium may hide host IPs behind mDNS names (`*.local`). Resolution needs UDP 5353 and an unblocked path. The speaker's WebRTC media is UDP to the WebView2 process; Windows Firewall may prompt for `msedgewebview2.exe` on first use — allow it on *Private* networks. Wi-Fi "client isolation" on venue networks will block everything: use the ShowFlow/Windows hotspot or a dedicated router.
- **Self-signed certificate warning** in the speaker's browser is expected once per host IP.
- **Windows Mobile Hotspot** needs an active internet connection profile (Windows limitation); otherwise the app reports it honestly and offers the Windows settings page.
- **Video codecs.** WebView2 plays H.264/AAC MP4 reliably; other containers depend on the installed codecs.
- **Unplugging the projector mid-show.** Detection is on refresh (Display Manager) and when a new output is started; there is no hot-plug watcher yet.
- **Auto-advance after the last PowerPoint slide** is detected by polling the slide-show state (every ~600 ms) and by Next pressed on the last slide.

## Security notes
- LAN service binds only to the chosen private IPv4 address; admin/audience signaling is on a random loopback port protected by a per-run token.
- Pairing code: 6 digits, constant-time compare, 5 failures per minute per IP, expires after 4 hours, can be regenerated. The code travels in the QR URL *fragment* (not sent to the server).
- Speaker WebSocket requires a matching `Origin`; messages are size-limited; one speaker at a time.
- The TLS private key is stored in the app-data folder under the user profile. DPAPI wrapping is not implemented.
- The asset protocol scope is `**` so the local UI can display chosen media files; the web content is entirely local (CSP is disabled because the UI loads only bundled files).
- Logs never contain pairing codes, tokens, keys or hotspot passwords (diagnostics strip the code).

## Not implemented (v1 scope cuts)
- Display hot-plug watcher; drag-and-drop of files from Explorer; multi-select in playlist panel; installer code signing; DPAPI key protection; PowerPoint presenter-view / notes display; audio-only share control beyond the browser's checkbox; session history UI (table not created).

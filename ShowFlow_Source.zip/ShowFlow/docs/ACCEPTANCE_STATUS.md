# Acceptance status (from WINDOWS_ACCEPTANCE_TESTS.md)

Legend: **Impl** = code exists for it, **Untested** = nothing has been run. No row is claimed as passed.

| Area | Item | Status |
|---|---|---|
| A | Clean build with documented commands | Untested (not yet compiled) |
| A | Installer (NSIS) | Configured, untested |
| A | Works offline | Impl (no network calls; sharing is LAN only) — Untested |
| A | Missing PowerPoint detected | Impl (`ppt_detect`, Settings → Check PowerPoint; Go Live error text) — Untested |
| A | Logs local, no secrets | Impl — Untested |
| B | Folder scan, search, type filters | Impl, unit-tested logic (not run) |
| B | Add one / selected / all filtered | Impl |
| B | Reorder, remove, duplicate, rename, duplicate playlist, reload | Impl (storage unit tests written, not run) |
| B | Files never modified | Impl (only read / opened read-only) |
| B | Missing-file warning and relink | Impl |
| C | Native PowerPoint on projector, slide controls, end policy, Stop closes only own show | Impl — needs hardware validation |
| C | Helper timeout recovery | Impl (kill + respawn) — Untested |
| D | Video play/pause/seek/volume/mute/loop/auto-advance | Impl — Untested |
| D | Image fit/fill/timed advance | Impl — Untested |
| D | PPT→video→PPT without desktop flash | Impl (audience window shows black underneath) — Untested |
| E | Display detection, operator stays on admin screen | Impl — needs hardware |
| E | Single-display simulation clearly labelled | Impl (window title + banner) |
| F | QR + pairing URL, HTTPS, preview, accept/reject/stop, no auto-projection | Impl — needs two PCs |
| G | Hotspot start/stop/status with honest errors | Impl — needs supported adapter |
| H | Black, idle video/PPT/image, auto-idle policy, return to playlist | Impl — Untested |
| I | Restart restores playlists/settings; no auto-project on launch | Impl — Untested |
| I | 60-minute soak | Not run |

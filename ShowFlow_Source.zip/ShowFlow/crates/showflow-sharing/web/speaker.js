(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var ws = null, stream = null, pcPreview = null, pcAudience = null;
  var wantAudience = false, connected = false, pingTimer = null;
  var RTC_CFG = { iceServers: [] }; // LAN only: host candidates, no STUN/TURN

  function setStatus(text, kind) {
    var s = $('status');
    s.textContent = text;
    s.className = 'status' + (kind ? ' ' + kind : '');
  }
  function send(obj) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj)); }

  // Pairing code from the QR link: https://host:port/#c=123456
  (function () {
    var m = /[#&]c=(\d{4,8})/.exec(location.hash || '');
    if (m) { $('code').value = m[1]; history.replaceState(null, '', location.pathname); }
    try { var n = localStorage.getItem('sf_name'); if (n) $('name').value = n; } catch (e) {}
  })();

  $('btn-connect').addEventListener('click', connect);
  $('code').addEventListener('keydown', function (e) { if (e.key === 'Enter') connect(); });
  $('btn-share').addEventListener('click', startShare);
  $('btn-stop').addEventListener('click', function () { stopAll(true); });

  function connect() {
    var code = $('code').value.trim();
    var name = $('name').value.trim();
    if (!/^\d{6}$/.test(code)) { setStatus('Enter the 6-digit code.', 'bad'); return; }
    try { localStorage.setItem('sf_name', name); } catch (e) {}
    $('btn-connect').disabled = true;
    setStatus('Connecting...');
    ws = new WebSocket('wss://' + location.host + '/ws');
    ws.onopen = function () { send({ type: 'hello', role: 'speaker', code: code, label: name }); };
    ws.onmessage = function (ev) { onMessage(JSON.parse(ev.data)); };
    ws.onclose = function () {
      clearInterval(pingTimer);
      var was = connected;
      connected = false;
      cleanupPeers();
      stopTracks();
      $('step-connect').classList.remove('hidden');
      $('step-share').classList.add('hidden');
      $('btn-connect').disabled = false;
      if (was) setStatus('Disconnected from the host.', 'bad');
    };
  }

  function onMessage(m) {
    switch (m.type) {
      case 'error':
        setStatus(m.message || 'Error', 'bad');
        break;
      case 'welcome':
        connected = true;
        pingTimer = setInterval(function () { send({ type: 'ping' }); }, 20000);
        $('step-connect').classList.add('hidden');
        $('step-share').classList.remove('hidden');
        setStatus('Connected. Click "Start sharing" and pick the screen or window to show.', 'ok');
        break;
      case 'accept':
        wantAudience = true;
        setStatus('The host accepted. Going live...', 'ok');
        maybeOfferAudience();
        break;
      case 'reject':
        setStatus('The host declined the share.', 'bad');
        stopAll(false);
        break;
      case 'stop':
        setStatus('The host stopped your share.', 'bad');
        stopAll(false);
        break;
      case 'event':
        if (m.event === 'audience_ready') maybeOfferAudience();
        if (m.event === 'target_unavailable' && m.target === 'audience') {
          setTimeout(maybeOfferAudience, 1000);
        }
        break;
      case 'signal':
        onSignal(m);
        break;
    }
  }

  function makePc(channel, to) {
    var pc = new RTCPeerConnection(RTC_CFG);
    stream.getTracks().forEach(function (t) { pc.addTrack(t, stream); });
    pc.onicecandidate = function (e) {
      if (e.candidate) send({ type: 'signal', to: to, channel: channel, data: { kind: 'candidate', candidate: e.candidate } });
    };
    pc.onconnectionstatechange = function () {
      if (channel === 'audience') {
        if (pc.connectionState === 'connected') setStatus('You are live on the projector.', 'ok');
        if (pc.connectionState === 'failed') setStatus('Could not reach the projector output. The host can retry.', 'bad');
      }
    };
    return pc;
  }

  async function offer(pc, channel, to) {
    var o = await pc.createOffer();
    await pc.setLocalDescription(o);
    send({ type: 'signal', to: to, channel: channel, data: { kind: 'offer', sdp: pc.localDescription } });
  }

  async function startShare() {
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: { ideal: 30, max: 30 } },
        audio: $('audio').checked
      });
    } catch (e) {
      setStatus('Sharing was cancelled or blocked: ' + (e && e.name ? e.name : e), 'bad');
      return;
    }
    stream.getVideoTracks()[0].addEventListener('ended', function () { stopAll(true); });
    $('btn-share').classList.add('hidden');
    $('btn-stop').classList.remove('hidden');
    pcPreview = makePc('preview', 'admin');
    send({ type: 'share_request', label: $('name').value.trim() });
    await offer(pcPreview, 'preview', 'admin');
    setStatus('Waiting for the host to accept...');
  }

  function maybeOfferAudience() {
    if (!wantAudience || !stream || pcAudience) return;
    pcAudience = makePc('audience', 'audience');
    offer(pcAudience, 'audience', 'audience').catch(function (e) { setStatus('Offer failed: ' + e, 'bad'); });
  }

  async function onSignal(m) {
    var d = m.data || {};
    var pc = m.channel === 'audience' ? pcAudience : pcPreview;
    if (!pc) return;
    try {
      if (d.kind === 'answer') await pc.setRemoteDescription(d.sdp);
      else if (d.kind === 'candidate' && d.candidate) await pc.addIceCandidate(d.candidate);
    } catch (e) { /* ignore late candidates */ }
  }

  function cleanupPeers() {
    [pcPreview, pcAudience].forEach(function (p) { if (p) { try { p.close(); } catch (e) {} } });
    pcPreview = null; pcAudience = null; wantAudience = false;
  }
  function stopTracks() {
    if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
  }
  function stopAll(notify) {
    if (notify) send({ type: 'share_stopped' });
    cleanupPeers();
    stopTracks();
    $('btn-share').classList.remove('hidden');
    $('btn-stop').classList.add('hidden');
    if (notify) setStatus('Sharing stopped.');
  }
})();

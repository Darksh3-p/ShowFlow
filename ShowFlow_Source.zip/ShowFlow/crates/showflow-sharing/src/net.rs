use std::net::IpAddr;

use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
pub struct NetInterface {
    pub name: String,
    pub ip: String,
    pub kind: String,
    pub recommended: bool,
}

/// Classify an adapter by its (Windows) friendly name and address.
pub fn classify(name: &str, ip: &str) -> (String, bool) {
    let n = name.to_lowercase();
    if ip == "192.168.137.1" {
        return ("Windows Mobile Hotspot".into(), true);
    }
    if n.contains("vethernet")
        || n.contains("vmware")
        || n.contains("virtualbox")
        || n.contains("hyper-v")
        || n.contains("vpn")
        || n.contains("tap")
        || n.contains("tun")
        || n.contains("loopback")
        || n.contains("wsl")
        || n.contains("docker")
    {
        return ("Virtual / VPN (not recommended)".into(), false);
    }
    if n.contains("wi-fi") || n.contains("wlan") || n.contains("wireless") {
        return ("Wi-Fi".into(), true);
    }
    if n.contains("ethernet") || n.starts_with("eth") || n.contains("lan") {
        return ("Ethernet".into(), true);
    }
    ("Network adapter".into(), false)
}

/// Private IPv4 addresses that could serve a LAN. Loopback and link-local are excluded.
pub fn candidate_interfaces() -> Vec<NetInterface> {
    let mut out = Vec::new();
    let list = match local_ip_address::list_afinet_netifas() {
        Ok(l) => l,
        Err(_) => return out,
    };
    for (name, ip) in list {
        if let IpAddr::V4(v4) = ip {
            if v4.is_loopback() || v4.is_link_local() || !v4.is_private() {
                continue;
            }
            let s = v4.to_string();
            let (kind, recommended) = classify(&name, &s);
            out.push(NetInterface { name, ip: s, kind, recommended });
        }
    }
    out.sort_by(|a, b| b.recommended.cmp(&a.recommended).then(a.name.cmp(&b.name)));
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classification() {
        assert_eq!(classify("Wi-Fi", "192.168.1.5").0, "Wi-Fi");
        assert_eq!(classify("Ethernet 2", "10.0.0.4").0, "Ethernet");
        assert!(!classify("vEthernet (WSL)", "172.20.0.1").1);
        assert!(classify("Local Area Connection* 10", "192.168.137.1").1);
    }
}

use std::collections::HashMap;
use std::net::{IpAddr, SocketAddr};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::{ConnectInfo, State};
use axum::http::{header, HeaderMap, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::Router;
use futures_util::stream::SplitStream;
use futures_util::{SinkExt, StreamExt};
use rand::distributions::Alphanumeric;
use rand::{thread_rng, Rng};
use serde::Serialize;
use serde_json::{json, Value};
use tokio::sync::{mpsc, Notify};
use tokio::task::JoinHandle;

use crate::cert;
use crate::net::candidate_interfaces;

const MAX_MSG: usize = 262_144;
const IDLE_TIMEOUT: Duration = Duration::from_secs(60);
const CODE_LIFETIME: Duration = Duration::from_secs(4 * 3600);
const MAX_FAILURES: u32 = 5;
const FAILURE_WINDOW: Duration = Duration::from_secs(60);

#[derive(Debug, Clone)]
pub struct ServerConfig {
    pub lan_ip: IpAddr,
    pub port: u16,
    pub data_dir: std::path::PathBuf,
}

#[derive(Debug, Clone, Serialize)]
pub struct SharingInfo {
    pub ip: String,
    pub port: u16,
    pub base_url: String,
    /// URL that includes the pairing code in the fragment (never sent to the server). Encoded in the QR code.
    pub url: String,
    pub code: String,
    pub qr_svg: String,
    pub cert_url: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct AdminConn {
    pub ws_url: String,
    pub token: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct SharingStatus {
    pub running: bool,
    pub ip: String,
    pub port: u16,
    pub code: String,
    pub code_expired: bool,
    pub speaker_label: Option<String>,
    pub admin_connected: bool,
    pub audience_connected: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Role {
    Speaker,
    Admin,
    Audience,
}

impl Role {
    fn as_str(&self) -> &'static str {
        match self {
            Role::Speaker => "speaker",
            Role::Admin => "admin",
            Role::Audience => "audience",
        }
    }
}

struct Conn {
    id: u64,
    tx: mpsc::Sender<String>,
    label: String,
}

#[derive(Default)]
struct Hub {
    admin: Option<Conn>,
    audience: Option<Conn>,
    speaker: Option<Conn>,
    next_id: u64,
}

struct Shared {
    code: Mutex<(String, Instant)>,
    admin_token: String,
    hub: Mutex<Hub>,
    failures: Mutex<HashMap<IpAddr, (u32, Instant)>>,
    cert_pem: String,
    shutdown: Notify,
}

fn lk<T>(m: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|p| p.into_inner())
}

fn ct_eq(a: &str, b: &str) -> bool {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    if a.len() != b.len() {
        return false;
    }
    a.iter().zip(b.iter()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

fn new_code() -> String {
    thread_rng().gen_range(100_000u32..1_000_000u32).to_string()
}

fn new_token() -> String {
    thread_rng()
        .sample_iter(&Alphanumeric)
        .take(40)
        .map(char::from)
        .collect()
}

fn send(c: &Option<Conn>, msg: String) -> bool {
    match c {
        Some(c) => c.tx.try_send(msg).is_ok(),
        None => false,
    }
}

fn event(name: &str, extra: Value) -> String {
    let mut v = json!({ "type": "event", "event": name });
    if let (Some(o), Some(e)) = (v.as_object_mut(), extra.as_object()) {
        for (k, val) in e {
            o.insert(k.clone(), val.clone());
        }
    }
    v.to_string()
}

fn sanitize_label(s: &str) -> String {
    let cleaned: String = s.chars().filter(|c| !c.is_control()).collect();
    let t = cleaned.trim();
    let t: String = t.chars().take(40).collect();
    if t.is_empty() {
        "Speaker".to_string()
    } else {
        t
    }
}

// ---------------------------------------------------------------- HTTP

async fn index() -> impl IntoResponse {
    (
        [
            (header::CONTENT_TYPE, "text/html; charset=utf-8"),
            (header::CACHE_CONTROL, "no-store"),
            (header::X_FRAME_OPTIONS, "DENY"),
            (header::REFERRER_POLICY, "no-referrer"),
        ],
        include_str!("../web/speaker.html"),
    )
}

async fn speaker_js() -> impl IntoResponse {
    (
        [(header::CONTENT_TYPE, "text/javascript; charset=utf-8"), (header::CACHE_CONTROL, "no-store")],
        include_str!("../web/speaker.js"),
    )
}

async fn speaker_css() -> impl IntoResponse {
    (
        [(header::CONTENT_TYPE, "text/css; charset=utf-8"), (header::CACHE_CONTROL, "no-store")],
        include_str!("../web/speaker.css"),
    )
}

async fn cert_download(State(shared): State<Arc<Shared>>) -> impl IntoResponse {
    (
        [
            (header::CONTENT_TYPE, "application/x-pem-file".to_string()),
            (header::CONTENT_DISPOSITION, "attachment; filename=\"showflow-cert.pem\"".to_string()),
        ],
        shared.cert_pem.clone(),
    )
}

fn origin_ok(headers: &HeaderMap) -> bool {
    let origin = headers.get(header::ORIGIN).and_then(|v| v.to_str().ok());
    let host = headers.get(header::HOST).and_then(|v| v.to_str().ok());
    match (origin, host) {
        (None, _) => true, // non-browser client; the pairing code still applies
        (Some(o), Some(h)) => o.strip_prefix("https://").map(|x| x == h).unwrap_or(false),
        (Some(_), None) => false,
    }
}

async fn lan_ws(
    ws: WebSocketUpgrade,
    headers: HeaderMap,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    State(shared): State<Arc<Shared>>,
) -> Response {
    if !origin_ok(&headers) {
        return (StatusCode::FORBIDDEN, "bad origin").into_response();
    }
    ws.max_message_size(MAX_MSG)
        .on_upgrade(move |s| handle_socket(s, shared, true, peer))
}

async fn local_ws(
    ws: WebSocketUpgrade,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    State(shared): State<Arc<Shared>>,
) -> Response {
    ws.max_message_size(MAX_MSG)
        .on_upgrade(move |s| handle_socket(s, shared, false, peer))
}

// ---------------------------------------------------------------- signaling

async fn next_text(stream: &mut SplitStream<WebSocket>) -> Option<String> {
    loop {
        match stream.next().await {
            Some(Ok(Message::Text(t))) => return Some(t),
            Some(Ok(Message::Close(_))) | None | Some(Err(_)) => return None,
            Some(Ok(_)) => continue,
        }
    }
}

fn authenticate(shared: &Shared, lan: bool, v: &Value, ip: IpAddr) -> Result<(Role, String), String> {
    if v.get("type").and_then(|t| t.as_str()) != Some("hello") {
        return Err("expected hello".into());
    }
    let role_s = v.get("role").and_then(|r| r.as_str()).unwrap_or("");
    if lan {
        if role_s != "speaker" {
            return Err("role not allowed".into());
        }
        {
            let f = lk(&shared.failures);
            if let Some((n, since)) = f.get(&ip) {
                if *n >= MAX_FAILURES && since.elapsed() < FAILURE_WINDOW {
                    return Err("Too many wrong codes. Wait a minute and try again.".into());
                }
            }
        }
        let supplied = v.get("code").and_then(|c| c.as_str()).unwrap_or("");
        let (code, issued) = lk(&shared.code).clone();
        if issued.elapsed() > CODE_LIFETIME {
            return Err("This pairing code has expired. Ask the host for a new one.".into());
        }
        if !ct_eq(supplied, &code) {
            let mut f = lk(&shared.failures);
            let e = f.entry(ip).or_insert((0, Instant::now()));
            if e.1.elapsed() >= FAILURE_WINDOW {
                *e = (0, Instant::now());
            }
            e.0 += 1;
            return Err("Wrong pairing code.".into());
        }
        lk(&shared.failures).remove(&ip);
        let label = sanitize_label(v.get("label").and_then(|l| l.as_str()).unwrap_or(""));
        Ok((Role::Speaker, label))
    } else {
        let supplied = v.get("token").and_then(|c| c.as_str()).unwrap_or("");
        if !ct_eq(supplied, &shared.admin_token) {
            return Err("bad token".into());
        }
        match role_s {
            "admin" => Ok((Role::Admin, "admin".into())),
            "audience" => Ok((Role::Audience, "audience".into())),
            _ => Err("role not allowed".into()),
        }
    }
}

fn register(hub: &mut Hub, role: Role, tx: mpsc::Sender<String>, label: String) -> Result<u64, String> {
    hub.next_id += 1;
    let id = hub.next_id;
    let conn = Conn { id, tx, label: label.clone() };
    match role {
        Role::Speaker => {
            if let Some(existing) = &hub.speaker {
                if !existing.tx.is_closed() {
                    return Err("Another speaker is already connected.".into());
                }
            }
            hub.speaker = Some(conn);
            send(&hub.admin, event("speaker_connected", json!({ "label": label })));
        }
        Role::Admin => {
            hub.admin = Some(conn);
            if let Some(s) = &hub.speaker {
                let msg = event("speaker_connected", json!({ "label": s.label }));
                send(&hub.admin, msg);
            }
        }
        Role::Audience => {
            hub.audience = Some(conn);
            if hub.speaker.is_some() {
                send(&hub.speaker, event("audience_ready", json!({})));
            }
        }
    }
    Ok(id)
}

fn unregister(hub: &mut Hub, role: Role, id: u64) {
    match role {
        Role::Speaker => {
            if hub.speaker.as_ref().map(|c| c.id) == Some(id) {
                hub.speaker = None;
                send(&hub.admin, event("speaker_disconnected", json!({})));
                send(&hub.audience, event("speaker_disconnected", json!({})));
            }
        }
        Role::Admin => {
            if hub.admin.as_ref().map(|c| c.id) == Some(id) {
                hub.admin = None;
            }
        }
        Role::Audience => {
            if hub.audience.as_ref().map(|c| c.id) == Some(id) {
                hub.audience = None;
            }
        }
    }
}

fn route(hub: &Hub, role: Role, ty: &str, v: &Value, out: String, back: &mpsc::Sender<String>) {
    match (role, ty) {
        (Role::Speaker, "signal") => {
            let to = v.get("to").and_then(|t| t.as_str()).unwrap_or("");
            let ok = match to {
                "admin" => send(&hub.admin, out),
                "audience" => send(&hub.audience, out),
                _ => true,
            };
            if !ok {
                let _ = back.try_send(event("target_unavailable", json!({ "target": to })));
            }
        }
        (Role::Speaker, "share_request") => {
            send(&hub.admin, out);
        }
        (Role::Speaker, "share_stopped") => {
            send(&hub.admin, out.clone());
            send(&hub.audience, out);
        }
        (Role::Admin, "accept") => {
            send(&hub.speaker, out);
            if hub.audience.is_some() {
                send(&hub.speaker, event("audience_ready", json!({})));
            }
        }
        (Role::Admin, "reject") | (Role::Admin, "stop") => {
            send(&hub.speaker, out);
        }
        (Role::Admin, "signal") | (Role::Audience, "signal") => {
            send(&hub.speaker, out);
        }
        _ => {}
    }
}

async fn handle_socket(socket: WebSocket, shared: Arc<Shared>, lan: bool, peer: SocketAddr) {
    let (mut sink, mut stream) = socket.split();
    let (tx, mut rx) = mpsc::channel::<String>(256);
    let writer = tokio::spawn(async move {
        while let Some(m) = rx.recv().await {
            if sink.send(Message::Text(m)).await.is_err() {
                break;
            }
        }
    });

    let hello = match tokio::time::timeout(Duration::from_secs(10), next_text(&mut stream)).await {
        Ok(Some(t)) if t.len() <= 4096 => t,
        _ => {
            writer.abort();
            return;
        }
    };
    let parsed: Value = serde_json::from_str(&hello).unwrap_or(Value::Null);

    let (role, label) = match authenticate(&shared, lan, &parsed, peer.ip()) {
        Ok(r) => r,
        Err(msg) => {
            let _ = tx.send(json!({ "type": "error", "message": msg }).to_string()).await;
            drop(tx);
            let _ = writer.await;
            return;
        }
    };

    let reg = { register(&mut lk(&shared.hub), role, tx.clone(), label) };
    let id = match reg {
        Ok(id) => id,
        Err(msg) => {
            let _ = tx.send(json!({ "type": "error", "message": msg }).to_string()).await;
            drop(tx);
            let _ = writer.await;
            return;
        }
    };
    let _ = tx
        .send(json!({ "type": "welcome", "role": role.as_str() }).to_string())
        .await;

    let notified = shared.shutdown.notified();
    tokio::pin!(notified);
    loop {
        tokio::select! {
            _ = &mut notified => break,
            res = tokio::time::timeout(IDLE_TIMEOUT, next_text(&mut stream)) => {
                let text = match res { Ok(Some(t)) => t, _ => break };
                if text.len() > MAX_MSG { continue; }
                let mut v: Value = match serde_json::from_str(&text) { Ok(v) => v, Err(_) => continue };
                let ty = v.get("type").and_then(|t| t.as_str()).unwrap_or("").to_string();
                if ty == "ping" {
                    let _ = tx.try_send("{\"type\":\"pong\"}".to_string());
                    continue;
                }
                v["from"] = Value::String(role.as_str().to_string());
                let out = v.to_string();
                let hub = lk(&shared.hub);
                route(&hub, role, &ty, &v, out, &tx);
            }
        }
    }

    unregister(&mut lk(&shared.hub), role, id);
    drop(tx);
    writer.abort();
}

// ---------------------------------------------------------------- server lifecycle

pub struct SharingServer {
    shared: Arc<Shared>,
    ip: IpAddr,
    port: u16,
    local_port: u16,
    tls_task: JoinHandle<()>,
    local_task: JoinHandle<()>,
}

impl SharingServer {
    pub async fn start(cfg: ServerConfig) -> Result<SharingServer, String> {
        let _ = rustls::crypto::ring::default_provider().install_default();

        let sans = vec![
            cfg.lan_ip.to_string(),
            "127.0.0.1".to_string(),
            "localhost".to_string(),
            "showflow.local".to_string(),
        ];
        let tls = cert::load_or_create(&cfg.data_dir, &sans)?;
        let rustls_cfg = axum_server::tls_rustls::RustlsConfig::from_pem(
            tls.cert_pem.clone().into_bytes(),
            tls.key_pem.into_bytes(),
        )
        .await
        .map_err(|e| format!("TLS configuration error: {e}"))?;

        let addr = SocketAddr::new(cfg.lan_ip, cfg.port);
        std::net::TcpListener::bind(addr)
            .map_err(|e| format!("Cannot listen on {addr}: {e}. Another program may be using this port."))?;

        let shared = Arc::new(Shared {
            code: Mutex::new((new_code(), Instant::now())),
            admin_token: new_token(),
            hub: Mutex::new(Hub::default()),
            failures: Mutex::new(HashMap::new()),
            cert_pem: tls.cert_pem,
            shutdown: Notify::new(),
        });

        let lan_app = Router::new()
            .route("/", get(index))
            .route("/speaker.js", get(speaker_js))
            .route("/speaker.css", get(speaker_css))
            .route("/cert.pem", get(cert_download))
            .route("/ws", get(lan_ws))
            .with_state(shared.clone());

        let local_app = Router::new().route("/ws", get(local_ws)).with_state(shared.clone());

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0")
            .await
            .map_err(|e| format!("Cannot open local control socket: {e}"))?;
        let local_port = listener.local_addr().map_err(|e| e.to_string())?.port();

        let local_task = tokio::spawn(async move {
            let _ = axum::serve(listener, local_app.into_make_service_with_connect_info::<SocketAddr>()).await;
        });
        let tls_task = tokio::spawn(async move {
            let _ = axum_server::bind_rustls(addr, rustls_cfg)
                .serve(lan_app.into_make_service_with_connect_info::<SocketAddr>())
                .await;
        });

        tracing::info!("speaker sharing listening on https://{addr} (control on 127.0.0.1:{local_port})");
        Ok(SharingServer {
            shared,
            ip: cfg.lan_ip,
            port: cfg.port,
            local_port,
            tls_task,
            local_task,
        })
    }

    pub fn info(&self) -> SharingInfo {
        let code = lk(&self.shared.code).0.clone();
        let base_url = format!("https://{}:{}", self.ip, self.port);
        let url = format!("{base_url}/#c={code}");
        SharingInfo {
            ip: self.ip.to_string(),
            port: self.port,
            base_url: base_url.clone(),
            qr_svg: qr_svg(&url),
            url,
            code,
            cert_url: format!("{base_url}/cert.pem"),
        }
    }

    pub fn admin_conn(&self) -> AdminConn {
        AdminConn {
            ws_url: format!("ws://127.0.0.1:{}/ws", self.local_port),
            token: self.shared.admin_token.clone(),
        }
    }

    pub fn status(&self) -> SharingStatus {
        let (code, issued) = lk(&self.shared.code).clone();
        let hub = lk(&self.shared.hub);
        SharingStatus {
            running: true,
            ip: self.ip.to_string(),
            port: self.port,
            code,
            code_expired: issued.elapsed() > CODE_LIFETIME,
            speaker_label: hub.speaker.as_ref().map(|s| s.label.clone()),
            admin_connected: hub.admin.is_some(),
            audience_connected: hub.audience.is_some(),
        }
    }

    /// Issue a fresh pairing code. A speaker that is already connected stays connected.
    pub fn regenerate_code(&self) -> String {
        let c = new_code();
        *lk(&self.shared.code) = (c.clone(), Instant::now());
        lk(&self.shared.failures).clear();
        c
    }

    pub fn stop(self) {
        self.shared.shutdown.notify_waiters();
        {
            let mut hub = lk(&self.shared.hub);
            hub.admin = None;
            hub.audience = None;
            hub.speaker = None;
        }
        self.tls_task.abort();
        self.local_task.abort();
    }
}

pub fn qr_svg(text: &str) -> String {
    use qrcode::render::svg;
    use qrcode::QrCode;
    match QrCode::new(text.as_bytes()) {
        Ok(code) => code
            .render::<svg::Color>()
            .min_dimensions(220, 220)
            .quiet_zone(true)
            .build(),
        Err(_) => String::new(),
    }
}

/// Helper for the UI: is the chosen IP still one of this PC's private addresses?
pub fn ip_is_candidate(ip: &str) -> bool {
    candidate_interfaces().iter().any(|i| i.ip == ip)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn shared() -> Shared {
        Shared {
            code: Mutex::new(("123456".into(), Instant::now())),
            admin_token: "tok".into(),
            hub: Mutex::new(Hub::default()),
            failures: Mutex::new(HashMap::new()),
            cert_pem: String::new(),
            shutdown: Notify::new(),
        }
    }

    #[test]
    fn constant_time_compare() {
        assert!(ct_eq("abc", "abc"));
        assert!(!ct_eq("abc", "abd"));
        assert!(!ct_eq("abc", "abcd"));
    }

    #[test]
    fn code_validation_and_rate_limit() {
        let s = shared();
        let ip: IpAddr = "192.168.1.9".parse().unwrap();
        let good = json!({"type":"hello","role":"speaker","code":"123456","label":"Al"});
        let bad = json!({"type":"hello","role":"speaker","code":"000000"});
        assert!(authenticate(&s, true, &good, ip).is_ok());
        for _ in 0..MAX_FAILURES {
            assert!(authenticate(&s, true, &bad, ip).is_err());
        }
        // locked out even with the right code
        assert!(authenticate(&s, true, &good, ip).is_err());
    }

    #[test]
    fn local_requires_token_and_roles() {
        let s = shared();
        let ip: IpAddr = "127.0.0.1".parse().unwrap();
        assert!(authenticate(&s, false, &json!({"type":"hello","role":"admin","token":"tok"}), ip).is_ok());
        assert!(authenticate(&s, false, &json!({"type":"hello","role":"admin","token":"x"}), ip).is_err());
        assert!(authenticate(&s, false, &json!({"type":"hello","role":"speaker","token":"tok"}), ip).is_err());
        // LAN endpoint never accepts admin role
        assert!(authenticate(&s, true, &json!({"type":"hello","role":"admin","code":"123456"}), ip).is_err());
    }

    #[test]
    fn only_one_speaker() {
        let mut hub = Hub::default();
        let (tx1, _rx1) = mpsc::channel(4);
        let (tx2, _rx2) = mpsc::channel(4);
        assert!(register(&mut hub, Role::Speaker, tx1, "A".into()).is_ok());
        assert!(register(&mut hub, Role::Speaker, tx2, "B".into()).is_err());
    }

    #[test]
    fn label_sanitized() {
        assert_eq!(sanitize_label("  \u{0007}Alex  "), "Alex");
        assert_eq!(sanitize_label(""), "Speaker");
        assert_eq!(sanitize_label(&"x".repeat(100)).len(), 40);
    }

    #[test]
    fn qr_is_svg() {
        assert!(qr_svg("https://192.168.1.2:8443/#c=123456").contains("<svg"));
    }
}

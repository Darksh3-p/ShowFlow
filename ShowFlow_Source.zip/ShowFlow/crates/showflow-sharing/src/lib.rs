//! Local-network speaker screen sharing: HTTPS speaker page + WebSocket signaling hub.
//! Media (WebRTC) flows browser <-> WebView2 directly; this crate only relays signaling.
pub mod cert;
pub mod net;
pub mod server;

pub use net::{candidate_interfaces, NetInterface};
pub use server::{AdminConn, ServerConfig, SharingInfo, SharingServer, SharingStatus};

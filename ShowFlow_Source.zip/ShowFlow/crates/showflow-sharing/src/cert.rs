//! Self-signed TLS certificate for the speaker page (needed for browser screen capture on a LAN).
//! The certificate is persisted so speakers only need to accept it once per host IP.
//! The private key is stored in the user's app-data folder (per-user ACL). DPAPI wrapping is a documented future hardening.
use std::path::Path;

use rcgen::{CertificateParams, DnType, KeyPair};

pub struct TlsMaterial {
    pub cert_pem: String,
    pub key_pem: String,
}

fn sorted(v: &[String]) -> Vec<String> {
    let mut s = v.to_vec();
    s.sort();
    s.dedup();
    s
}

pub fn load_or_create(dir: &Path, sans: &[String]) -> Result<TlsMaterial, String> {
    std::fs::create_dir_all(dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
    let cert_path = dir.join("cert.pem");
    let key_path = dir.join("key.pem");
    let sans_path = dir.join("sans.json");
    let wanted = sorted(sans);

    if let (Ok(c), Ok(k), Ok(s)) = (
        std::fs::read_to_string(&cert_path),
        std::fs::read_to_string(&key_path),
        std::fs::read_to_string(&sans_path),
    ) {
        if let Ok(stored) = serde_json::from_str::<Vec<String>>(&s) {
            if wanted.iter().all(|w| stored.contains(w)) {
                return Ok(TlsMaterial { cert_pem: c, key_pem: k });
            }
        }
    }

    let mut params = CertificateParams::new(wanted.clone()).map_err(|e| format!("certificate params: {e}"))?;
    params.distinguished_name.push(DnType::CommonName, "ShowFlow Local Speaker Share");
    params.not_before = rcgen::date_time_ymd(2025, 1, 1);
    params.not_after = rcgen::date_time_ymd(2032, 1, 1);
    let key_pair = KeyPair::generate().map_err(|e| format!("key generation: {e}"))?;
    let cert = params
        .self_signed(&key_pair)
        .map_err(|e| format!("certificate generation: {e}"))?;
    let material = TlsMaterial {
        cert_pem: cert.pem(),
        key_pem: key_pair.serialize_pem(),
    };
    std::fs::write(&cert_path, &material.cert_pem).map_err(|e| e.to_string())?;
    std::fs::write(&key_path, &material.key_pem).map_err(|e| e.to_string())?;
    std::fs::write(&sans_path, serde_json::to_string(&wanted).unwrap_or_default()).map_err(|e| e.to_string())?;
    Ok(material)
}

use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use rusqlite::{params, Connection, OptionalExtension, Row};

use crate::error::{CoreError, Result};
use crate::media::{media_type_for, ScannedFile};
use crate::models::*;
use crate::playlist::move_index;

const MIGRATIONS: &[&str] = &[
    // v1
    "CREATE TABLE media_files(
        id INTEGER PRIMARY KEY,
        path TEXT NOT NULL UNIQUE,
        filename TEXT NOT NULL,
        media_type TEXT NOT NULL,
        size_bytes INTEGER NOT NULL DEFAULT 0,
        duration_ms INTEGER,
        modified_at INTEGER NOT NULL DEFAULT 0,
        folder_root TEXT NOT NULL DEFAULT ''
     );
     CREATE TABLE playlists(
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        folder_root TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
     );
     CREATE TABLE playlist_items(
        id INTEGER PRIMARY KEY,
        playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
        media_file_id INTEGER NOT NULL REFERENCES media_files(id) ON DELETE RESTRICT,
        position INTEGER NOT NULL,
        auto_advance INTEGER NOT NULL DEFAULT 0,
        looped INTEGER NOT NULL DEFAULT 0,
        volume REAL NOT NULL DEFAULT 1.0,
        start_position_ms INTEGER,
        image_duration_secs INTEGER
     );
     CREATE INDEX idx_items_playlist ON playlist_items(playlist_id, position);
     CREATE TABLE kv(key TEXT PRIMARY KEY, value TEXT NOT NULL);",
];

fn now() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

pub struct Database {
    conn: Connection,
}

const MEDIA_COLS: &str =
    "id, path, filename, media_type, size_bytes, duration_ms, modified_at, folder_root";

fn media_from_row(row: &Row, off: usize) -> rusqlite::Result<MediaFile> {
    let t: String = row.get(off + 3)?;
    let media_type = MediaType::parse(&t).ok_or_else(|| {
        rusqlite::Error::InvalidColumnType(off + 3, "media_type".into(), rusqlite::types::Type::Text)
    })?;
    let path: String = row.get(off + 1)?;
    let available = Path::new(&path).exists();
    Ok(MediaFile {
        id: row.get(off)?,
        path,
        filename: row.get(off + 2)?,
        media_type,
        size_bytes: row.get(off + 4)?,
        duration_ms: row.get(off + 5)?,
        modified_at: row.get(off + 6)?,
        folder_root: row.get(off + 7)?,
        available,
    })
}

fn item_from_row(row: &Row) -> rusqlite::Result<PlaylistItem> {
    Ok(PlaylistItem {
        id: row.get(0)?,
        playlist_id: row.get(1)?,
        media_file_id: row.get(2)?,
        position: row.get(3)?,
        auto_advance: row.get::<_, i64>(4)? != 0,
        looped: row.get::<_, i64>(5)? != 0,
        volume: row.get(6)?,
        start_position_ms: row.get(7)?,
        image_duration_secs: row.get(8)?,
    })
}

const ENTRY_SQL: &str = "SELECT i.id, i.playlist_id, i.media_file_id, i.position, i.auto_advance, i.looped, i.volume,
        i.start_position_ms, i.image_duration_secs,
        m.id, m.path, m.filename, m.media_type, m.size_bytes, m.duration_ms, m.modified_at, m.folder_root
     FROM playlist_items i JOIN media_files m ON m.id = i.media_file_id";

impl Database {
    pub fn open(path: &Path) -> Result<Self> {
        Self::init(Connection::open(path)?)
    }

    pub fn open_in_memory() -> Result<Self> {
        Self::init(Connection::open_in_memory()?)
    }

    fn init(mut conn: Connection) -> Result<Self> {
        conn.execute_batch("PRAGMA foreign_keys = ON;")?;
        let _mode: String = conn.query_row("PRAGMA journal_mode = WAL", [], |r| r.get(0))?;
        let version: i64 = conn.query_row("PRAGMA user_version", [], |r| r.get(0))?;
        for (i, sql) in MIGRATIONS.iter().enumerate() {
            let v = (i + 1) as i64;
            if v > version {
                let tx = conn.transaction()?;
                tx.execute_batch(sql)?;
                tx.execute_batch(&format!("PRAGMA user_version = {v};"))?;
                tx.commit()?;
            }
        }
        Ok(Database { conn })
    }

    // ---------- key/value + typed settings ----------
    pub fn get_kv(&self, key: &str) -> Result<Option<String>> {
        Ok(self
            .conn
            .query_row("SELECT value FROM kv WHERE key = ?1", params![key], |r| r.get(0))
            .optional()?)
    }

    pub fn set_kv(&self, key: &str, value: &str) -> Result<()> {
        self.conn.execute(
            "INSERT INTO kv(key, value) VALUES (?1, ?2) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            params![key, value],
        )?;
        Ok(())
    }

    pub fn load_settings(&self) -> Result<Settings> {
        match self.get_kv("settings")? {
            Some(s) => Ok(serde_json::from_str(&s).unwrap_or_default()),
            None => Ok(Settings::default()),
        }
    }

    pub fn save_settings(&self, s: &Settings) -> Result<()> {
        self.set_kv("settings", &serde_json::to_string(s)?)
    }

    pub fn load_idle(&self) -> Result<IdleConfig> {
        match self.get_kv("idle")? {
            Some(s) => Ok(serde_json::from_str(&s).unwrap_or_default()),
            None => Ok(IdleConfig::default()),
        }
    }

    pub fn save_idle(&self, c: &IdleConfig) -> Result<()> {
        self.set_kv("idle", &serde_json::to_string(c)?)
    }

    // ---------- media ----------
    pub fn upsert_scanned(&mut self, folder_root: &str, files: &[ScannedFile]) -> Result<Vec<MediaFile>> {
        let tx = self.conn.transaction()?;
        let mut ids = Vec::with_capacity(files.len());
        {
            let mut up = tx.prepare(
                "INSERT INTO media_files(path, filename, media_type, size_bytes, modified_at, folder_root)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)
                 ON CONFLICT(path) DO UPDATE SET filename = excluded.filename,
                    media_type = excluded.media_type, size_bytes = excluded.size_bytes,
                    modified_at = excluded.modified_at, folder_root = excluded.folder_root",
            )?;
            for f in files {
                up.execute(params![
                    f.path,
                    f.filename,
                    f.media_type.as_str(),
                    f.size_bytes,
                    f.modified_at,
                    folder_root
                ])?;
            }
            let mut sel = tx.prepare("SELECT id FROM media_files WHERE path = ?1")?;
            for f in files {
                let id: i64 = sel.query_row(params![f.path], |r| r.get(0))?;
                ids.push(id);
            }
        }
        tx.commit()?;
        ids.iter().map(|id| self.get_media(*id)).collect()
    }

    pub fn get_media(&self, id: i64) -> Result<MediaFile> {
        self.conn
            .query_row(
                &format!("SELECT {MEDIA_COLS} FROM media_files WHERE id = ?1"),
                params![id],
                |r| media_from_row(r, 0),
            )
            .optional()?
            .ok_or_else(|| CoreError::NotFound(format!("media {id}")))
    }

    pub fn set_duration(&self, id: i64, duration_ms: i64) -> Result<()> {
        self.conn.execute(
            "UPDATE media_files SET duration_ms = ?1 WHERE id = ?2",
            params![duration_ms, id],
        )?;
        Ok(())
    }

    /// Point a media record at a new file location (for missing files).
    pub fn relink_media(&mut self, media_id: i64, new_path: &str) -> Result<MediaFile> {
        let p = Path::new(new_path);
        let media_type = media_type_for(p)
            .ok_or_else(|| CoreError::Invalid("unsupported file type".into()))?;
        if !p.is_file() {
            return Err(CoreError::Invalid("file does not exist".into()));
        }
        let filename = p
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();
        let existing: Option<i64> = self
            .conn
            .query_row(
                "SELECT id FROM media_files WHERE path = ?1 AND id != ?2",
                params![new_path, media_id],
                |r| r.get(0),
            )
            .optional()?;
        let tx = self.conn.transaction()?;
        let final_id = if let Some(other) = existing {
            tx.execute(
                "UPDATE playlist_items SET media_file_id = ?1 WHERE media_file_id = ?2",
                params![other, media_id],
            )?;
            other
        } else {
            tx.execute(
                "UPDATE media_files SET path = ?1, filename = ?2, media_type = ?3 WHERE id = ?4",
                params![new_path, filename, media_type.as_str(), media_id],
            )?;
            media_id
        };
        tx.commit()?;
        self.get_media(final_id)
    }

    // ---------- playlists ----------
    fn touch(&self, playlist_id: i64) -> Result<()> {
        self.conn.execute(
            "UPDATE playlists SET updated_at = ?1 WHERE id = ?2",
            params![now(), playlist_id],
        )?;
        Ok(())
    }

    pub fn create_playlist(&self, name: &str, folder_root: Option<&str>) -> Result<Playlist> {
        let name = name.trim();
        if name.is_empty() {
            return Err(CoreError::Invalid("playlist name is empty".into()));
        }
        let t = now();
        self.conn.execute(
            "INSERT INTO playlists(name, folder_root, created_at, updated_at) VALUES (?1, ?2, ?3, ?3)",
            params![name, folder_root, t],
        )?;
        self.get_playlist(self.conn.last_insert_rowid())
    }

    pub fn get_playlist(&self, id: i64) -> Result<Playlist> {
        self.conn
            .query_row(
                "SELECT p.id, p.name, p.folder_root, p.created_at, p.updated_at,
                        (SELECT COUNT(*) FROM playlist_items WHERE playlist_id = p.id)
                 FROM playlists p WHERE p.id = ?1",
                params![id],
                |r| {
                    Ok(Playlist {
                        id: r.get(0)?,
                        name: r.get(1)?,
                        folder_root: r.get(2)?,
                        created_at: r.get(3)?,
                        updated_at: r.get(4)?,
                        item_count: r.get(5)?,
                    })
                },
            )
            .optional()?
            .ok_or_else(|| CoreError::NotFound(format!("playlist {id}")))
    }

    pub fn list_playlists(&self) -> Result<Vec<Playlist>> {
        let mut stmt = self.conn.prepare("SELECT id FROM playlists ORDER BY updated_at DESC, id DESC")?;
        let ids: Vec<i64> = stmt
            .query_map([], |r| r.get(0))?
            .collect::<rusqlite::Result<Vec<i64>>>()?;
        ids.into_iter().map(|id| self.get_playlist(id)).collect()
    }

    pub fn rename_playlist(&self, id: i64, name: &str) -> Result<()> {
        let name = name.trim();
        if name.is_empty() {
            return Err(CoreError::Invalid("playlist name is empty".into()));
        }
        self.conn
            .execute("UPDATE playlists SET name = ?1, updated_at = ?2 WHERE id = ?3", params![name, now(), id])?;
        Ok(())
    }

    pub fn delete_playlist(&self, id: i64) -> Result<()> {
        self.conn.execute("DELETE FROM playlists WHERE id = ?1", params![id])?;
        Ok(())
    }

    pub fn duplicate_playlist(&self, id: i64) -> Result<Playlist> {
        let src = self.get_playlist(id)?;
        let copy = self.create_playlist(&format!("{} (copy)", src.name), src.folder_root.as_deref())?;
        self.conn.execute(
            "INSERT INTO playlist_items(playlist_id, media_file_id, position, auto_advance, looped, volume, start_position_ms, image_duration_secs)
             SELECT ?1, media_file_id, position, auto_advance, looped, volume, start_position_ms, image_duration_secs
             FROM playlist_items WHERE playlist_id = ?2",
            params![copy.id, id],
        )?;
        self.get_playlist(copy.id)
    }

    pub fn playlist_entries(&self, playlist_id: i64) -> Result<Vec<PlaylistEntry>> {
        let mut stmt = self
            .conn
            .prepare(&format!("{ENTRY_SQL} WHERE i.playlist_id = ?1 ORDER BY i.position, i.id"))?;
        let rows = stmt.query_map(params![playlist_id], |r| {
            Ok(PlaylistEntry {
                item: item_from_row(r)?,
                media: media_from_row(r, 9)?,
            })
        })?;
        Ok(rows.collect::<rusqlite::Result<Vec<_>>>()?)
    }

    fn next_position(&self, playlist_id: i64) -> Result<i64> {
        let max: Option<i64> = self.conn.query_row(
            "SELECT MAX(position) FROM playlist_items WHERE playlist_id = ?1",
            params![playlist_id],
            |r| r.get(0),
        )?;
        Ok(max.map(|m| m + 1).unwrap_or(0))
    }

    pub fn add_items(&mut self, playlist_id: i64, media_ids: &[i64]) -> Result<Vec<i64>> {
        self.get_playlist(playlist_id)?;
        let mut pos = self.next_position(playlist_id)?;
        let tx = self.conn.transaction()?;
        let mut new_ids = Vec::new();
        for mid in media_ids {
            tx.execute(
                "INSERT INTO playlist_items(playlist_id, media_file_id, position) VALUES (?1, ?2, ?3)",
                params![playlist_id, mid, pos],
            )?;
            new_ids.push(tx.last_insert_rowid());
            pos += 1;
        }
        tx.commit()?;
        self.touch(playlist_id)?;
        Ok(new_ids)
    }

    fn item_playlist(&self, item_id: i64) -> Result<i64> {
        self.conn
            .query_row("SELECT playlist_id FROM playlist_items WHERE id = ?1", params![item_id], |r| r.get(0))
            .optional()?
            .ok_or_else(|| CoreError::NotFound(format!("item {item_id}")))
    }

    fn renumber(&mut self, playlist_id: i64, ordered_ids: &[i64]) -> Result<()> {
        let tx = self.conn.transaction()?;
        for (i, id) in ordered_ids.iter().enumerate() {
            tx.execute("UPDATE playlist_items SET position = ?1 WHERE id = ?2", params![i as i64, id])?;
        }
        tx.commit()?;
        self.touch(playlist_id)
    }

    fn ordered_item_ids(&self, playlist_id: i64) -> Result<Vec<i64>> {
        let mut stmt = self
            .conn
            .prepare("SELECT id FROM playlist_items WHERE playlist_id = ?1 ORDER BY position, id")?;
        let ids = stmt
            .query_map(params![playlist_id], |r| r.get(0))?
            .collect::<rusqlite::Result<Vec<i64>>>()?;
        Ok(ids)
    }

    pub fn remove_item(&mut self, item_id: i64) -> Result<()> {
        let pid = self.item_playlist(item_id)?;
        self.conn.execute("DELETE FROM playlist_items WHERE id = ?1", params![item_id])?;
        let ids = self.ordered_item_ids(pid)?;
        self.renumber(pid, &ids)
    }

    pub fn clear_playlist(&self, playlist_id: i64) -> Result<()> {
        self.conn
            .execute("DELETE FROM playlist_items WHERE playlist_id = ?1", params![playlist_id])?;
        self.touch(playlist_id)
    }

    pub fn move_item(&mut self, item_id: i64, new_index: usize) -> Result<()> {
        let pid = self.item_playlist(item_id)?;
        let mut ids = self.ordered_item_ids(pid)?;
        let from = ids
            .iter()
            .position(|i| *i == item_id)
            .ok_or_else(|| CoreError::NotFound(format!("item {item_id}")))?;
        move_index(&mut ids, from, new_index)?;
        self.renumber(pid, &ids)
    }

    pub fn duplicate_item(&mut self, item_id: i64) -> Result<i64> {
        let pid = self.item_playlist(item_id)?;
        self.conn.execute(
            "INSERT INTO playlist_items(playlist_id, media_file_id, position, auto_advance, looped, volume, start_position_ms, image_duration_secs)
             SELECT playlist_id, media_file_id, position, auto_advance, looped, volume, start_position_ms, image_duration_secs
             FROM playlist_items WHERE id = ?1",
            params![item_id],
        )?;
        let new_id = self.conn.last_insert_rowid();
        // Place the copy directly after the original.
        let mut ids = self.ordered_item_ids(pid)?;
        ids.retain(|i| *i != new_id);
        let at = ids.iter().position(|i| *i == item_id).map(|p| p + 1).unwrap_or(ids.len());
        ids.insert(at, new_id);
        self.renumber(pid, &ids)?;
        Ok(new_id)
    }

    pub fn update_item_options(&self, item_id: i64, o: &ItemOptions) -> Result<()> {
        let vol = o.volume.clamp(0.0, 1.0);
        let n = self.conn.execute(
            "UPDATE playlist_items SET auto_advance = ?1, looped = ?2, volume = ?3,
                start_position_ms = ?4, image_duration_secs = ?5 WHERE id = ?6",
            params![o.auto_advance as i64, o.looped as i64, vol, o.start_position_ms, o.image_duration_secs, item_id],
        )?;
        if n == 0 {
            return Err(CoreError::NotFound(format!("item {item_id}")));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scanned(name: &str, t: MediaType) -> ScannedFile {
        ScannedFile {
            path: format!("C:\\media\\{name}"),
            filename: name.to_string(),
            media_type: t,
            size_bytes: 10,
            modified_at: 1,
        }
    }

    fn setup() -> (Database, Vec<MediaFile>, Playlist) {
        let mut db = Database::open_in_memory().unwrap();
        let media = db
            .upsert_scanned(
                "C:\\media",
                &[
                    scanned("a.pptx", MediaType::Presentation),
                    scanned("b.mp4", MediaType::Video),
                    scanned("c.png", MediaType::Image),
                ],
            )
            .unwrap();
        let pl = db.create_playlist("Show", Some("C:\\media")).unwrap();
        (db, media, pl)
    }

    #[test]
    fn upsert_is_idempotent() {
        let (mut db, media, _) = setup();
        let again = db
            .upsert_scanned("C:\\media", &[scanned("a.pptx", MediaType::Presentation)])
            .unwrap();
        assert_eq!(again[0].id, media[0].id);
    }

    #[test]
    fn playlist_order_and_move() {
        let (mut db, media, pl) = setup();
        let ids: Vec<i64> = media.iter().map(|m| m.id).collect();
        let item_ids = db.add_items(pl.id, &ids).unwrap();
        let e = db.playlist_entries(pl.id).unwrap();
        assert_eq!(e.iter().map(|x| x.media.filename.as_str()).collect::<Vec<_>>(), ["a.pptx", "b.mp4", "c.png"]);
        db.move_item(item_ids[2], 0).unwrap();
        let e = db.playlist_entries(pl.id).unwrap();
        assert_eq!(e[0].media.filename, "c.png");
        assert_eq!(e[2].media.filename, "b.mp4");
        assert_eq!(e.iter().map(|x| x.item.position).collect::<Vec<_>>(), [0, 1, 2]);
    }

    #[test]
    fn remove_duplicate_clear() {
        let (mut db, media, pl) = setup();
        let ids: Vec<i64> = media.iter().map(|m| m.id).collect();
        let items = db.add_items(pl.id, &ids).unwrap();
        db.remove_item(items[1]).unwrap();
        assert_eq!(db.playlist_entries(pl.id).unwrap().len(), 2);
        let new_id = db.duplicate_item(items[0]).unwrap();
        let e = db.playlist_entries(pl.id).unwrap();
        assert_eq!(e.len(), 3);
        assert_eq!(e[1].item.id, new_id);
        db.clear_playlist(pl.id).unwrap();
        assert!(db.playlist_entries(pl.id).unwrap().is_empty());
    }

    #[test]
    fn duplicate_playlist_copies_items() {
        let (mut db, media, pl) = setup();
        db.add_items(pl.id, &[media[0].id, media[1].id]).unwrap();
        let copy = db.duplicate_playlist(pl.id).unwrap();
        assert_eq!(copy.item_count, 2);
        assert!(copy.name.contains("(copy)"));
        db.delete_playlist(pl.id).unwrap();
        assert_eq!(db.playlist_entries(copy.id).unwrap().len(), 2);
    }

    #[test]
    fn options_and_settings_roundtrip() {
        let (mut db, media, pl) = setup();
        let items = db.add_items(pl.id, &[media[1].id]).unwrap();
        db.update_item_options(
            items[0],
            &ItemOptions { auto_advance: true, looped: true, volume: 7.0, start_position_ms: Some(500), image_duration_secs: None },
        )
        .unwrap();
        let e = db.playlist_entries(pl.id).unwrap();
        assert!(e[0].item.auto_advance && e[0].item.looped);
        assert_eq!(e[0].item.volume, 1.0); // clamped
        assert_eq!(e[0].item.start_position_ms, Some(500));

        let mut s = db.load_settings().unwrap();
        assert_eq!(s.share_port, 8443);
        s.share_port = 9000;
        db.save_settings(&s).unwrap();
        assert_eq!(db.load_settings().unwrap().share_port, 9000);
    }

    #[test]
    fn empty_name_rejected() {
        let db = Database::open_in_memory().unwrap();
        assert!(db.create_playlist("   ", None).is_err());
    }
}

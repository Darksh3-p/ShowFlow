use crate::error::{CoreError, Result};

/// Move element `from` to index `to` (both must be in range).
pub fn move_index<T>(v: &mut Vec<T>, from: usize, to: usize) -> Result<()> {
    if from >= v.len() || to >= v.len() {
        return Err(CoreError::Invalid(format!(
            "index out of range (from={from}, to={to}, len={})",
            v.len()
        )));
    }
    let item = v.remove(from);
    v.insert(to, item);
    Ok(())
}

/// Next/previous index. `delta` is +1 or -1 (any step works). Returns None when out of range.
pub fn step(current: Option<usize>, len: usize, delta: i64) -> Option<usize> {
    if len == 0 {
        return None;
    }
    match current {
        None => {
            if delta >= 0 {
                Some(0)
            } else {
                None
            }
        }
        Some(c) => {
            let n = c as i64 + delta;
            if n < 0 || n >= len as i64 {
                None
            } else {
                Some(n as usize)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn moves() {
        let mut v = vec![1, 2, 3, 4];
        move_index(&mut v, 0, 2).unwrap();
        assert_eq!(v, vec![2, 3, 1, 4]);
        move_index(&mut v, 3, 0).unwrap();
        assert_eq!(v, vec![4, 2, 3, 1]);
        assert!(move_index(&mut v, 9, 0).is_err());
        assert!(move_index(&mut v, 0, 4).is_err());
    }

    #[test]
    fn stepping() {
        assert_eq!(step(None, 3, 1), Some(0));
        assert_eq!(step(None, 3, -1), None);
        assert_eq!(step(Some(0), 3, 1), Some(1));
        assert_eq!(step(Some(2), 3, 1), None);
        assert_eq!(step(Some(0), 3, -1), None);
        assert_eq!(step(Some(1), 3, -1), Some(0));
        assert_eq!(step(None, 0, 1), None);
    }
}

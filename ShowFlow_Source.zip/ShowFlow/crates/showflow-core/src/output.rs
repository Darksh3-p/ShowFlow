//! Output state machine. Pure logic: it validates transitions; the app performs the side effects.
use serde::{Deserialize, Serialize};

use crate::error::{CoreError, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OutputSource {
    None,
    #[serde(rename = "powerpoint")]
    PowerPoint,
    Video,
    Image,
    SpeakerShare,
    #[serde(rename = "idle_powerpoint")]
    IdlePowerPoint,
    IdleVideo,
    IdleImage,
    Black,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PlaybackState {
    Idle,
    Loading,
    Live,
    Paused,
    Completed,
    Error,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutputState {
    pub source: OutputSource,
    pub playback: PlaybackState,
    pub item_id: Option<i64>,
    pub message: Option<String>,
}

#[derive(Debug)]
pub struct OutputController {
    state: OutputState,
}

impl Default for OutputController {
    fn default() -> Self {
        Self::new()
    }
}

impl OutputController {
    pub fn new() -> Self {
        OutputController {
            state: OutputState {
                source: OutputSource::None,
                playback: PlaybackState::Idle,
                item_id: None,
                message: None,
            },
        }
    }

    pub fn state(&self) -> &OutputState {
        &self.state
    }

    /// Start switching to `target`. Returns the previous source, which the caller must stop.
    pub fn begin_switch(&mut self, target: OutputSource, item_id: Option<i64>) -> Result<OutputSource> {
        let prev = self.state.source;
        self.state = OutputState {
            source: target,
            playback: PlaybackState::Loading,
            item_id,
            message: None,
        };
        Ok(prev)
    }

    pub fn mark_live(&mut self) -> Result<()> {
        if self.state.playback != PlaybackState::Loading {
            return Err(CoreError::State(format!(
                "cannot go live from {:?}",
                self.state.playback
            )));
        }
        self.state.playback = PlaybackState::Live;
        Ok(())
    }

    pub fn mark_paused(&mut self, paused: bool) -> Result<()> {
        match (self.state.playback, paused) {
            (PlaybackState::Live, true) => {
                self.state.playback = PlaybackState::Paused;
                Ok(())
            }
            (PlaybackState::Paused, false) => {
                self.state.playback = PlaybackState::Live;
                Ok(())
            }
            (PlaybackState::Live, false) | (PlaybackState::Paused, true) => Ok(()),
            (s, _) => Err(CoreError::State(format!("cannot pause/resume from {s:?}"))),
        }
    }

    pub fn mark_completed(&mut self) -> Result<()> {
        if self.state.playback != PlaybackState::Live {
            return Err(CoreError::State(format!(
                "cannot complete from {:?}",
                self.state.playback
            )));
        }
        self.state.playback = PlaybackState::Completed;
        Ok(())
    }

    pub fn mark_error(&mut self, message: String) {
        self.state.playback = PlaybackState::Error;
        self.state.message = Some(message);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn source_names_match_frontend() {
        assert_eq!(serde_json::to_string(&OutputSource::PowerPoint).unwrap(), "\"powerpoint\"");
        assert_eq!(serde_json::to_string(&OutputSource::IdlePowerPoint).unwrap(), "\"idle_powerpoint\"");
        assert_eq!(serde_json::to_string(&OutputSource::SpeakerShare).unwrap(), "\"speaker_share\"");
    }

    #[test]
    fn normal_flow() {
        let mut c = OutputController::new();
        assert_eq!(c.state().source, OutputSource::None);
        let prev = c.begin_switch(OutputSource::Video, Some(5)).unwrap();
        assert_eq!(prev, OutputSource::None);
        assert_eq!(c.state().playback, PlaybackState::Loading);
        c.mark_live().unwrap();
        c.mark_paused(true).unwrap();
        assert_eq!(c.state().playback, PlaybackState::Paused);
        c.mark_paused(false).unwrap();
        c.mark_completed().unwrap();
        assert_eq!(c.state().playback, PlaybackState::Completed);
    }

    #[test]
    fn invalid_transitions() {
        let mut c = OutputController::new();
        assert!(c.mark_live().is_err());
        assert!(c.mark_paused(true).is_err());
        assert!(c.mark_completed().is_err());
    }

    #[test]
    fn error_then_recover() {
        let mut c = OutputController::new();
        c.begin_switch(OutputSource::PowerPoint, Some(1)).unwrap();
        c.mark_error("boom".into());
        assert_eq!(c.state().playback, PlaybackState::Error);
        let prev = c.begin_switch(OutputSource::Black, None).unwrap();
        assert_eq!(prev, OutputSource::PowerPoint);
        c.mark_live().unwrap();
        assert_eq!(c.state().source, OutputSource::Black);
        assert!(c.state().message.is_none());
    }
}

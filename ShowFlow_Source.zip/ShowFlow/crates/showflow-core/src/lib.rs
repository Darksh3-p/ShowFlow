//! ShowFlow core: portable (non-Windows-specific) domain logic.
//! Media scanning/search, playlists, SQLite storage and the output state machine.
pub mod error;
pub mod media;
pub mod models;
pub mod output;
pub mod playlist;
pub mod storage;

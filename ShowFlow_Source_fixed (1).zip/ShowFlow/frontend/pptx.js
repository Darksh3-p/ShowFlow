/* ShowFlow built-in PowerPoint (.pptx / .ppsx) renderer.
 *
 * Draws slides as HTML/SVG so ShowFlow can show presentations on the audience
 * display WITHOUT Microsoft PowerPoint installed. No external libraries.
 *
 * Supported: text (placeholders, inherited styles, bullets, autofit), shapes (preset + custom
 * geometry), pictures (with crop), groups, lines/connectors, tables, basic charts, SmartArt
 * (via its cached drawing), backgrounds (solid/gradient/picture), master/layout graphics.
 * Present mode (present()) also plays slide transitions and entrance / exit / emphasis / motion-path animations
 * (common effects exactly, exotic ones as a fade).
 * NOT supported: embedded video/audio, OLE objects, 3-D/effects.
 *
 * API:  ShowFlowPptx.load(url)  -> Promise<Deck>      (url may be an asset:// / http URL)
 *       ShowFlowPptx.parse(arrayBuffer) -> Promise<Deck>
 *       ShowFlowPptx.show(hostElement, deck, slideIndex) -> Promise   (renders + scales to fit, static final state)
 *       ShowFlowPptx.present(hostElement, deck, {style,speed,onSlide,onAdvance,onError}) -> controller (goto/next/prev/dispose)
 *       ShowFlowPptx.transitions -> [[id, label], ...] (transition styles the operator can force)
 *       deck.count, deck.width, deck.height (CSS px @96dpi), deck.dispose()
 */
(function (root) {
  'use strict';

  var EMU = 9525;           // EMU per CSS pixel
  var SVGNS = 'http://www.w3.org/2000/svg';
  var uidCounter = 0;
  function uid(p) { uidCounter += 1; return (p || 'sf') + uidCounter; }

  // ------------------------------------------------------------------ small XML helpers
  function kids(el, name) {
    var out = [];
    if (!el) return out;
    for (var c = el.firstElementChild; c; c = c.nextElementSibling) { if (!name || c.localName === name) out.push(c); }
    return out;
  }
  function kid(el, name) {
    if (!el) return null;
    for (var c = el.firstElementChild; c; c = c.nextElementSibling) { if (c.localName === name) return c; }
    return null;
  }
  function kidPath(el) {
    for (var i = 1; i < arguments.length && el; i++) el = kid(el, arguments[i]);
    return el || null;
  }
  function attr(el, name, def) {
    if (!el) return def;
    var v = el.getAttribute(name);
    return v == null ? def : v;
  }
  function num(el, name, def) {
    var v = attr(el, name, null);
    if (v == null || v === '') return def;
    var n = parseFloat(v);
    return isNaN(n) ? def : n;
  }
  function bool(el, name, def) {
    var v = attr(el, name, null);
    if (v == null) return def;
    return v === '1' || v === 'true' || v === 'on';
  }
  function findFirst(doc, name) {
    var l = doc.getElementsByTagNameNS('*', name);
    return l.length ? l[0] : null;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // ------------------------------------------------------------------ ZIP reader (stored + deflate)
  var utf8 = new TextDecoder('utf-8');

  function inflateRaw(data) {
    var ds = new DecompressionStream('deflate-raw');
    var w = ds.writable.getWriter();
    w.write(data).catch(function () {});
    w.close().catch(function () {});
    return new Response(ds.readable).arrayBuffer().then(function (b) { return new Uint8Array(b); });
  }

  function openZip(buf) {
    var u8 = new Uint8Array(buf), dv = new DataView(buf);
    if (u8.length < 22) throw new Error('The file is empty or too small to be a presentation.');
    if (!(u8[0] === 0x50 && u8[1] === 0x4b)) {
      if (u8[0] === 0xd0 && u8[1] === 0xcf) {
        throw new Error('This is an old binary PowerPoint file (.ppt/.pps) or a password-protected file. The built-in viewer supports .pptx/.ppsx only - open it in any editor, save as .pptx and try again.');
      }
      throw new Error('This file is not a valid .pptx presentation.');
    }
    var i = u8.length - 22;
    for (; i >= 0 && i > u8.length - 70000; i--) { if (dv.getUint32(i, true) === 0x06054b50) break; }
    if (i < 0 || dv.getUint32(i, true) !== 0x06054b50) throw new Error('The presentation file is damaged (zip directory not found).');
    var total = dv.getUint16(i + 10, true);
    var p = dv.getUint32(i + 16, true);
    var entries = {};
    for (var n = 0; n < total; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      var method = dv.getUint16(p + 10, true);
      var csize = dv.getUint32(p + 20, true);
      var nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
      var lho = dv.getUint32(p + 42, true);
      var name = utf8.decode(u8.subarray(p + 46, p + 46 + nlen));
      entries[name] = { method: method, csize: csize, lho: lho };
      p += 46 + nlen + elen + clen;
    }
    return {
      has: function (name) { return !!entries[name]; },
      names: function () { return Object.keys(entries); },
      read: function (name) {
        var e = entries[name];
        if (!e) return Promise.reject(new Error('missing part ' + name));
        var nlen2 = dv.getUint16(e.lho + 26, true), elen2 = dv.getUint16(e.lho + 28, true);
        var start = e.lho + 30 + nlen2 + elen2;
        var data = u8.subarray(start, start + e.csize);
        if (e.method === 0) return Promise.resolve(data);
        if (e.method === 8) return inflateRaw(data);
        return Promise.reject(new Error('unsupported zip compression in ' + name));
      }
    };
  }

  // ------------------------------------------------------------------ colours
  var PRESET = { black: '000000', white: 'FFFFFF', red: 'FF0000', green: '008000', blue: '0000FF', yellow: 'FFFF00', gray: '808080', grey: '808080', orange: 'FFA500', purple: '800080', cyan: '00FFFF', magenta: 'FF00FF', brown: 'A52A2A', pink: 'FFC0CB', lime: '00FF00', navy: '000080', teal: '008080', silver: 'C0C0C0', maroon: '800000', olive: '808000', darkblue: '00008B', darkgreen: '006400', darkred: '8B0000', lightgray: 'D3D3D3', lightgrey: 'D3D3D3', darkgray: 'A9A9A9', darkgrey: 'A9A9A9', gold: 'FFD700', ltGray: 'D3D3D3', dkGray: 'A9A9A9' };

  function hex2rgb(h) {
    h = String(h || '000000').replace('#', '');
    if (h.length === 3) h = h.split('').map(function (x) { return x + x; }).join('');
    return [parseInt(h.substr(0, 2), 16) || 0, parseInt(h.substr(2, 2), 16) || 0, parseInt(h.substr(4, 2), 16) || 0];
  }
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2;
    if (mx !== mn) {
      var d = mx - mn;
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h /= 6;
    }
    return [h, s, l];
  }
  function hsl2rgb(h, s, l) {
    function f(p, q, t) {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    }
    if (s === 0) { var v = Math.round(l * 255); return [v, v, v]; }
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return [Math.round(f(p, q, h + 1 / 3) * 255), Math.round(f(p, q, h) * 255), Math.round(f(p, q, h - 1 / 3) * 255)];
  }
  function clamp01(x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
  function toLin(c) { return Math.pow(c / 255, 2.2); }
  function fromLin(l) { return Math.round(Math.pow(clamp01(l), 1 / 2.2) * 255); }

  function applyMods(c, el) {
    for (var m = el.firstElementChild; m; m = m.nextElementSibling) {
      var n = m.localName, v = num(m, 'val', 0) / 100000, hsl;
      switch (n) {
        case 'alpha': c.a = clamp01(v); break;
        case 'alphaMod': c.a = clamp01(c.a * v); break;
        case 'alphaOff': c.a = clamp01(c.a + v); break;
        case 'lumMod': hsl = rgb2hsl(c.rgb[0], c.rgb[1], c.rgb[2]); hsl[2] = clamp01(hsl[2] * v); c.rgb = hsl2rgb(hsl[0], hsl[1], hsl[2]); break;
        case 'lumOff': hsl = rgb2hsl(c.rgb[0], c.rgb[1], c.rgb[2]); hsl[2] = clamp01(hsl[2] + v); c.rgb = hsl2rgb(hsl[0], hsl[1], hsl[2]); break;
        case 'satMod': hsl = rgb2hsl(c.rgb[0], c.rgb[1], c.rgb[2]); hsl[1] = clamp01(hsl[1] * v); c.rgb = hsl2rgb(hsl[0], hsl[1], hsl[2]); break;
        case 'satOff': hsl = rgb2hsl(c.rgb[0], c.rgb[1], c.rgb[2]); hsl[1] = clamp01(hsl[1] + v); c.rgb = hsl2rgb(hsl[0], hsl[1], hsl[2]); break;
        case 'hueOff': hsl = rgb2hsl(c.rgb[0], c.rgb[1], c.rgb[2]); hsl[0] = (hsl[0] + num(m, 'val', 0) / 21600000 + 1) % 1; c.rgb = hsl2rgb(hsl[0], hsl[1], hsl[2]); break;
        case 'tint': c.rgb = c.rgb.map(function (x) { return fromLin(toLin(x) * v + (1 - v)); }); break;
        case 'shade': c.rgb = c.rgb.map(function (x) { return fromLin(toLin(x) * v); }); break;
        case 'comp': hsl = rgb2hsl(c.rgb[0], c.rgb[1], c.rgb[2]); hsl[0] = (hsl[0] + 0.5) % 1; c.rgb = hsl2rgb(hsl[0], hsl[1], hsl[2]); break;
        case 'inv': c.rgb = c.rgb.map(function (x) { return 255 - x; }); break;
        case 'gray': var g = Math.round(c.rgb[0] * 0.3 + c.rgb[1] * 0.59 + c.rgb[2] * 0.11); c.rgb = [g, g, g]; break;
      }
    }
    return c;
  }

  function themeColorHex(ctx, name) {
    var m = ctx.clrMap && ctx.clrMap[name];
    var key = m || name;
    return (ctx.theme && ctx.theme.colors[key]) || (key === 'lt1' || key === 'bg1' ? 'FFFFFF' : '000000');
  }

  /** el = a colour element (srgbClr, schemeClr, ...). Returns {rgb:[r,g,b], a} or null. */
  function colorFromEl(el, ctx) {
    var n = el.localName, rgb = null, a = 1;
    if (n === 'srgbClr') rgb = hex2rgb(attr(el, 'val', '000000'));
    else if (n === 'scrgbClr') rgb = [Math.round(num(el, 'r', 0) / 100000 * 255), Math.round(num(el, 'g', 0) / 100000 * 255), Math.round(num(el, 'b', 0) / 100000 * 255)];
    else if (n === 'prstClr') rgb = hex2rgb(PRESET[attr(el, 'val', 'black')] || '000000');
    else if (n === 'sysClr') { var sv = attr(el, 'val', ''); rgb = hex2rgb(attr(el, 'lastClr', sv === 'window' ? 'FFFFFF' : '000000')); }
    else if (n === 'schemeClr') {
      var v = attr(el, 'val', 'tx1');
      if (v === 'phClr') { if (!ctx.phClr) return null; rgb = ctx.phClr.rgb.slice(); a = ctx.phClr.a; }
      else rgb = hex2rgb(themeColorHex(ctx, v));
    } else return null;
    return applyMods({ rgb: rgb, a: a }, el);
  }
  var COLOR_NAMES = { srgbClr: 1, scrgbClr: 1, prstClr: 1, sysClr: 1, schemeClr: 1, hslClr: 1 };
  /** parent contains a colour child (solidFill, fontRef, lnRef...) */
  function colorIn(parent, ctx) {
    if (!parent) return null;
    for (var c = parent.firstElementChild; c; c = c.nextElementSibling) {
      if (COLOR_NAMES[c.localName]) return colorFromEl(c, ctx);
    }
    return null;
  }
  function css(c) {
    if (!c) return 'transparent';
    var r = c.rgb;
    return c.a >= 0.999 ? 'rgb(' + r[0] + ',' + r[1] + ',' + r[2] + ')' : 'rgba(' + r[0] + ',' + r[1] + ',' + r[2] + ',' + (Math.round(c.a * 1000) / 1000) + ')';
  }

  // ------------------------------------------------------------------ fills & lines
  var NS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  function rattr(el, name) {
    if (!el) return null;
    return el.getAttributeNS(NS_R, name) || el.getAttribute('r:' + name) || null;
  }
  var FILL_NAMES = { noFill: 1, solidFill: 1, gradFill: 1, blipFill: 1, pattFill: 1 };

  function fillFromEl(c, ctx) {
    switch (c.localName) {
      case 'noFill': return { t: 'none' };
      case 'solidFill': { var col = colorIn(c, ctx); return col ? { t: 'solid', c: col } : null; }
      case 'gradFill': {
        var stops = [];
        kids(kid(c, 'gsLst'), 'gs').forEach(function (g) {
          var gc = colorIn(g, ctx);
          if (gc) stops.push({ p: num(g, 'pos', 0) / 1000, c: gc });
        });
        if (!stops.length) return null;
        var lin = kid(c, 'lin'), path = kid(c, 'path');
        return { t: 'grad', stops: stops, ang: lin ? num(lin, 'ang', 0) / 60000 : 90, radial: !!path };
      }
      case 'blipFill': {
        var blip = kid(c, 'blip');
        var url = blip ? ctx.imageUrl(rattr(blip, 'embed')) : null;
        if (!url) return null;
        var amf = blip ? kid(blip, 'alphaModFix') : null;
        return { t: 'blip', url: url, alpha: amf ? num(amf, 'amt', 100000) / 100000 : 1, src: kid(c, 'srcRect') };
      }
      case 'pattFill': {
        var fg = colorIn(kid(c, 'fgClr'), ctx), bg = colorIn(kid(c, 'bgClr'), ctx);
        if (!fg) return null;
        if (bg) return { t: 'solid', c: { rgb: [Math.round((fg.rgb[0] + bg.rgb[0]) / 2), Math.round((fg.rgb[1] + bg.rgb[1]) / 2), Math.round((fg.rgb[2] + bg.rgb[2]) / 2)], a: 1 } };
        return { t: 'solid', c: fg };
      }
    }
    return null;
  }
  function parseFill(parent, ctx) {
    if (!parent) return null;
    for (var c = parent.firstElementChild; c; c = c.nextElementSibling) {
      if (FILL_NAMES[c.localName]) { var f = fillFromEl(c, ctx); if (f) return f; if (c.localName === 'noFill') return { t: 'none' }; }
    }
    return null;
  }
  function themeFill(ctx, idx, phCol) {
    if (!idx || !ctx.theme) return null;
    var el = idx >= 1001 ? ctx.theme.bgFill[idx - 1001] : ctx.theme.fill[idx - 1];
    if (!el) return null;
    var saved = ctx.phClr; ctx.phClr = phCol;
    var f = fillFromEl(el, ctx);
    ctx.phClr = saved;
    return f;
  }
  function lineFromEl(ln, ctx) {
    if (!ln) return null;
    var o = {};
    var w = attr(ln, 'w', null);
    if (w != null) o.w = parseFloat(w) / EMU;
    var f = parseFill(ln, ctx);
    if (f) o.fill = f;
    var d = kid(ln, 'prstDash');
    if (d) o.dash = attr(d, 'val', 'solid');
    var cap = attr(ln, 'cap', null);
    if (cap) o.cap = cap;
    var he = kid(ln, 'headEnd'), te = kid(ln, 'tailEnd');
    if (he && attr(he, 'type', 'none') !== 'none') o.head = attr(he, 'type', 'triangle');
    if (te && attr(te, 'type', 'none') !== 'none') o.tail = attr(te, 'type', 'triangle');
    return o;
  }
  function themeLn(ctx, idx, phCol) {
    if (!idx || !ctx.theme) return null;
    var el = ctx.theme.ln[idx - 1];
    if (!el) return null;
    var saved = ctx.phClr; ctx.phClr = phCol;
    var l = lineFromEl(el, ctx);
    ctx.phClr = saved;
    return l;
  }
  function mergeObj(a, b) {
    var o = {}, k;
    for (k in (a || {})) o[k] = a[k];
    for (k in (b || {})) { if (b[k] !== undefined) o[k] = b[k]; }
    return o;
  }

  function gradDefs(fill, w, h, id) {
    // returns an SVG gradient element (string)
    var stops = fill.stops.map(function (s) {
      return '<stop offset="' + s.p + '%" stop-color="rgb(' + s.c.rgb.join(',') + ')" stop-opacity="' + s.c.a + '"/>';
    }).join('');
    if (fill.radial) {
      return '<radialGradient id="' + id + '" cx="50%" cy="50%" r="70%">' + stops + '</radialGradient>';
    }
    var th = (fill.ang || 0) * Math.PI / 180, dx = Math.cos(th), dy = Math.sin(th);
    var half = (Math.abs(w * dx) + Math.abs(h * dy)) / 2;
    var cx = w / 2, cy = h / 2;
    return '<linearGradient id="' + id + '" gradientUnits="userSpaceOnUse" x1="' + (cx - dx * half) + '" y1="' + (cy - dy * half) + '" x2="' + (cx + dx * half) + '" y2="' + (cy + dy * half) + '">' + stops + '</linearGradient>';
  }
  function fillCss(f) {
    // CSS background value for a fill (used for slide backgrounds and table cells)
    if (!f || f.t === 'none') return null;
    if (f.t === 'solid') return css(f.c);
    if (f.t === 'grad') {
      var stops = f.stops.map(function (s) { return css(s.c) + ' ' + s.p + '%'; }).join(',');
      return f.radial ? 'radial-gradient(circle at 50% 50%,' + stops + ')' : 'linear-gradient(' + ((f.ang || 0) + 90) + 'deg,' + stops + ')';
    }
    if (f.t === 'blip') return 'url("' + f.url + '") center/100% 100% no-repeat';
    return null;
  }

  // ------------------------------------------------------------------ preset geometry
  function poly(pts) { return 'M' + pts.map(function (p) { return p[0].toFixed(2) + ',' + p[1].toFixed(2); }).join(' L') + ' Z'; }
  function rrect(w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    return 'M' + r + ',0 H' + (w - r) + ' A' + r + ',' + r + ' 0 0 1 ' + w + ',' + r + ' V' + (h - r) + ' A' + r + ',' + r + ' 0 0 1 ' + (w - r) + ',' + h +
      ' H' + r + ' A' + r + ',' + r + ' 0 0 1 0,' + (h - r) + ' V' + r + ' A' + r + ',' + r + ' 0 0 1 ' + r + ',0 Z';
  }
  function ellipsePath(cx, cy, rx, ry) {
    return 'M' + (cx - rx) + ',' + cy + ' A' + rx + ',' + ry + ' 0 1 0 ' + (cx + rx) + ',' + cy + ' A' + rx + ',' + ry + ' 0 1 0 ' + (cx - rx) + ',' + cy + ' Z';
  }
  function star(n, inner, w, h) {
    var pts = [], cx = w / 2, cy = h / 2;
    for (var i = 0; i < n * 2; i++) {
      var r = i % 2 === 0 ? 1 : inner, a = -Math.PI / 2 + i * Math.PI / n;
      pts.push([cx + Math.cos(a) * r * w / 2, cy + Math.sin(a) * r * h / 2]);
    }
    return poly(pts);
  }

  /** Returns [{d, rule, noFill, noStroke, tr}] for a preset shape. */
  function preset(name, w, h, av) {
    var ss = Math.min(w, h);
    function A(n, def) { return av && av[n] != null ? av[n] : def; }
    var P = function (d, extra) { var o = { d: d }; if (extra) for (var k in extra) o[k] = extra[k]; return [o]; };
    var a, a1, a2, dx, x1, y1, y2;
    switch (name) {
      case 'ellipse': case 'flowChartConnector': case 'flowChartOr': case 'flowChartSummingJunction': case 'cloud': case 'teardrop': case 'smileyFace': case 'sun': case 'moon':
        return P(ellipsePath(w / 2, h / 2, w / 2, h / 2));
      case 'roundRect': return P(rrect(w, h, ss * A('adj', 16667) / 100000));
      case 'flowChartAlternateProcess': return P(rrect(w, h, ss * 0.1667));
      case 'flowChartTerminator': return P(rrect(w, h, h / 2));
      case 'round1Rect': case 'round2SameRect': case 'round2DiagRect': case 'snip1Rect': case 'snip2SameRect': case 'snipRoundRect':
        return P(rrect(w, h, ss * 0.16));
      case 'wedgeRoundRectCallout': return P(rrect(w, h, ss * 0.16));
      case 'triangle': case 'flowChartMerge': case 'flowChartExtract':
        a = A('adj', 50000); return P(poly([[w * a / 100000, 0], [w, h], [0, h]]));
      case 'rtTriangle': return P(poly([[0, 0], [0, h], [w, h]]));
      case 'diamond': case 'flowChartDecision': return P(poly([[w / 2, 0], [w, h / 2], [w / 2, h], [0, h / 2]]));
      case 'parallelogram': case 'flowChartInputOutput':
        a = A('adj', 25000); dx = ss * a / 100000; return P(poly([[dx, 0], [w, 0], [w - dx, h], [0, h]]));
      case 'trapezoid': case 'flowChartManualOperation':
        a = A('adj', 25000); dx = ss * a / 100000; return P(poly([[0, h], [dx, 0], [w - dx, 0], [w, h]]));
      case 'pentagon': return P(poly([[w / 2, 0], [w, h * 0.382], [w * 0.809, h], [w * 0.191, h], [0, h * 0.382]]));
      case 'hexagon': case 'flowChartPreparation':
        a = A('adj', 25000); x1 = ss * a / 100000; return P(poly([[0, h / 2], [x1, 0], [w - x1, 0], [w, h / 2], [w - x1, h], [x1, h]]));
      case 'octagon':
        a = A('adj', 29289); x1 = ss * a / 100000; return P(poly([[0, x1], [x1, 0], [w - x1, 0], [w, x1], [w, h - x1], [w - x1, h], [x1, h], [0, h - x1]]));
      case 'homePlate':
        a = A('adj', 50000); dx = ss * a / 100000; return P(poly([[0, 0], [w - dx, 0], [w, h / 2], [w - dx, h], [0, h]]));
      case 'chevron':
        a = A('adj', 50000); dx = ss * a / 100000; return P(poly([[0, 0], [w - dx, 0], [w, h / 2], [w - dx, h], [0, h], [dx, h / 2]]));
      case 'rightArrow': case 'notchedRightArrow':
        a1 = A('adj1', 50000); a2 = A('adj2', 50000); dx = ss * a2 / 100000; y1 = h * (50000 - a1 / 2) / 100000; y2 = h - y1;
        return P(poly([[0, y1], [w - dx, y1], [w - dx, 0], [w, h / 2], [w - dx, h], [w - dx, y2], [0, y2]]));
      case 'leftArrow':
        a1 = A('adj1', 50000); a2 = A('adj2', 50000); dx = ss * a2 / 100000; y1 = h * (50000 - a1 / 2) / 100000; y2 = h - y1;
        return P(poly([[w, y1], [dx, y1], [dx, 0], [0, h / 2], [dx, h], [dx, y2], [w, y2]]));
      case 'upArrow':
        a1 = A('adj1', 50000); a2 = A('adj2', 50000); dx = ss * a2 / 100000; x1 = w * (50000 - a1 / 2) / 100000; var x2 = w - x1;
        return P(poly([[x1, h], [x1, dx], [0, dx], [w / 2, 0], [w, dx], [x2, dx], [x2, h]]));
      case 'downArrow':
        a1 = A('adj1', 50000); a2 = A('adj2', 50000); dx = ss * a2 / 100000; x1 = w * (50000 - a1 / 2) / 100000; var x3 = w - x1;
        return P(poly([[x1, 0], [x1, h - dx], [0, h - dx], [w / 2, h], [w, h - dx], [x3, h - dx], [x3, 0]]));
      case 'leftRightArrow':
        a1 = A('adj1', 50000); a2 = A('adj2', 50000); dx = ss * a2 / 100000; y1 = h * (50000 - a1 / 2) / 100000; y2 = h - y1;
        return P(poly([[0, h / 2], [dx, 0], [dx, y1], [w - dx, y1], [w - dx, 0], [w, h / 2], [w - dx, h], [w - dx, y2], [dx, y2], [dx, h]]));
      case 'plus': case 'mathPlus':
        a = A('adj', 25000); x1 = ss * a / 100000;
        return P(poly([[x1, 0], [w - x1, 0], [w - x1, x1], [w, x1], [w, h - x1], [w - x1, h - x1], [w - x1, h], [x1, h], [x1, h - x1], [0, h - x1], [0, x1], [x1, x1]]));
      case 'star4': return P(star(4, A('adj', 12500) / 50000, w, h));
      case 'star5': return P(star(5, A('adj', 19098) / 50000, w, h));
      case 'star6': return P(star(6, A('adj', 28868) / 50000, w, h));
      case 'star8': return P(star(8, A('adj', 37500) / 50000, w, h));
      case 'star10': return P(star(10, A('adj', 42533) / 50000, w, h));
      case 'star12': return P(star(12, A('adj', 37500) / 50000, w, h));
      case 'star16': return P(star(16, A('adj', 37500) / 50000, w, h));
      case 'star24': return P(star(24, A('adj', 37500) / 50000, w, h));
      case 'heart': return P('M50,30 C50,-8 0,-8 0,30 C0,60 40,80 50,100 C60,80 100,60 100,30 C100,-8 50,-8 50,30 Z', { tr: 'scale(' + (w / 100) + ',' + (h / 100) + ')', ve: true });
      case 'donut': {
        a = A('adj', 25000); var t = ss * a / 100000;
        return P(ellipsePath(w / 2, h / 2, w / 2, h / 2) + ' ' + ellipsePath(w / 2, h / 2, Math.max(0, w / 2 - t), Math.max(0, h / 2 - t)), { rule: 'evenodd' });
      }
      case 'frame': {
        a = A('adj1', 12500); var f = ss * a / 100000;
        return P('M0,0 H' + w + ' V' + h + ' H0 Z M' + f + ',' + f + ' V' + (h - f) + ' H' + (w - f) + ' V' + f + ' Z', { rule: 'evenodd' });
      }
      case 'line': case 'straightConnector1': return P('M0,0 L' + w + ',' + h, { noFill: true });
      case 'bentConnector2': return P('M0,0 L' + w + ',0 L' + w + ',' + h, { noFill: true });
      case 'bentConnector3': case 'bentConnector4': case 'bentConnector5':
        x1 = w * A('adj1', 50000) / 100000; return P('M0,0 L' + x1 + ',0 L' + x1 + ',' + h + ' L' + w + ',' + h, { noFill: true });
      case 'curvedConnector2': return P('M0,0 C' + (w / 2) + ',0 ' + w + ',' + (h / 2) + ' ' + w + ',' + h, { noFill: true });
      case 'curvedConnector3': case 'curvedConnector4': case 'curvedConnector5':
        x1 = w * A('adj1', 50000) / 100000; return P('M0,0 C' + x1 + ',0 ' + x1 + ',' + h + ' ' + w + ',' + h, { noFill: true });
      case 'leftBracket': return P('M' + w + ',0 L0,0 L0,' + h + ' L' + w + ',' + h, { noFill: true });
      case 'rightBracket': return P('M0,0 L' + w + ',0 L' + w + ',' + h + ' L0,' + h, { noFill: true });
      case 'rightBrace': return P('M0,0 Q' + (w / 2) + ',0 ' + (w / 2) + ',' + (h * 0.25) + ' L' + (w / 2) + ',' + (h * 0.4) + ' Q' + (w / 2) + ',' + (h / 2) + ' ' + w + ',' + (h / 2) + ' Q' + (w / 2) + ',' + (h / 2) + ' ' + (w / 2) + ',' + (h * 0.6) + ' L' + (w / 2) + ',' + (h * 0.75) + ' Q' + (w / 2) + ',' + h + ' 0,' + h, { noFill: true });
      case 'leftBrace': return P('M' + w + ',0 Q' + (w / 2) + ',0 ' + (w / 2) + ',' + (h * 0.25) + ' L' + (w / 2) + ',' + (h * 0.4) + ' Q' + (w / 2) + ',' + (h / 2) + ' 0,' + (h / 2) + ' Q' + (w / 2) + ',' + (h / 2) + ' ' + (w / 2) + ',' + (h * 0.6) + ' L' + (w / 2) + ',' + (h * 0.75) + ' Q' + (w / 2) + ',' + h + ' ' + w + ',' + h, { noFill: true });
      default: return P('M0,0 H' + w + ' V' + h + ' H0 Z'); // rect and anything unknown
    }
  }

  function guideVal(s, pw, ph) {
    var n = parseFloat(s);
    if (!isNaN(n) && /^-?[0-9.]+$/.test(String(s))) return n;
    switch (s) {
      case 'l': case 't': return 0;
      case 'r': case 'w': return pw;
      case 'b': case 'h': return ph;
      case 'hc': case 'wd2': return pw / 2;
      case 'vc': case 'hd2': return ph / 2;
      default: return 0;
    }
  }
  function custPaths(cg, w, h) {
    var out = [];
    kids(kid(cg, 'pathLst'), 'path').forEach(function (p) {
      var pw = num(p, 'w', 0) || w, ph = num(p, 'h', 0) || h;
      var sx = pw ? w / pw : 1, sy = ph ? h / ph : 1;
      var d = '', cx = 0, cy = 0;
      function pt(el) { return [guideVal(attr(el, 'x', '0'), pw, ph) * sx, guideVal(attr(el, 'y', '0'), pw, ph) * sy]; }
      for (var c = p.firstElementChild; c; c = c.nextElementSibling) {
        var pts = kids(c, 'pt').map(pt), q;
        switch (c.localName) {
          case 'moveTo': q = pts[0]; if (q) { d += 'M' + q[0] + ',' + q[1] + ' '; cx = q[0]; cy = q[1]; } break;
          case 'lnTo': q = pts[0]; if (q) { d += 'L' + q[0] + ',' + q[1] + ' '; cx = q[0]; cy = q[1]; } break;
          case 'cubicBezTo': if (pts.length >= 3) { d += 'C' + pts.map(function (z) { return z[0] + ',' + z[1]; }).join(' ') + ' '; cx = pts[2][0]; cy = pts[2][1]; } break;
          case 'quadBezTo': if (pts.length >= 2) { d += 'Q' + pts.map(function (z) { return z[0] + ',' + z[1]; }).join(' ') + ' '; cx = pts[1][0]; cy = pts[1][1]; } break;
          case 'arcTo': {
            var wr = guideVal(attr(c, 'wR', '0'), pw, ph) * sx, hr = guideVal(attr(c, 'hR', '0'), pw, ph) * sy;
            var st = guideVal(attr(c, 'stAng', '0'), pw, ph) / 60000, sw = guideVal(attr(c, 'swAng', '0'), pw, ph) / 60000;
            if (wr > 0 && hr > 0) {
              var s1 = st * Math.PI / 180, s2 = (st + sw) * Math.PI / 180;
              var ox = cx - wr * Math.cos(s1), oy = cy - hr * Math.sin(s1);
              var ex = ox + wr * Math.cos(s2), ey = oy + hr * Math.sin(s2);
              d += 'A' + wr + ',' + hr + ' 0 ' + (Math.abs(sw) > 180 ? 1 : 0) + ' ' + (sw > 0 ? 1 : 0) + ' ' + ex + ',' + ey + ' ';
              cx = ex; cy = ey;
            }
            break;
          }
          case 'close': d += 'Z '; break;
        }
      }
      if (d) out.push({ d: d, noFill: attr(p, 'fill', 'norm') === 'none', noStroke: attr(p, 'stroke', '1') === '0' || attr(p, 'stroke', 'true') === 'false' });
    });
    return out;
  }

  // ------------------------------------------------------------------ text styles
  function parseRPr(el, ctx) {
    var o = {};
    if (!el) return o;
    var v = attr(el, 'sz', null);
    if (v != null) o.sz = parseFloat(v);
    if (attr(el, 'b', null) != null) o.b = bool(el, 'b', false);
    if (attr(el, 'i', null) != null) o.i = bool(el, 'i', false);
    if (attr(el, 'u', null) != null) o.u = attr(el, 'u', 'none') !== 'none';
    if (attr(el, 'strike', null) != null) o.strike = attr(el, 'strike', 'noStrike') !== 'noStrike';
    if (attr(el, 'baseline', null) != null) o.baseline = num(el, 'baseline', 0);
    if (attr(el, 'cap', null) != null) o.cap = attr(el, 'cap', 'none');
    if (attr(el, 'spc', null) != null) o.spc = num(el, 'spc', 0);
    var fill = kid(el, 'solidFill');
    if (fill) { var c = colorIn(fill, ctx); if (c) o.color = c; }
    var lat = kid(el, 'latin'); if (lat && attr(lat, 'typeface', '')) o.latin = attr(lat, 'typeface', '');
    var ea = kid(el, 'ea'); if (ea && attr(ea, 'typeface', '')) o.ea = attr(ea, 'typeface', '');
    if (kid(el, 'hlinkClick')) o.hlink = true;
    return o;
  }
  function spacing(el) {
    if (!el) return undefined;
    var pc = kid(el, 'spcPct'), pt = kid(el, 'spcPts');
    if (pc) return { pct: num(pc, 'val', 100000) / 1000 };
    if (pt) return { pts: num(pt, 'val', 0) / 100 };
    return undefined;
  }
  function parsePPr(el, ctx) {
    var o = {};
    if (!el) return o;
    if (attr(el, 'marL', null) != null) o.marL = num(el, 'marL', 0);
    if (attr(el, 'marR', null) != null) o.marR = num(el, 'marR', 0);
    if (attr(el, 'indent', null) != null) o.indent = num(el, 'indent', 0);
    if (attr(el, 'algn', null) != null) o.algn = attr(el, 'algn', 'l');
    var t;
    if ((t = spacing(kid(el, 'lnSpc')))) o.lnSpc = t;
    if ((t = spacing(kid(el, 'spcBef')))) o.spcBef = t;
    if ((t = spacing(kid(el, 'spcAft')))) o.spcAft = t;
    if (kid(el, 'buNone')) o.bu = { type: 'none' };
    var bc = kid(el, 'buChar'), ba = kid(el, 'buAutoNum');
    if (bc) o.bu = { type: 'char', ch: attr(bc, 'char', '\u2022') };
    else if (ba) o.bu = { type: 'auto', kind: attr(ba, 'type', 'arabicPeriod'), start: num(ba, 'startAt', 1) };
    else if (kid(el, 'buBlip')) o.bu = { type: 'char', ch: '\u2022' };
    var bf = kid(el, 'buFont'); if (bf) o.buFont = attr(bf, 'typeface', '');
    var bcl = kid(el, 'buClr'); if (bcl) { var cc = colorIn(bcl, ctx); if (cc) o.buClr = cc; }
    var bs = kid(el, 'buSzPct'); if (bs) o.buSz = num(bs, 'val', 100000) / 100000;
    var d = kid(el, 'defRPr'); if (d) o.rpr = parseRPr(d, ctx);
    return o;
  }
  function mergeP(a, b) {
    var o = {}, k;
    for (k in a) o[k] = a[k];
    for (k in b) { if (k !== 'rpr' && b[k] !== undefined) o[k] = b[k]; }
    o.rpr = mergeObj(a.rpr, b.rpr);
    return o;
  }
  function levelStyle(chain, lvl, ctx) {
    var o = { rpr: {} };
    chain.forEach(function (el) {
      if (!el) return;
      if (el.nodeType === undefined) { o = mergeP(o, el); return; }   // synthetic pre-parsed entry
      var p = kid(el, 'lvl' + (lvl + 1) + 'pPr');
      if (p) o = mergeP(o, parsePPr(p, ctx));
    });
    return o;
  }

  var WINGDINGS = { '\u00a7': '\u25aa', '\u00d8': '\u27a2', '\u00fc': '\u2713', 'v': '\u2756', 'l': '\u25cf', 'n': '\u25a0', 'q': '\u2751', '\u00b7': '\u2022', 'o': '\u25cb', '\u00a8': '\u25a1', 'p': '\u25a0', 'u': '\u25c6', 'w': '\u25c6' };
  function roman(n, lower) {
    var r = [['m', 1000], ['cm', 900], ['d', 500], ['cd', 400], ['c', 100], ['xc', 90], ['l', 50], ['xl', 40], ['x', 10], ['ix', 9], ['v', 5], ['iv', 4], ['i', 1]], s = '';
    r.forEach(function (p) { while (n >= p[1]) { s += p[0]; n -= p[1]; } });
    return lower ? s : s.toUpperCase();
  }
  function alpha(n, lower) {
    var s = '';
    while (n > 0) { n--; s = String.fromCharCode(97 + (n % 26)) + s; n = Math.floor(n / 26); }
    return lower ? s : s.toUpperCase();
  }
  function autoNumText(kind, n) {
    var core, k = kind || 'arabicPeriod';
    if (/^arabic/.test(k)) core = String(n);
    else if (/^romanLc/.test(k)) core = roman(n, true);
    else if (/^romanUc/.test(k)) core = roman(n, false);
    else if (/^alphaLc/.test(k)) core = alpha(n, true);
    else if (/^alphaUc/.test(k)) core = alpha(n, false);
    else core = String(n);
    if (/ParenBoth/.test(k)) return '(' + core + ')';
    if (/ParenR/.test(k)) return core + ')';
    if (/Plain/.test(k)) return core;
    return core + '.';
  }

  function fontStack(rpr, ctx, text) {
    var th = ctx.theme || {};
    function res(f) {
      if (!f) return '';
      if (f.indexOf('+mj') === 0) return th.major || '';
      if (f.indexOf('+mn') === 0) return th.minor || '';
      return f;
    }
    var lat = res(rpr.latin) || th.minor || 'Calibri';
    var ea = res(rpr.ea);
    var list = ['"' + lat.replace(/"/g, '') + '"'];
    if (ea && /[\u2e80-\u9fff\uac00-\ud7af\uff00-\uffef]/.test(text || '')) list.unshift('"' + ea.replace(/"/g, '') + '"');
    list.push('"Segoe UI"', 'Arial', '"Microsoft YaHei"', '"Yu Gothic"', '"Malgun Gothic"', 'sans-serif');
    return list.join(',');
  }

  /** Merge bodyPr attributes: list is highest-priority first. */
  function bodyProps(list) {
    var o = { l: 91440, t: 45720, r: 91440, b: 45720, anchor: 't', wrap: true, anchorCtr: false, vert: 'horz', fit: null };
    for (var i = list.length - 1; i >= 0; i--) {
      var bp = list[i];
      if (!bp) continue;
      if (attr(bp, 'lIns', null) != null) o.l = num(bp, 'lIns', o.l);
      if (attr(bp, 'tIns', null) != null) o.t = num(bp, 'tIns', o.t);
      if (attr(bp, 'rIns', null) != null) o.r = num(bp, 'rIns', o.r);
      if (attr(bp, 'bIns', null) != null) o.b = num(bp, 'bIns', o.b);
      if (attr(bp, 'anchor', null) != null) o.anchor = attr(bp, 'anchor', 't');
      if (attr(bp, 'wrap', null) != null) o.wrap = attr(bp, 'wrap', 'square') !== 'none';
      if (attr(bp, 'vert', null) != null) o.vert = attr(bp, 'vert', 'horz');
      if (attr(bp, 'anchorCtr', null) != null) o.anchorCtr = bool(bp, 'anchorCtr', false);
      var na = kid(bp, 'normAutofit');
      if (na) o.fit = { type: 'norm', scale: num(na, 'fontScale', 100000) / 100000, lnRed: num(na, 'lnSpcReduction', 0) / 100000, explicit: attr(na, 'fontScale', null) != null };
      else if (kid(bp, 'spAutoFit')) o.fit = { type: 'shape' };
      else if (kid(bp, 'noAutofit')) o.fit = null;
    }
    return o;
  }

  function hasText(txBody) {
    if (!txBody) return false;
    var ts = txBody.getElementsByTagNameNS('*', 't');
    for (var i = 0; i < ts.length; i++) { if (ts[i].textContent !== '') return true; }
    var fl = txBody.getElementsByTagNameNS('*', 'fld');
    return fl.length > 0;
  }

  /**
   * Render txBody into a new flex container appended to `parent`.
   * opt: { chain: [lstStyle elements/synthetic...], bodyPr: [..], baseRpr: obj }
   */
  function renderText(txBody, parent, ctx, opt) {
    var bp = bodyProps(opt.bodyPr || []);
    var box = document.createElement('div');
    var anchor = bp.anchor === 'ctr' ? 'center' : (bp.anchor === 'b' ? 'flex-end' : 'flex-start');
    var cs = opt.flow
      ? 'box-sizing:border-box;display:flex;flex-direction:column;padding:0;'
      : 'position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;display:flex;flex-direction:column;justify-content:' + anchor +
        ';padding:' + (bp.t / EMU) + 'px ' + (bp.r / EMU) + 'px ' + (bp.b / EMU) + 'px ' + (bp.l / EMU) + 'px;overflow:visible;';
    if (bp.anchorCtr) cs += 'align-items:center;';
    if (bp.vert === 'vert' || bp.vert === 'eaVert') cs += 'writing-mode:vertical-rl;';
    else if (bp.vert === 'vert270') cs += 'writing-mode:vertical-rl;transform:rotate(180deg);';
    var scale = 1, lnRed = 0;
    if (bp.fit && bp.fit.type === 'norm') { scale = bp.fit.scale || 1; lnRed = bp.fit.lnRed || 0; }
    cs += '--sfs:' + scale + ';';
    box.style.cssText = cs;
    box.className = 'sfp-text';
    if (bp.fit && bp.fit.type === 'norm' && !bp.fit.explicit) box.setAttribute('data-fit', '1');

    var counters = [], lastLvl = -1, first = true;
    kids(txBody, 'p').forEach(function (p, paraIdx) {
      var pPr = kid(p, 'pPr');
      var lvl = Math.max(0, Math.min(8, num(pPr, 'lvl', 0)));
      var st = mergeP(levelStyle(opt.chain, lvl, ctx), parsePPr(pPr, ctx));
      var base = mergeObj(opt.baseRpr || {}, {});
      var prpr = mergeObj(st.rpr, base);          // paragraph default run props (table-style text overrides defaults)
      var runs = [], i, c;
      for (c = p.firstElementChild; c; c = c.nextElementSibling) {
        if (c.localName === 'r' || c.localName === 'fld') {
          var tEl = kid(c, 't'), txt = tEl ? tEl.textContent : '';
          if (c.localName === 'fld' && /slidenum/i.test(attr(c, 'type', ''))) txt = String(ctx.slideNum || '');
          runs.push({ text: txt, rpr: mergeObj(prpr, parseRPr(kid(c, 'rPr'), ctx)) });
        } else if (c.localName === 'br') {
          runs.push({ br: true, rpr: mergeObj(prpr, parseRPr(kid(c, 'rPr'), ctx)) });
        }
      }
      var endRpr = mergeObj(prpr, parseRPr(kid(p, 'endParaRPr'), ctx));
      var fs0 = ((runs.length && runs[0].rpr.sz) || endRpr.sz || 1800);
      var fsPx0 = fs0 / 75;

      // bullet
      var bulletText = null;
      var bu = st.bu;
      var plain = runs.every(function (r) { return r.br || r.text === ''; });
      if (bu && bu.type !== 'none' && !plain) {
        if (bu.type === 'char') {
          bulletText = bu.ch;
          if (/wingdings/i.test(st.buFont || '') || (/symbol/i.test(st.buFont || ''))) bulletText = WINGDINGS[bulletText] || '\u2022';
        } else if (bu.type === 'auto') {
          counters.length = Math.max(counters.length, lvl + 1);
          var cur = counters[lvl];
          cur = (cur == null) ? bu.start : cur + 1;
          counters[lvl] = cur;
          bulletText = autoNumText(bu.kind, cur);
        }
      }
      if (!bu || bu.type !== 'auto' || plain) { if (!(bu && bu.type === 'auto')) counters[lvl] = null; }
      if (lvl < lastLvl) counters.length = lvl + 1;      // leaving deeper levels resets their numbering
      lastLvl = lvl;

      var pd = document.createElement('div');
      var marL = (st.marL || 0) / EMU, indent = (st.indent || 0) / EMU;
      if (marL + indent < 0) indent = -marL;
      var algn = { l: 'left', ctr: 'center', r: 'right', just: 'justify', dist: 'justify', justLow: 'justify' }[st.algn || 'l'] || 'left';
      var ls = st.lnSpc, lh;
      if (ls && ls.pts != null) lh = (ls.pts * 96 / 72) + 'px';
      else lh = String(((ls && ls.pct != null ? ls.pct : 100) / 100) * 1.2 * (1 - lnRed));
      function spc(s) {
        if (!s) return 0;
        if (s.pts != null) return s.pts * 96 / 72;
        return (s.pct / 100) * fsPx0 * 1.2 * scale;
      }
      var mt = first ? 0 : spc(st.spcBef), mb = spc(st.spcAft);
      pd.style.cssText = 'margin:' + mt + 'px 0 ' + mb + 'px 0;padding:0 ' + ((st.marR || 0) / EMU) + 'px 0 ' + marL + 'px;text-indent:' + indent + 'px;text-align:' + algn +
        ';line-height:' + lh + ';white-space:' + (bp.wrap ? 'pre-wrap' : 'pre') + ';overflow-wrap:' + (bp.wrap ? 'break-word' : 'normal') + ';';
      first = false;

      if (bulletText) {
        var bs = document.createElement('span');
        var bsz = (st.buSz || 1);
        var bcol = st.buClr || (runs.length ? runs[0].rpr.color : null) || endRpr.color;
        var bw = indent < 0 ? -indent : Math.max(indent, fsPx0 * 0.9);
        bs.style.cssText = 'display:inline-block;text-indent:0;white-space:nowrap;width:' + bw + 'px;font-size:calc(' + (fsPx0 * bsz) + 'px * var(--sfs));color:' + (bcol ? css(bcol) : 'rgb(0,0,0)') +
          ';font-family:' + (bu && bu.type === 'char' && /wingdings|symbol/i.test(st.buFont || '') ? 'Arial,"Segoe UI Symbol",sans-serif' : (st.buFont ? '"' + st.buFont + '",Arial,sans-serif' : 'inherit')) + ';';
        bs.textContent = bulletText;
        pd.appendChild(bs);
      }
      function mkSpan(rpr, text) {
        var s = document.createElement('span');
        var sz = (rpr.sz || 1800) / 75;
        var mul = rpr.baseline ? (rpr.baseline > 0 ? 0.65 : 0.65) : 1;
        var col = rpr.color || { rgb: [0, 0, 0], a: 1 };
        var deco = [];
        var u = rpr.u, hl = rpr.hlink;
        if (hl) { col = colorFromEl({ localName: 'schemeClr', getAttribute: function () { return 'hlink'; }, firstElementChild: null }, ctx) || col; u = true; }
        if (u) deco.push('underline');
        if (rpr.strike) deco.push('line-through');
        var cssText = 'font-size:calc(' + (sz * mul) + 'px * var(--sfs));font-family:' + fontStack(rpr, ctx, text) + ';color:' + css(col) + ';';
        if (rpr.b) cssText += 'font-weight:700;';
        if (rpr.i) cssText += 'font-style:italic;';
        if (deco.length) cssText += 'text-decoration:' + deco.join(' ') + ';';
        if (rpr.baseline) cssText += 'vertical-align:' + (rpr.baseline > 0 ? 'super' : 'sub') + ';';
        if (rpr.cap === 'all') cssText += 'text-transform:uppercase;'; else if (rpr.cap === 'small') cssText += 'font-variant:small-caps;';
        if (rpr.spc) cssText += 'letter-spacing:' + (rpr.spc / 100 * 96 / 72) + 'px;';
        s.style.cssText = cssText;
        s.textContent = text;
        return s;
      }
      runs.forEach(function (r) {
        if (r.br) { pd.appendChild(document.createElement('br')); return; }
        if (r.text === '') return;
        pd.appendChild(mkSpan(r.rpr, r.text));
      });
      if (plain) pd.appendChild(mkSpan(endRpr, '\u200b'));   // keep the line height of an empty paragraph
      pd.setAttribute('data-para', String(paraIdx));
      box.appendChild(pd);
    });
    parent.appendChild(box);
    return box;
  }

  // ------------------------------------------------------------------ shapes
  function normType(t) {
    if (!t || t === 'obj' || t === 'body' || t === 'subTitle') return 'body';
    if (t === 'title' || t === 'ctrTitle') return 'title';
    return t;
  }
  function phOf(node) {
    var nv = node.firstElementChild;
    return nv ? kidPath(nv, 'nvPr', 'ph') : null;
  }
  function matchPh(tree, ph) {
    if (!tree || !ph) return null;
    var idx = attr(ph, 'idx', null), nt = normType(attr(ph, 'type', null)), best = null, c, p;
    var list = kids(tree);
    if (idx != null) {
      for (var i = 0; i < list.length; i++) {
        c = list[i]; p = phOf(c);
        if (p && attr(p, 'idx', null) === idx && normType(attr(p, 'type', null)) === nt) return c;
      }
    }
    for (var j = 0; j < list.length; j++) {
      c = list[j]; p = phOf(c);
      if (p && normType(attr(p, 'type', null)) === nt) { if (!best) best = c; if (idx == null || attr(p, 'idx', null) == null) return c; }
    }
    if (best) return best;
    if (idx != null) {
      for (var k = 0; k < list.length; k++) { c = list[k]; p = phOf(c); if (p && attr(p, 'idx', null) === idx) return c; }
    }
    return null;
  }
  function inheritFor(ctx, ph) {
    var o = { layoutSp: null, masterSp: null };
    if (!ph) return o;
    if (ctx.level === 'slide') { o.layoutSp = matchPh(ctx.layoutTree, ph); o.masterSp = matchPh(ctx.masterTree, ph); }
    else if (ctx.level === 'layout') { o.masterSp = matchPh(ctx.masterTree, ph); }
    return o;
  }
  function firstWith(chain, name) {
    for (var i = 0; i < chain.length; i++) { var k = kid(chain[i], name); if (k) return k; }
    return null;
  }
  function boxOf(xfrm, map) {
    var off = kid(xfrm, 'off'), ext = kid(xfrm, 'ext');
    return {
      x: (num(off, 'x', 0) - map.ox) * map.sx / EMU, y: (num(off, 'y', 0) - map.oy) * map.sy / EMU,
      w: num(ext, 'cx', 0) * map.sx / EMU, h: num(ext, 'cy', 0) * map.sy / EMU,
      rot: num(xfrm, 'rot', 0) / 60000, fh: bool(xfrm, 'flipH', false), fv: bool(xfrm, 'flipV', false)
    };
  }
  function place(d, b) {
    d.style.position = 'absolute';
    d.style.left = b.x + 'px'; d.style.top = b.y + 'px';
    d.style.width = b.w + 'px'; d.style.height = b.h + 'px';
    if (b.rot) d.style.transform = 'rotate(' + b.rot + 'deg)';
  }
  function textChainFor(ctx, node, php, inh, fontRefCol) {
    var chain = [ctx.defaultTextStyle];
    if (php) {
      var k = normType(attr(php, 'type', null));
      var ts = ctx.txStyles && ctx.txStyles[k === 'title' ? 'titleStyle' : (k === 'body' ? 'bodyStyle' : 'otherStyle')];
      chain.push(ts);
      chain.push(inh.masterSp ? kidPath(inh.masterSp, 'txBody', 'lstStyle') : null);
      chain.push(inh.layoutSp ? kidPath(inh.layoutSp, 'txBody', 'lstStyle') : null);
    }
    if (fontRefCol) chain.push({ rpr: { color: fontRefCol } });
    chain.push(kidPath(node, 'txBody', 'lstStyle'));
    return chain;
  }
  var DASH = { dash: [4, 3], sysDash: [3, 1], dot: [1, 3], sysDot: [1, 1], lgDash: [8, 3], dashDot: [4, 3, 1, 3], lgDashDot: [8, 3, 1, 3], sysDashDot: [3, 1, 1, 1], sysDashDotDot: [3, 1, 1, 1, 1, 1], lgDashDotDot: [8, 3, 1, 3, 1, 3] };
  var MARKER = { triangle: 'M0,0 L10,5 L0,10 Z', arrow: 'M0,0 L10,5 L0,10 L2,5 Z', stealth: 'M0,0 L10,5 L0,10 L3,5 Z', diamond: 'M5,0 L10,5 L5,10 L0,5 Z', oval: 'M5,0 A5,5 0 1 1 5,10 A5,5 0 1 1 5,0 Z' };

  function lineColor(line) {
    if (!line || !line.fill || line.fill.t === 'none') return null;
    if (line.fill.t === 'solid') return line.fill.c;
    if (line.fill.t === 'grad') return line.fill.stops[0].c;
    return null;
  }

  function svgFor(paths, w, h, fill, line, flipH, flipV) {
    var id = uid('g'), defs = '', body = '';
    var lc = lineColor(line);
    var lw = line && line.w != null ? line.w : (lc ? 1.333 : 0);
    var fillAttr = 'none', fillOp = 1, clipId = null, imgFill = null;
    if (fill && fill.t === 'solid') { fillAttr = 'rgb(' + fill.c.rgb.join(',') + ')'; fillOp = fill.c.a; }
    else if (fill && fill.t === 'grad') { defs += gradDefs(fill, w, h, id); fillAttr = 'url(#' + id + ')'; }
    else if (fill && fill.t === 'blip') { imgFill = fill; clipId = id + 'c'; }
    var strokeAttrs = '';
    if (lc && lw > 0) {
      strokeAttrs = ' stroke="rgb(' + lc.rgb.join(',') + ')" stroke-opacity="' + lc.a + '" stroke-width="' + lw + '" stroke-linejoin="round"';
      if (line.cap === 'rnd') strokeAttrs += ' stroke-linecap="round"'; else if (line.cap === 'sq') strokeAttrs += ' stroke-linecap="square"';
      if (line.dash && DASH[line.dash]) { var u = Math.max(lw, 1); strokeAttrs += ' stroke-dasharray="' + DASH[line.dash].map(function (x) { return x * u; }).join(' ') + '"'; }
    }
    var mStart = '', mEnd = '';
    if (lc && lw > 0) {
      var rgb = 'rgb(' + lc.rgb.join(',') + ')';
      if (line.head && MARKER[line.head]) { defs += '<marker id="' + id + 'h" viewBox="0 0 10 10" refX="3" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse"><path d="' + MARKER[line.head] + '" fill="' + rgb + '"/></marker>'; mStart = ' marker-start="url(#' + id + 'h)"'; }
      if (line.tail && MARKER[line.tail]) { defs += '<marker id="' + id + 't" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="4" markerHeight="4" orient="auto"><path d="' + MARKER[line.tail] + '" fill="' + rgb + '"/></marker>'; mEnd = ' marker-end="url(#' + id + 't)"'; }
    }
    paths.forEach(function (p, i) {
      var f = p.noFill ? 'none' : fillAttr;
      var tr = p.tr ? ' transform="' + p.tr + '"' : '';
      var ve = p.ve ? ' vector-effect="non-scaling-stroke"' : '';
      var st = p.noStroke ? '' : strokeAttrs;
      if (imgFill && !p.noFill) {
        defs += '<clipPath id="' + clipId + i + '"><path d="' + p.d + '"' + tr + '/></clipPath>';
        body += '<image href="' + esc(imgFill.url) + '" x="0" y="0" width="' + w + '" height="' + h + '" preserveAspectRatio="none" opacity="' + imgFill.alpha + '" clip-path="url(#' + clipId + i + ')"/>';
        if (st) body += '<path d="' + p.d + '" fill="none"' + st + tr + ve + '/>';
      } else {
        body += '<path d="' + p.d + '" fill="' + f + '" fill-opacity="' + fillOp + '"' + (p.rule ? ' fill-rule="' + p.rule + '"' : '') + st + tr + ve + (i === 0 ? mStart + mEnd : '') + '/>';
      }
    });
    var flip = (flipH || flipV) ? 'transform:scale(' + (flipH ? -1 : 1) + ',' + (flipV ? -1 : 1) + ');' : '';
    return '<svg xmlns="' + SVGNS + '" width="' + Math.max(w, 0.01) + '" height="' + Math.max(h, 0.01) + '" viewBox="0 0 ' + Math.max(w, 0.01) + ' ' + Math.max(h, 0.01) +
      '" style="position:absolute;left:0;top:0;overflow:visible;' + flip + '"><defs>' + defs + '</defs>' + body + '</svg>';
  }

  function renderSp(node, ctx, map, parent) {
    var isCxn = node.localName === 'cxnSp';
    var nv = node.firstElementChild;
    if (bool(kid(nv, 'cNvPr'), 'hidden', false)) return;
    var php = phOf(node);
    var inh = inheritFor(ctx, php);
    var spPr = kid(node, 'spPr');
    var chain = [spPr, inh.layoutSp ? kid(inh.layoutSp, 'spPr') : null, inh.masterSp ? kid(inh.masterSp, 'spPr') : null].filter(Boolean);
    var xfrm = firstWith(chain, 'xfrm');
    if (!xfrm) return;
    var b = boxOf(xfrm, map);
    var style = kid(node, 'style');

    // geometry
    var geom = firstWith(chain, 'prstGeom'), cust = firstWith(chain, 'custGeom'), paths = null;
    var spGeom = spPr && (kid(spPr, 'prstGeom') || kid(spPr, 'custGeom'));
    if (spGeom) { geom = kid(spPr, 'prstGeom'); cust = kid(spPr, 'custGeom'); }
    if (cust) paths = custPaths(cust, b.w, b.h);
    else {
      var name = geom ? attr(geom, 'prst', 'rect') : (isCxn ? 'line' : 'rect');
      var av = {};
      kids(kid(geom, 'avLst'), 'gd').forEach(function (g) {
        var m = /val\s+(-?\d+)/.exec(attr(g, 'fmla', ''));
        if (m) av[attr(g, 'name', '')] = parseFloat(m[1]);
      });
      paths = preset(name, b.w, b.h, av);
    }

    // paint
    var fill = null, i;
    for (i = 0; i < chain.length && !fill; i++) fill = parseFill(chain[i], ctx);
    if (!fill && style) { var fr = kid(style, 'fillRef'); fill = themeFill(ctx, num(fr, 'idx', 0), colorIn(fr, ctx)); }
    var line = null;
    if (style) { var lr = kid(style, 'lnRef'); line = themeLn(ctx, num(lr, 'idx', 0), colorIn(lr, ctx)); }
    for (i = chain.length - 1; i >= 0; i--) {
      var ln = kid(chain[i], 'ln');
      if (ln) line = mergeObj(line, lineFromEl(ln, ctx));
    }
    var visFill = fill && fill.t !== 'none';
    var visLine = lineColor(line) && (line.w == null || line.w > 0 || true);

    var d = document.createElement('div');
    place(d, b);
    if (paths && (visFill || visLine)) {
      var g = document.createElement('div');
      g.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;';
      g.innerHTML = svgFor(paths, b.w, b.h, fill, line, b.fh, b.fv);
      d.appendChild(g);
    }
    var txBody = kid(node, 'txBody');
    if (txBody && hasText(txBody)) {
      var fontRef = style ? kid(style, 'fontRef') : null;
      var fcol = fontRef ? colorIn(fontRef, ctx) : null;
      var bps = [kid(txBody, 'bodyPr'), inh.layoutSp ? kidPath(inh.layoutSp, 'txBody', 'bodyPr') : null, inh.masterSp ? kidPath(inh.masterSp, 'txBody', 'bodyPr') : null];
      renderText(txBody, d, ctx, { chain: textChainFor(ctx, node, php, inh, php ? null : fcol), bodyPr: bps });
    }
    parent.appendChild(d);
  }

  function renderPic(node, ctx, map, parent) {
    var nv = node.firstElementChild;
    if (bool(kid(nv, 'cNvPr'), 'hidden', false)) return;
    var php = phOf(node), inh = inheritFor(ctx, php);
    var spPr = kid(node, 'spPr');
    var chain = [spPr, inh.layoutSp ? kid(inh.layoutSp, 'spPr') : null, inh.masterSp ? kid(inh.masterSp, 'spPr') : null].filter(Boolean);
    var xfrm = firstWith(chain, 'xfrm');
    if (!xfrm) return;
    var b = boxOf(xfrm, map);
    var bf = kid(node, 'blipFill'), blip = kid(bf, 'blip');
    var url = blip ? ctx.imageUrl(rattr(blip, 'embed')) : null;
    if (!url) return;
    var d = document.createElement('div');
    place(d, b);
    d.style.overflow = 'hidden';
    var geom = spPr && kid(spPr, 'prstGeom');
    var prst = geom ? attr(geom, 'prst', 'rect') : 'rect', radius = '';
    if (prst === 'ellipse') radius = '50%';
    else if (prst === 'roundRect') radius = (Math.min(b.w, b.h) * 0.1667) + 'px';
    if (radius) d.style.borderRadius = radius;
    var src = kid(bf, 'srcRect');
    var l = num(src, 'l', 0) / 100000, t = num(src, 't', 0) / 100000, r = num(src, 'r', 0) / 100000, bt = num(src, 'b', 0) / 100000;
    var wf = Math.max(0.01, 1 - l - r), hf = Math.max(0.01, 1 - t - bt);
    var img = document.createElement('img');
    img.src = url; img.draggable = false;
    var amf = blip && kid(blip, 'alphaModFix');
    img.style.cssText = 'position:absolute;display:block;max-width:none;width:' + (100 / wf) + '%;height:' + (100 / hf) + '%;left:' + (-l / wf * 100) + '%;top:' + (-t / hf * 100) + '%;' +
      (b.fh || b.fv ? 'transform:scale(' + (b.fh ? -1 : 1) + ',' + (b.fv ? -1 : 1) + ');' : '') + (amf ? 'opacity:' + (num(amf, 'amt', 100000) / 100000) + ';' : '');
    d.appendChild(img);
    parent.appendChild(d);
    var ln = spPr && kid(spPr, 'ln');
    if (ln) {
      var lf = lineFromEl(ln, ctx), lc = lineColor(lf);
      if (lc) {
        var o = document.createElement('div');
        o.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;pointer-events:none;border:' + (lf.w != null ? lf.w : 1.333) + 'px solid ' + css(lc) + (radius ? ';border-radius:' + radius : '') + ';';
        // outline drawn on a sibling so it is not clipped by the picture box
        var holder = document.createElement('div');
        place(holder, b);
        holder.appendChild(o);
        parent.appendChild(holder);
      }
    }
  }

  function renderGroup(node, ctx, map, parent) {
    var nv = node.firstElementChild;
    if (bool(kid(nv, 'cNvPr'), 'hidden', false)) return;
    var gp = kid(node, 'grpSpPr'), xfrm = kid(gp, 'xfrm');
    if (!xfrm) return;
    var b = boxOf(xfrm, map);
    var chOff = kid(xfrm, 'chOff'), chExt = kid(xfrm, 'chExt');
    var cx = num(chExt, 'cx', 0), cy = num(chExt, 'cy', 0), ext = kid(xfrm, 'ext');
    var sx = cx ? num(ext, 'cx', cx) / cx * map.sx : map.sx, sy = cy ? num(ext, 'cy', cy) / cy * map.sy : map.sy;
    var d = document.createElement('div');
    place(d, b);
    if (b.fh || b.fv) d.style.transform = (b.rot ? 'rotate(' + b.rot + 'deg) ' : '') + 'scale(' + (b.fh ? -1 : 1) + ',' + (b.fv ? -1 : 1) + ')';
    var cmap = { ox: num(chOff, 'x', 0), oy: num(chOff, 'y', 0), sx: sx, sy: sy };
    renderTree(node, ctx, cmap, d, false);
    parent.appendChild(d);
  }

  // ------------------------------------------------------------------ tables
  function C1(rgb) { return { rgb: rgb, a: 1 }; }
  function F1(rgb) { return { t: 'solid', c: { rgb: rgb, a: 1 } }; }
  function tintRgb(rgb, v) { return rgb.map(function (x) { return fromLin(toLin(x) * v + (1 - v)); }); }
  var ACCENT_STYLE = { '{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}': 'accent1', '{21E4AEA4-8DFA-4A89-87EB-49C32662AFE0}': 'accent2', '{F5AB1C69-6EDB-4FF4-983F-18BD219EF322}': 'accent3', '{00A15C55-8517-42AA-B614-E9B94910E393}': 'accent4', '{7DF18680-E054-41AD-8BC1-D1AEF772440D}': 'accent5', '{93296810-A885-4BE3-A3E7-6D5BEEA58F35}': 'accent6' };
  function builtinTableStyle(id, ctx) {
    var acc = ACCENT_STYLE[String(id || '').toUpperCase()];
    var D = hex2rgb(themeColorHex(ctx, 'dk1')), W = hex2rgb(themeColorHex(ctx, 'lt1'));
    if (String(id || '').toUpperCase() === '{5940675A-B579-460E-94D1-54222C63F5DA}') {     // No Style, Table Grid
      var g = { w: 1.333, c: C1(D) };
      return { whole: { txColor: C1(D), bdr: { top: g, bottom: g, left: g, right: g, insideH: g, insideV: g } } };
    }
    if (!acc) return { whole: { txColor: C1(D) } };
    var A = hex2rgb(themeColorHex(ctx, acc)), b1 = { w: 1.333, c: C1(W) };
    return {
      whole: { txColor: C1(D), fill: F1(tintRgb(A, 0.2)), bdr: { top: b1, bottom: b1, left: b1, right: b1, insideH: b1, insideV: b1 } },
      band1H: { fill: F1(tintRgb(A, 0.4)) }, band1V: { fill: F1(tintRgb(A, 0.4)) },
      firstRow: { bold: true, txColor: C1(W), fill: F1(A), bdr: { bottom: { w: 4, c: C1(W) } } },
      lastRow: { bold: true, txColor: C1(W), fill: F1(A), bdr: { top: { w: 4, c: C1(W) } } },
      firstCol: { bold: true, txColor: C1(W), fill: F1(A) }, lastCol: { bold: true, txColor: C1(W), fill: F1(A) }
    };
  }
  function lnToBdr(ln, ctx) {
    if (!ln) return null;
    var lf = lineFromEl(ln, ctx), lc = lineColor(lf);
    if (!lc) return { none: true };
    return { w: lf.w != null ? lf.w : 1, c: lc };
  }
  function parseTableStyle(el, ctx) {
    var out = {}, names = { wholeTbl: 'whole', band1H: 'band1H', band2H: 'band2H', band1V: 'band1V', band2V: 'band2V', firstCol: 'firstCol', lastCol: 'lastCol', firstRow: 'firstRow', lastRow: 'lastRow' };
    Object.keys(names).forEach(function (n) {
      var part = kid(el, n);
      if (!part) return;
      var o = {}, tx = kid(part, 'tcTxStyle'), ts = kid(part, 'tcStyle');
      if (tx) {
        o.bold = attr(tx, 'b', 'off') === 'on';
        var fr = kid(tx, 'fontRef');
        o.txColor = colorIn(fr, ctx) || colorIn(tx, ctx);
      }
      if (ts) {
        var fe = kid(ts, 'fill');
        if (fe) o.fill = parseFill(fe, ctx);
        var fre = kid(ts, 'fillRef');
        if (!o.fill && fre) o.fill = themeFill(ctx, num(fre, 'idx', 0), colorIn(fre, ctx));
        var bd = kid(ts, 'tcBdr');
        if (bd) {
          o.bdr = {};
          ['left', 'right', 'top', 'bottom', 'insideH', 'insideV'].forEach(function (s) {
            var e = kid(bd, s), l = e && kid(e, 'ln');
            var v = l ? lnToBdr(l, ctx) : null;
            if (!v && e && kid(e, 'lnRef')) { var lr = kid(e, 'lnRef'); var tl = themeLn(ctx, num(lr, 'idx', 0), colorIn(lr, ctx)); v = tl && lineColor(tl) ? { w: tl.w != null ? tl.w : 1, c: lineColor(tl) } : null; }
            if (v) o.bdr[s] = v;
          });
        }
      }
      out[names[n]] = o;
    });
    return out;
  }
  function bdrCss(v) { return !v || v.none ? 'none' : (Math.max(0.5, v.w) + 'px solid ' + css(v.c)); }

  function renderTable(tbl, b, ctx, map, parent) {
    var cols = kids(kid(tbl, 'tblGrid'), 'gridCol').map(function (g) { return num(g, 'w', 0) * map.sx / EMU; });
    var rows = kids(tbl, 'tr');
    var pr = kid(tbl, 'tblPr');
    var flags = { firstRow: bool(pr, 'firstRow', false), lastRow: bool(pr, 'lastRow', false), firstCol: bool(pr, 'firstCol', false), lastCol: bool(pr, 'lastCol', false), bandRow: bool(pr, 'bandRow', false), bandCol: bool(pr, 'bandCol', false) };
    var sid = kid(pr, 'tableStyleId') ? kid(pr, 'tableStyleId').textContent.trim() : '';
    var style = null;
    if (ctx.tableStyles && sid && ctx.tableStyles[sid]) style = parseTableStyle(ctx.tableStyles[sid], ctx);
    if (!style) style = builtinTableStyle(sid || '{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}', ctx);
    var t = document.createElement('table');
    var totalW = cols.reduce(function (a, c) { return a + c; }, 0) || b.w;
    t.style.cssText = 'position:absolute;left:' + b.x + 'px;top:' + b.y + 'px;width:' + totalW + 'px;border-collapse:collapse;table-layout:fixed;border-spacing:0;';
    var cg = document.createElement('colgroup');
    cols.forEach(function (w) { var c = document.createElement('col'); c.style.width = w + 'px'; cg.appendChild(c); });
    t.appendChild(cg);
    var nR = rows.length, nC = cols.length;
    rows.forEach(function (tr, ri) {
      var trEl = document.createElement('tr');
      trEl.style.height = (num(tr, 'h', 0) * map.sy / EMU) + 'px';
      var ci = 0;
      kids(tr, 'tc').forEach(function (tc) {
        var myCi = ci; ci += 1;
        if (bool(tc, 'hMerge', false) || bool(tc, 'vMerge', false)) return;
        var td = document.createElement('td');
        var span = num(tc, 'gridSpan', 1), rspan = num(tc, 'rowSpan', 1);
        if (span > 1) { td.colSpan = span; ci = myCi + span; }
        if (rspan > 1) td.rowSpan = rspan;
        // resolve style parts
        var res = { fill: null, txColor: null, bold: false, edge: {} };
        function apply(part, isWhole) {
          if (!part) return;
          if (part.fill) res.fill = part.fill;
          if (part.txColor) res.txColor = part.txColor;
          if (part.bold != null) res.bold = part.bold || (isWhole ? false : res.bold);
          if (part.bdr) {
            Object.keys(part.bdr).forEach(function (k) {
              if (isWhole) res.edge['w_' + k] = part.bdr[k]; else res.edge['p_' + k] = part.bdr[k];
            });
          }
        }
        apply(style.whole, true);
        if (flags.bandRow && !(flags.firstRow && ri === 0) && !(flags.lastRow && ri === nR - 1)) apply(((ri - (flags.firstRow ? 1 : 0)) % 2 === 0) ? style.band1H : style.band2H);
        if (flags.bandCol && !(flags.firstCol && myCi === 0)) apply(((myCi - (flags.firstCol ? 1 : 0)) % 2 === 0) ? style.band1V : style.band2V);
        if (flags.firstCol && myCi === 0) apply(style.firstCol);
        if (flags.lastCol && myCi === nC - 1) apply(style.lastCol);
        if (flags.firstRow && ri === 0) apply(style.firstRow);
        if (flags.lastRow && ri === nR - 1) apply(style.lastRow);
        function edge(side, outer, inner) {
          var v = res.edge['p_' + side] || (outer ? res.edge['w_' + side] : res.edge['w_' + inner]);
          return v;
        }
        var lastC = myCi + span >= nC, lastR = ri + rspan >= nR;
        var bTop = edge('top', ri === 0, 'insideH'), bBot = edge('bottom', lastR, 'insideH'), bLeft = edge('left', myCi === 0, 'insideV'), bRight = edge('right', lastC, 'insideV');
        var pr2 = kid(tc, 'tcPr');
        var ov = { Top: 'lnT', Bottom: 'lnB', Left: 'lnL', Right: 'lnR' };
        var bd = { Top: bTop, Bottom: bBot, Left: bLeft, Right: bRight };
        Object.keys(ov).forEach(function (s) { var l = kid(pr2, ov[s]); if (l) bd[s] = lnToBdr(l, ctx); });
        var cellFill = pr2 ? parseFill(pr2, ctx) : null;
        var f = cellFill || res.fill;
        var cs = 'vertical-align:' + ({ t: 'top', ctr: 'middle', b: 'bottom' }[attr(pr2, 'anchor', 't')] || 'top') + ';overflow:visible;box-sizing:border-box;' +
          'padding:' + (num(pr2, 'marT', 45720) / EMU) + 'px ' + (num(pr2, 'marR', 91440) / EMU) + 'px ' + (num(pr2, 'marB', 45720) / EMU) + 'px ' + (num(pr2, 'marL', 91440) / EMU) + 'px;' +
          'border-top:' + bdrCss(bd.Top) + ';border-bottom:' + bdrCss(bd.Bottom) + ';border-left:' + bdrCss(bd.Left) + ';border-right:' + bdrCss(bd.Right) + ';';
        var bg = fillCss(f);
        if (bg) cs += 'background:' + bg + ';';
        td.style.cssText = cs;
        var txBody = kid(tc, 'txBody');
        if (txBody) {
          var base = {};
          if (res.txColor) base.color = res.txColor;
          if (res.bold) base.b = true;
          renderText(txBody, td, ctx, { chain: [ctx.defaultTextStyle, kid(txBody, 'lstStyle')], bodyPr: [], baseRpr: base, flow: true });
        }
        trEl.appendChild(td);
      });
      t.appendChild(trEl);
    });
    parent.appendChild(t);
  }

  // ------------------------------------------------------------------ frames (table / chart / SmartArt)
  function renderFrame(node, ctx, map, parent) {
    var nv = node.firstElementChild;
    if (bool(kid(nv, 'cNvPr'), 'hidden', false)) return;
    var xfrm = kid(node, 'xfrm');
    if (!xfrm) { var ph = phOf(node), inh = inheritFor(ctx, ph); xfrm = inh.layoutSp ? kidPath(inh.layoutSp, 'spPr', 'xfrm') : null; }
    if (!xfrm) return;
    var b = boxOf(xfrm, map);
    var gd = kidPath(node, 'graphic', 'graphicData');
    if (!gd) return;
    var tbl = kid(gd, 'tbl'), ch = kid(gd, 'chart'), rel = kid(gd, 'relIds');
    if (tbl) { renderTable(tbl, b, ctx, map, parent); return; }
    var d = document.createElement('div');
    place(d, b);
    if (ch) {
      var cdoc = ctx.chartDoc(rattr(ch, 'id'));
      if (cdoc && root.__sfpChart) root.__sfpChart(cdoc, d, b.w, b.h, ctx);
      parent.appendChild(d);
      return;
    }
    if (rel) {
      var dd = ctx.diagramDrawing(rattr(rel, 'dm'));
      if (dd) {
        var tree = findFirst(dd, 'spTree');
        if (tree) {
          var dctx = Object.create(ctx);
          dctx.imageUrl = dd.__imageUrl || ctx.imageUrl;
          dctx.noTag = true;
          renderTree(tree, dctx, { ox: 0, oy: 0, sx: map.sx, sy: map.sy }, d, false);
        }
      }
      parent.appendChild(d);
    }
  }

  function renderNode(node, ctx, map, parent) {
    var before = parent.childNodes.length;
    renderNode0(node, ctx, map, parent);
    if (ctx.level !== 'slide' || ctx.noTag) return;
    var ln = node.localName;
    if (ln !== 'sp' && ln !== 'pic' && ln !== 'grpSp' && ln !== 'graphicFrame' && ln !== 'cxnSp') return;
    var c = kid(node.firstElementChild, 'cNvPr'), id = c ? c.getAttribute('id') : null;
    if (id == null) return;
    for (var i = before; i < parent.childNodes.length; i++) {
      var n = parent.childNodes[i];
      if (n.setAttribute) n.setAttribute('data-spid', id);
    }
  }
  function renderNode0(node, ctx, map, parent) {
    switch (node.localName) {
      case 'sp': case 'cxnSp': renderSp(node, ctx, map, parent); break;
      case 'pic': renderPic(node, ctx, map, parent); break;
      case 'grpSp': renderGroup(node, ctx, map, parent); break;
      case 'graphicFrame': renderFrame(node, ctx, map, parent); break;
      case 'AlternateContent': {
        var fb = kid(node, 'Fallback') || kid(node, 'Choice');
        if (fb) kids(fb).forEach(function (c) { renderNode(c, ctx, map, parent); });
        break;
      }
    }
  }
  function renderTree(tree, ctx, map, parent, onlyNonPh) {
    kids(tree).forEach(function (n) {
      if (n.localName === 'nvGrpSpPr' || n.localName === 'grpSpPr') return;
      if (onlyNonPh && phOf(n)) return;
      renderNode(n, ctx, map, parent);
    });
  }

  // ------------------------------------------------------------------ charts (basic: bar/column, line, area, pie, doughnut)
  (function () {
    function cacheOf(el) {
      if (!el) return [];
      var ref = kid(el, 'strRef') || kid(el, 'numRef'), cache = ref ? (kid(ref, 'strCache') || kid(ref, 'numCache')) : (kid(el, 'strLit') || kid(el, 'numLit'));
      if (!cache) return [];
      var n = num(kid(cache, 'ptCount'), 'val', 0), arr = [];
      for (var i = 0; i < n; i++) arr.push(null);
      kids(cache, 'pt').forEach(function (pt) { var v = kid(pt, 'v'); arr[num(pt, 'idx', 0)] = v ? v.textContent : null; });
      return arr;
    }
    function textOf(rich) {
      if (!rich) return '';
      return kids(rich, 'p').map(function (p) { return Array.prototype.map.call(p.getElementsByTagNameNS('*', 't'), function (t) { return t.textContent; }).join(''); }).join(' ');
    }
    function fmt(v, code) {
      if (v == null || isNaN(v)) return '';
      code = code || 'General';
      var pct = /%/.test(code), x = pct ? v * 100 : v;
      var m = /0\.(0+)/.exec(code), dec = m ? m[1].length : (Math.abs(x) >= 100 || x === Math.round(x) ? 0 : 2);
      var s = (/#,#/.test(code) || Math.abs(x) >= 10000) ? x.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec }) : x.toFixed(dec);
      if (!m && !pct && x !== Math.round(x)) s = String(Math.round(x * 100) / 100);
      if (/\$/.test(code)) s = '$' + s;
      return s + (pct ? '%' : '');
    }
    function niceMax(range, n) {
      if (!(range > 0)) return 1;
      var raw = range / n, mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), norm = raw / mag;
      var m = norm <= 1 ? 1 : (norm <= 2 ? 2 : (norm <= 2.5 ? 2.5 : (norm <= 5 ? 5 : 10)));
      return m * mag;
    }
    root.__sfpChart = function (doc, host, w, h, ctx) {
      var cs = doc.documentElement, chart = kid(cs, 'chart'), plot = kid(chart, 'plotArea');
      if (!plot) return;
      var baseSz = 1200, tx = kidPath(cs, 'txPr', 'p', 'pPr', 'defRPr');
      if (tx && attr(tx, 'sz', null)) baseSz = num(tx, 'sz', 1200);
      var fs = baseSz / 75, txtCol = '#404040';
      var kind = null, node = null;
      kids(plot).forEach(function (c) { if (!node && /Chart$/.test(c.localName) && c.localName !== 'bar3DChart') { node = c; kind = c.localName; } });
      if (!node) { node = kids(plot).filter(function (c) { return /Chart$/.test(c.localName); })[0]; kind = node ? node.localName : null; }
      if (!node) return;
      function pal(i) {
        var hex = themeColorHex(ctx, 'accent' + ((i % 6) + 1)), rgb = hex2rgb(hex);
        if (i >= 6) { var f = i < 12 ? 0.75 : 1.25; rgb = rgb.map(function (x) { return Math.max(0, Math.min(255, Math.round(x * f))); }); }
        return 'rgb(' + rgb.join(',') + ')';
      }
      var series = kids(node, 'ser').map(function (ser, i) {
        var col = null, sp = kid(ser, 'spPr');
        if (sp) { var f = parseFill(sp, ctx); if (f && f.t === 'solid') col = css(f.c); if (!col) { var l = kid(sp, 'ln'); var lf = l ? lineFromEl(l, ctx) : null; var lc = lineColor(lf); if (lc) col = css(lc); } }
        var dpt = {};
        kids(ser, 'dPt').forEach(function (d) { var f2 = parseFill(kid(d, 'spPr'), ctx); if (f2 && f2.t === 'solid') dpt[num(kid(d, 'idx'), 'val', 0)] = css(f2.c); });
        var nm = cacheOf(kid(ser, 'tx'))[0];
        var vals = cacheOf(kid(ser, 'val')).map(function (v) { return v == null || v === '' ? null : parseFloat(v); });
        var cats = cacheOf(kid(ser, 'cat'));
        var dl = kid(ser, 'dLbls') || kid(node, 'dLbls');
        return { name: nm || ('Series ' + (i + 1)), vals: vals, cats: cats, color: col || pal(i), dpt: dpt, showVal: !!dl && attr(kid(dl, 'showVal'), 'val', '0') === '1', showPct: !!dl && attr(kid(dl, 'showPercent'), 'val', '0') === '1' };
      });
      if (!series.length) return;
      var cats = series[0].cats.length ? series[0].cats : series[0].vals.map(function (_, i) { return String(i + 1); });
      var titleEl = kid(chart, 'title'), title = titleEl && attr(kid(chart, 'autoTitleDeleted'), 'val', '0') !== '1' ? textOf(kidPath(titleEl, 'tx', 'rich')) : '';
      if (!title && series.length === 1 && attr(kid(chart, 'autoTitleDeleted'), 'val', '0') !== '1') title = series[0].name;
      var legend = kid(chart, 'legend'), lpos = legend ? attr(kid(legend, 'legendPos'), 'val', 'r') : null;
      var out = [];
      var top = 8, bottom = 8, left = 8, right = 8;
      if (title) { out.push('<text x="' + w / 2 + '" y="' + (fs * 1.3 + 4) + '" text-anchor="middle" font-size="' + (fs * 1.4) + '" font-weight="600" fill="' + txtCol + '">' + esc(title) + '</text>'); top += fs * 2.2; }
      var items = (/pie|doughnut/.test(kind) ? cats.map(function (c, i) { return { n: c, c: series[0].dpt[i] || pal(i) }; }) : series.map(function (s) { return { n: s.name, c: s.color }; }));
      if (legend) {
        var itemW = items.map(function (it) { return fs * 0.62 * String(it.n == null ? '' : it.n).length + fs * 2.2; });
        if (lpos === 'b' || lpos === 't') {
          var tot = itemW.reduce(function (a, b2) { return a + b2; }, 0), x0 = Math.max(8, (w - tot) / 2), ly = lpos === 'b' ? h - fs - 2 : top + fs;
          items.forEach(function (it, i) {
            out.push('<rect x="' + x0 + '" y="' + (ly - fs * 0.8) + '" width="' + fs * 0.8 + '" height="' + fs * 0.8 + '" fill="' + it.c + '"/><text x="' + (x0 + fs * 1.1) + '" y="' + ly + '" font-size="' + fs + '" fill="' + txtCol + '">' + esc(it.n) + '</text>');
            x0 += itemW[i];
          });
          if (lpos === 'b') bottom += fs * 2; else top += fs * 2;
        } else {
          var maxW = Math.max.apply(null, itemW) + 8, lx = lpos === 'l' ? 8 : w - maxW, ly2 = h / 2 - items.length * fs * 0.8;
          items.forEach(function (it, i) {
            out.push('<rect x="' + lx + '" y="' + (ly2 + i * fs * 1.6 - fs * 0.8) + '" width="' + fs * 0.8 + '" height="' + fs * 0.8 + '" fill="' + it.c + '"/><text x="' + (lx + fs * 1.1) + '" y="' + (ly2 + i * fs * 1.6) + '" font-size="' + fs + '" fill="' + txtCol + '">' + esc(it.n) + '</text>');
          });
          if (lpos === 'l') left += maxW; else right += maxW;
        }
      }
      var fmtCode = attr(kidPath(plot, 'valAx', 'numFmt'), 'formatCode', 'General');
      if (/pie|doughnut/.test(kind)) {
        var vals = series[0].vals.map(function (v) { return v || 0; }), sum = vals.reduce(function (a, b2) { return a + b2; }, 0) || 1;
        var cx = left + (w - left - right) / 2, cy = top + (h - top - bottom) / 2, R = Math.min(w - left - right, h - top - bottom) / 2 - 4, a0 = -Math.PI / 2;
        var hole = kind === 'doughnutChart' ? R * (num(kid(node, 'holeSize'), 'val', 50) / 100) : 0;
        vals.forEach(function (v, i) {
          var a1 = a0 + v / sum * 2 * Math.PI, large = (a1 - a0) > Math.PI ? 1 : 0, col = series[0].dpt[i] || pal(i), d;
          if (v / sum > 0.9999) d = hole ? 'M' + (cx - R) + ',' + cy + ' A' + R + ',' + R + ' 0 1 1 ' + (cx + R) + ',' + cy + ' A' + R + ',' + R + ' 0 1 1 ' + (cx - R) + ',' + cy + ' Z M' + (cx - hole) + ',' + cy + ' A' + hole + ',' + hole + ' 0 1 0 ' + (cx + hole) + ',' + cy + ' A' + hole + ',' + hole + ' 0 1 0 ' + (cx - hole) + ',' + cy + ' Z' : 'M' + (cx - R) + ',' + cy + ' A' + R + ',' + R + ' 0 1 1 ' + (cx + R) + ',' + cy + ' A' + R + ',' + R + ' 0 1 1 ' + (cx - R) + ',' + cy + ' Z';
          else d = 'M' + (cx + hole * Math.cos(a0)) + ',' + (cy + hole * Math.sin(a0)) + ' L' + (cx + R * Math.cos(a0)) + ',' + (cy + R * Math.sin(a0)) + ' A' + R + ',' + R + ' 0 ' + large + ' 1 ' + (cx + R * Math.cos(a1)) + ',' + (cy + R * Math.sin(a1)) + ' L' + (cx + hole * Math.cos(a1)) + ',' + (cy + hole * Math.sin(a1)) + (hole ? ' A' + hole + ',' + hole + ' 0 ' + large + ' 0 ' + (cx + hole * Math.cos(a0)) + ',' + (cy + hole * Math.sin(a0)) : '') + ' Z';
          out.push('<path d="' + d + '" fill="' + col + '" fill-rule="evenodd" stroke="#fff" stroke-width="1.5"/>');
          if ((series[0].showPct || series[0].showVal) && v > 0) {
            var am = (a0 + a1) / 2, rr = hole ? (R + hole) / 2 : R * 0.65;
            out.push('<text x="' + (cx + rr * Math.cos(am)) + '" y="' + (cy + rr * Math.sin(am) + fs * 0.35) + '" text-anchor="middle" font-size="' + fs + '" fill="#fff" font-weight="600">' + (series[0].showPct ? Math.round(v / sum * 100) + '%' : fmt(v, fmtCode)) + '</text>');
          }
          a0 = a1;
        });
      } else {
        var isBar = kind === 'barChart', horiz = isBar && attr(kid(node, 'barDir'), 'val', 'col') === 'bar';
        var grouping = attr(kid(node, 'grouping'), 'val', 'clustered'), stacked = /stacked/i.test(grouping), pctStack = /percent/i.test(grouping);
        var n = cats.length, lo = 0, hi = 0;
        var tot = cats.map(function (_, i) { var p = 0, ng = 0; series.forEach(function (s) { var v = s.vals[i] || 0; if (v >= 0) p += v; else ng += v; }); return [p, ng]; });
        if (stacked) { hi = Math.max.apply(null, tot.map(function (t) { return t[0]; })); lo = Math.min(0, Math.min.apply(null, tot.map(function (t) { return t[1]; }))); }
        else { series.forEach(function (s) { s.vals.forEach(function (v) { if (v != null) { hi = Math.max(hi, v); lo = Math.min(lo, v); } }); }); }
        if (pctStack) { hi = 1; lo = 0; }
        var mn = kidPath(plot, 'valAx', 'scaling', 'min'), mxEl = kidPath(plot, 'valAx', 'scaling', 'max');
        var ticks = 5, step = niceMax(hi - lo || 1, ticks);
        var axMax = mxEl ? num(mxEl, 'val', hi) : Math.ceil(hi / step - 1e-9) * step;
        var axMin = mn ? num(mn, 'val', lo) : (lo < 0 ? Math.floor(lo / step) * step : 0);
        if (axMax <= axMin) axMax = axMin + step;
        var labW = fs * 0.62 * Math.max.apply(null, [axMin, axMax].map(function (v) { return fmt(v, fmtCode).length; })) + 10;
        var maxCat = Math.max.apply(null, cats.map(function (c) { return String(c == null ? '' : c).length; }));
        var pl = left + (horiz ? Math.min(w * 0.3, fs * 0.6 * maxCat + 10) : labW), pr = w - right, pt = top, pb = h - bottom - (horiz ? fs * 1.6 : fs * 2);
        var pw = pr - pl, ph = pb - pt;
        function vpos(v) { return horiz ? pl + (v - axMin) / (axMax - axMin) * pw : pb - (v - axMin) / (axMax - axMin) * ph; }
        for (var tv = axMin; tv <= axMax + step * 0.001; tv += step) {
          var p2 = vpos(tv);
          out.push(horiz ? '<line x1="' + p2 + '" y1="' + pt + '" x2="' + p2 + '" y2="' + pb + '" stroke="#d9d9d9"/><text x="' + p2 + '" y="' + (pb + fs * 1.3) + '" text-anchor="middle" font-size="' + fs + '" fill="' + txtCol + '">' + fmt(pctStack ? tv : tv, pctStack ? '0%' : fmtCode) + '</text>'
            : '<line x1="' + pl + '" y1="' + p2 + '" x2="' + pr + '" y2="' + p2 + '" stroke="#d9d9d9"/><text x="' + (pl - 6) + '" y="' + (p2 + fs * 0.35) + '" text-anchor="end" font-size="' + fs + '" fill="' + txtCol + '">' + fmt(pctStack ? tv : tv, pctStack ? '0%' : fmtCode) + '</text>');
        }
        var slot = (horiz ? ph : pw) / n;
        cats.forEach(function (c, i) {
          var cpos = (horiz ? pt : pl) + slot * (i + 0.5), lab = esc(c == null ? '' : c);
          out.push(horiz ? '<text x="' + (pl - 6) + '" y="' + (pt + slot * (horiz ? (n - i - 0.5) : i) + fs * 0.35) + '" text-anchor="end" font-size="' + fs + '" fill="' + txtCol + '">' + lab + '</text>'
            : '<text x="' + cpos + '" y="' + (pb + fs * 1.4) + '" text-anchor="middle" font-size="' + fs + '" fill="' + txtCol + '">' + lab + '</text>');
        });
        var zero = vpos(Math.max(axMin, 0));
        out.push(horiz ? '<line x1="' + zero + '" y1="' + pt + '" x2="' + zero + '" y2="' + pb + '" stroke="#8c8c8c"/>' : '<line x1="' + pl + '" y1="' + zero + '" x2="' + pr + '" y2="' + zero + '" stroke="#8c8c8c"/>');
        if (isBar) {
          var gap = num(kid(node, 'gapWidth'), 'val', 150) / 100, overlap = stacked ? 1 : 0, ns = stacked ? 1 : series.length;
          var bw = slot / (ns - (ns - 1) * overlap * 0 + gap);   // width of one bar
          var posAcc = cats.map(function () { return 0; }), negAcc = cats.map(function () { return 0; });
          series.forEach(function (s, si) {
            s.vals.forEach(function (v, i) {
              if (v == null) return;
              var val = pctStack ? v / (tot[i][0] || 1) : v, a, b2;
              if (stacked) { if (val >= 0) { a = posAcc[i]; b2 = a + val; posAcc[i] = b2; } else { a = negAcc[i]; b2 = a + val; negAcc[i] = b2; } }
              else { a = Math.max(axMin, 0); b2 = val; }
              var off = stacked ? (slot - bw) / 2 : (slot - bw * ns) / 2 + bw * si;
              var colr = s.dpt[i] || s.color, rx, ry, rw, rh;
              if (horiz) { var xa = vpos(a), xb = vpos(b2); rx = Math.min(xa, xb); rw = Math.abs(xb - xa); ry = pt + slot * (n - i - 1) + off; rh = bw; }
              else { var ya = vpos(a), yb = vpos(b2); ry = Math.min(ya, yb); rh = Math.abs(yb - ya); rx = pl + slot * i + off; rw = bw; }
              out.push('<rect x="' + rx + '" y="' + ry + '" width="' + Math.max(rw, 0) + '" height="' + Math.max(rh, 0) + '" fill="' + colr + '"/>');
              if (s.showVal) out.push(horiz ? '<text x="' + (rx + rw + 4) + '" y="' + (ry + rh / 2 + fs * 0.35) + '" font-size="' + fs + '" fill="' + txtCol + '">' + fmt(v, fmtCode) + '</text>'
                : '<text x="' + (rx + rw / 2) + '" y="' + (ry - 4) + '" text-anchor="middle" font-size="' + fs + '" fill="' + txtCol + '">' + fmt(v, fmtCode) + '</text>');
            });
          });
        } else {
          series.forEach(function (s) {
            var pts = [];
            s.vals.forEach(function (v, i) { if (v != null) pts.push([pl + slot * (i + 0.5), vpos(v), v]); });
            if (!pts.length) return;
            if (kind === 'areaChart') {
              out.push('<path d="M' + pts[0][0] + ',' + zero + ' L' + pts.map(function (p) { return p[0] + ',' + p[1]; }).join(' L') + ' L' + pts[pts.length - 1][0] + ',' + zero + ' Z" fill="' + s.color + '" fill-opacity="0.65"/>');
            } else {
              out.push('<polyline points="' + pts.map(function (p) { return p[0] + ',' + p[1]; }).join(' ') + '" fill="none" stroke="' + s.color + '" stroke-width="2.5" stroke-linejoin="round"/>');
              pts.forEach(function (p) { out.push('<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3.5" fill="' + s.color + '"/>'); if (s.showVal) out.push('<text x="' + p[0] + '" y="' + (p[1] - 8) + '" text-anchor="middle" font-size="' + fs + '" fill="' + txtCol + '">' + fmt(p[2], fmtCode) + '</text>'); });
            }
          });
        }
      }
      host.innerHTML = '<svg xmlns="' + SVGNS + '" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" style="position:absolute;left:0;top:0;font-family:Calibri,\'Segoe UI\',Arial,sans-serif">' + out.join('') + '</svg>';
    };
  })();

  // ------------------------------------------------------------------ package / deck
  function dirname(p) { var i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }
  function resolvePath(base, target) {
    if (target.charAt(0) === '/') return target.slice(1);
    var parts = dirname(base).split('/').filter(Boolean);
    target.split('/').forEach(function (s) { if (s === '..') parts.pop(); else if (s !== '.' && s !== '') parts.push(s); });
    return parts.join('/');
  }
  function relsPath(part) { var i = part.lastIndexOf('/'); return part.slice(0, i + 1) + '_rels/' + part.slice(i + 1) + '.rels'; }
  var MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml', webp: 'image/webp', tif: 'image/tiff', tiff: 'image/tiff' };

  var AUDIO_MIME = { mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', flac: 'audio/flac', wma: 'audio/x-ms-wma', mid: 'audio/midi', midi: 'audio/midi' };

  function Package(zip) { this.zip = zip; this.docs = {}; this.blobs = {}; this.urls = []; }
  Package.prototype.doc = function (path) {
    var self = this;
    if (Object.prototype.hasOwnProperty.call(self.docs, path)) return Promise.resolve(self.docs[path]);
    if (!self.zip.has(path)) { self.docs[path] = null; return Promise.resolve(null); }
    return self.zip.read(path).then(function (bytes) {
      var d = new DOMParser().parseFromString(utf8.decode(bytes), 'application/xml');
      if (d.getElementsByTagName('parsererror').length) d = null;
      self.docs[path] = d;
      return d;
    });
  };
  Package.prototype.rels = function (part) {
    return this.doc(relsPath(part)).then(function (d) {
      var m = {};
      if (d) kids(d.documentElement, 'Relationship').forEach(function (r) {
        var ext = attr(r, 'TargetMode', 'Internal') === 'External';
        m[attr(r, 'Id', '')] = { type: attr(r, 'Type', ''), target: ext ? attr(r, 'Target', '') : resolvePath(part, attr(r, 'Target', '')), external: ext };
      });
      return m;
    });
  };
  Package.prototype.imageUrl = function (path) {
    var self = this;
    if (Object.prototype.hasOwnProperty.call(self.blobs, path)) return Promise.resolve(self.blobs[path]);
    var ext = path.split('.').pop().toLowerCase(), mime = MIME[ext];
    if (!mime || !self.zip.has(path)) { self.blobs[path] = null; return Promise.resolve(null); }
    return self.zip.read(path).then(function (bytes) {
      var url = URL.createObjectURL(new Blob([bytes], { type: mime }));
      self.urls.push(url);
      self.blobs[path] = url;
      return url;
    }).catch(function () { self.blobs[path] = null; return null; });
  };

  Package.prototype.audioUrl = function (path) {
    var self = this, ext = path.split('.').pop().toLowerCase(), mime = AUDIO_MIME[ext];
    if (!mime || !self.zip.has(path)) return Promise.resolve(null);
    return self.zip.read(path).then(function (bytes) {
      var url = URL.createObjectURL(new Blob([bytes], { type: mime }));
      self.urls.push(url);
      return url;
    }).catch(function () { return null; });
  };

  function parseTheme(doc) {
    var t = { colors: {}, major: '', minor: '', fill: [], ln: [], bgFill: [] };
    if (!doc) return t;
    var cs = findFirst(doc, 'clrScheme');
    kids(cs).forEach(function (c) {
      var col = c.firstElementChild;
      if (!col) return;
      t.colors[c.localName] = col.localName === 'sysClr' ? attr(col, 'lastClr', 'FFFFFF') : attr(col, 'val', '000000');
    });
    var mj = findFirst(doc, 'majorFont'), mn = findFirst(doc, 'minorFont');
    t.major = attr(kid(mj, 'latin'), 'typeface', '');
    t.minor = attr(kid(mn, 'latin'), 'typeface', '');
    var fs = findFirst(doc, 'fmtScheme');
    t.fill = kids(kid(fs, 'fillStyleLst'));
    t.ln = kids(kid(fs, 'lnStyleLst'));
    t.bgFill = kids(kid(fs, 'bgFillStyleLst'));
    return t;
  }
  function clrMapOf(el) {
    var m = { bg1: 'lt1', tx1: 'dk1', bg2: 'lt2', tx2: 'dk2' };
    if (el && el.attributes) for (var i = 0; i < el.attributes.length; i++) m[el.attributes[i].name] = el.attributes[i].value;
    return m;
  }

  function loadPart(pkg, path) {
    var part = { path: path, doc: null, rels: {}, imgs: {}, charts: {}, drawings: {} };
    return Promise.all([pkg.doc(path), pkg.rels(path)]).then(function (r) {
      part.doc = r[0]; part.rels = r[1];
      var chain = Promise.resolve();
      var drawRel = null;
      Object.keys(part.rels).forEach(function (id) { if (/\/diagramDrawing$/.test(part.rels[id].type)) drawRel = part.rels[id]; });
      Object.keys(part.rels).forEach(function (id) {
        var rel = part.rels[id];
        if (rel.external) return;
        chain = chain.then(function () {
          if (/\/image$/.test(rel.type)) return pkg.imageUrl(rel.target).then(function (u) { part.imgs[id] = u; });
          if (/\/chart$/.test(rel.type)) return pkg.doc(rel.target).then(function (d) { part.charts[id] = d; });
          if (/\/diagramData$/.test(rel.type)) {
            return pkg.doc(rel.target).then(function (dd) {
              var ext = dd ? findFirst(dd, 'dataModelExt') : null, rid = ext ? attr(ext, 'relId', null) : null;
              var dr = (rid && part.rels[rid]) || drawRel;
              if (!dr) return null;
              return Promise.all([pkg.doc(dr.target), pkg.rels(dr.target)]).then(function (x) {
                var drawDoc = x[0], drels = x[1];
                if (!drawDoc) return null;
                var di = {}, ch2 = Promise.resolve();
                Object.keys(drels).forEach(function (k) {
                  if (/\/image$/.test(drels[k].type)) ch2 = ch2.then(function () { return pkg.imageUrl(drels[k].target).then(function (u) { di[k] = u; }); });
                });
                return ch2.then(function () {
                  drawDoc.__imageUrl = function (rid2) { return di[rid2] || null; };
                  part.drawings[id] = drawDoc;
                });
              });
            });
          }
          return null;
        });
      });
      return chain;
    }).then(function () { return part; });
  }

  function Deck(pkg, info) {
    this.pkg = pkg;
    this.info = info;
    this.width = info.W;
    this.height = info.H;
    this.count = info.slides.length;
    this.prep = {};
    this.shared = {};
  }
  Deck.prototype.dispose = function () {
    this.pkg.urls.forEach(function (u) { try { URL.revokeObjectURL(u); } catch (e) {} });
    this.pkg.urls = [];
    this.prep = {};
  };
  /** First embedded audio file of the presentation (slide order): Promise<{ url, name, slide } | null>. */
  Deck.prototype.music = function () {
    var self = this, slides = self.info.slides, pkg = self.pkg;
    function scan(i) {
      if (i >= slides.length) return Promise.resolve(null);
      return pkg.rels(slides[i]).then(function (rels) {
        var found = null;
        Object.keys(rels).forEach(function (id) {
          var r = rels[id], ext = String(r.target).split('.').pop().toLowerCase();
          if (!found && !r.external && /\/(audio|media)$/.test(r.type) && AUDIO_MIME[ext] && pkg.zip.has(r.target)) found = r.target;
        });
        if (!found) return scan(i + 1);
        return pkg.audioUrl(found).then(function (url) {
          return url ? { url: url, name: found.split('/').pop(), slide: i } : scan(i + 1);
        });
      });
    }
    return scan(0).catch(function () { return null; });
  };
  Deck.prototype._shared = function (path) {
    var self = this;
    if (!self.shared[path]) self.shared[path] = loadPart(self.pkg, path);
    return self.shared[path];
  };
  Deck.prototype.prepare = function (i) {
    var self = this;
    if (self.prep[i]) return self.prep[i];
    var pr = (async function () {
      var sp = self.info.slides[i];
      var slide = await loadPart(self.pkg, sp);
      var layoutRel = null, k;
      for (k in slide.rels) if (/\/slideLayout$/.test(slide.rels[k].type)) layoutRel = slide.rels[k];
      if (!layoutRel) throw new Error('Slide ' + (i + 1) + ' has no layout');
      var layout = await self._shared(layoutRel.target);
      var masterRel = null;
      for (k in layout.rels) if (/\/slideMaster$/.test(layout.rels[k].type)) masterRel = layout.rels[k];
      if (!masterRel) throw new Error('Slide layout has no master');
      var master = await self._shared(masterRel.target);
      var themeRel = null;
      for (k in master.rels) if (/\/theme$/.test(master.rels[k].type)) themeRel = master.rels[k];
      var themeDoc = themeRel ? await self.pkg.doc(themeRel.target) : null;
      if (!master.theme) master.theme = parseTheme(themeDoc);
      return { slide: slide, layout: layout, master: master, theme: master.theme };
    })();
    self.prep[i] = pr;
    pr.catch(function () { delete self.prep[i]; });
    return pr;
  };

  function bgFill(cSld, ctx) {
    var bg = kid(cSld, 'bg');
    if (!bg) return null;
    var bgPr = kid(bg, 'bgPr');
    if (bgPr) return parseFill(bgPr, ctx);
    var ref = kid(bg, 'bgRef');
    if (ref) return themeFill(ctx, num(ref, 'idx', 0), colorIn(ref, ctx));
    return null;
  }

  Deck.prototype.build = function (i, p) {
    var info = this.info;
    var sRoot = p.slide.doc.documentElement, lRoot = p.layout.doc.documentElement, mRoot = p.master.doc.documentElement;
    var sCSld = kid(sRoot, 'cSld'), lCSld = kid(lRoot, 'cSld'), mCSld = kid(mRoot, 'cSld');
    var masterTree = kid(mCSld, 'spTree'), layoutTree = kid(lCSld, 'spTree'), slideTree = kid(sCSld, 'spTree');
    var txs = {}, tx = kid(mRoot, 'txStyles');
    ['titleStyle', 'bodyStyle', 'otherStyle'].forEach(function (n) { txs[n] = kid(tx, n); });
    var mMap = clrMapOf(kid(mRoot, 'clrMap'));
    var lOv = kidPath(lRoot, 'clrMapOvr', 'overrideClrMapping'), sOv = kidPath(sRoot, 'clrMapOvr', 'overrideClrMapping');
    var lMap = lOv ? clrMapOf(lOv) : mMap, sMap = sOv ? clrMapOf(sOv) : lMap;
    function mk(part, level, clrMap) {
      return {
        level: level, theme: p.theme, clrMap: clrMap, defaultTextStyle: info.defTx, txStyles: txs, tableStyles: info.tableStyles,
        slideNum: i + 1, layoutTree: layoutTree, masterTree: masterTree, phClr: null,
        imageUrl: function (rid) { return (rid && part.imgs[rid]) || null; },
        chartDoc: function (rid) { return (rid && part.charts[rid]) || null; },
        diagramDrawing: function (rid) { return (rid && part.drawings[rid]) || null; }
      };
    }
    var cS = mk(p.slide, 'slide', sMap), cL = mk(p.layout, 'layout', lMap), cM = mk(p.master, 'master', mMap);

    var el = document.createElement('div');
    el.className = 'sfp-slide';
    el.style.cssText = 'position:absolute;left:0;top:0;width:' + this.width + 'px;height:' + this.height + 'px;overflow:hidden;background:#fff;transform-origin:0 0;';
    var f = bgFill(sCSld, cS) || bgFill(lCSld, cL) || bgFill(mCSld, cM);
    var bg = fillCss(f);
    if (bg) el.style.background = bg;
    var ident = { ox: 0, oy: 0, sx: 1, sy: 1 };
    var showLayout = attr(sRoot, 'showMasterSp', '1') !== '0';
    var showMaster = showLayout && attr(lRoot, 'showMasterSp', '1') !== '0';
    try { if (showMaster && masterTree) renderTree(masterTree, cM, ident, el, true); } catch (e1) { console.warn('master render', e1); }
    try { if (showLayout && layoutTree) renderTree(layoutTree, cL, ident, el, true); } catch (e2) { console.warn('layout render', e2); }
    kids(slideTree).forEach(function (n) {
      if (n.localName === 'nvGrpSpPr' || n.localName === 'grpSpPr') return;
      try { renderNode(n, cS, ident, el); } catch (e3) { console.warn('shape render', e3); }
    });
    return el;
  };

  Deck.prototype.render = function (i) {
    var self = this;
    if (i < 0 || i >= self.count) return Promise.reject(new Error('no such slide'));
    return self.prepare(i).then(function (p) { return self.build(i, p); });
  };

  /** Shrink text in "shrink on overflow" boxes whose stored font scale is unknown. Call when attached to the DOM. */
  Deck.prototype.postLayout = function (rootEl) {
    var list = rootEl.querySelectorAll('.sfp-text[data-fit="1"]');
    for (var n = 0; n < list.length; n++) {
      var box = list[n];
      if (!box.firstElementChild) continue;
      var cs = getComputedStyle(box);
      var padV = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
      var avail = box.offsetHeight - padV;
      if (avail <= 0) continue;
      var used = function () {
        var rb = box.getBoundingClientRect(), fe = box.firstElementChild.getBoundingClientRect(), le = box.lastElementChild.getBoundingClientRect();
        var sc = box.offsetHeight ? rb.height / box.offsetHeight : 1;
        return (le.bottom - fe.top) / (sc || 1);
      };
      if (used() <= avail + 1) continue;
      for (var s = 0.95; s >= 0.4; s -= 0.05) {
        box.style.setProperty('--sfs', String(s));
        if (used() <= avail + 1) break;
      }
    }
  };

  function fitHost(host, el, deck) {
    var cw = host.clientWidth || 1, ch = host.clientHeight || 1;
    var s = Math.min(cw / deck.width, ch / deck.height);
    var x = (cw - deck.width * s) / 2, y = (ch - deck.height * s) / 2;
    el.style.transformOrigin = '0 0';
    el.style.transform = 'translate(' + x + 'px,' + y + 'px) scale(' + s + ')';
  }
  function waitImages(el) {
    var imgs = Array.prototype.slice.call(el.querySelectorAll('img'));
    if (!imgs.length) return Promise.resolve();
    var all = Promise.all(imgs.map(function (im) { return im.decode ? im.decode().catch(function () {}) : Promise.resolve(); }));
    return Promise.race([all, new Promise(function (r) { setTimeout(r, 3000); })]);
  }

  /** Render slide `index` into `host` (a positioned element with a size). Re-fits automatically when host resizes. */
  function show(host, deck, index) {
    var seq = (host.__sfpSeq = (host.__sfpSeq || 0) + 1);
    return deck.render(index).then(function (el) {
      return waitImages(el).then(function () { return el; });
    }).then(function (el) {
      if (host.__sfpSeq !== seq) return;      // a newer request replaced this one
      if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
      host.style.overflow = 'hidden';
      host.innerHTML = '';
      host.appendChild(el);
      deck.postLayout(el);
      fitHost(host, el, deck);
      host.__sfp = { el: el, deck: deck };
      if (!host.__sfpRO && root.ResizeObserver) {
        host.__sfpRO = new ResizeObserver(function () { var c = host.__sfp; if (c) fitHost(host, c.el, c.deck); });
        host.__sfpRO.observe(host);
      }
    });
  }

  function parse(buf) {
    return (async function () {
      var zip = openZip(buf), pkg = new Package(zip);
      var rootRels = await pkg.rels('');
      var presPath = null, k;
      for (k in rootRels) if (/\/officeDocument$/.test(rootRels[k].type)) presPath = rootRels[k].target;
      if (!presPath) presPath = 'ppt/presentation.xml';
      var pres = await pkg.doc(presPath);
      if (!pres) throw new Error('This file does not look like a PowerPoint presentation.');
      var prels = await pkg.rels(presPath);
      var sz = findFirst(pres, 'sldSz');
      var W = num(sz, 'cx', 9144000) / EMU, H = num(sz, 'cy', 5143500) / EMU;
      var paths = [];
      kids(kid(pres.documentElement, 'sldIdLst'), 'sldId').forEach(function (s) {
        var r = prels[rattr(s, 'id')];
        if (r && !r.external) paths.push(r.target);
      });
      if (!paths.length) throw new Error('This presentation has no slides.');
      // skip hidden slides (like a real slide show does)
      var visible = [];
      for (var i = 0; i < paths.length; i++) {
        var hidden = false;
        if (zip.has(paths[i])) {
          var bytes = await zip.read(paths[i]);
          hidden = /<p:sld\b[^>]*\sshow="(0|false)"/.test(utf8.decode(bytes.subarray(0, Math.min(bytes.length, 4000))));
        }
        if (!hidden) visible.push(paths[i]);
      }
      if (!visible.length) visible = paths;
      var tableStyles = {}, tsRel = null;
      for (k in prels) if (/\/tableStyles$/.test(prels[k].type)) tsRel = prels[k];
      if (tsRel) {
        var tsd = await pkg.doc(tsRel.target);
        if (tsd) kids(tsd.documentElement, 'tblStyle').forEach(function (s) { tableStyles[attr(s, 'styleId', '')] = s; });
      }
      return new Deck(pkg, { W: W, H: H, slides: visible, defTx: kid(pres.documentElement, 'defaultTextStyle'), tableStyles: tableStyles });
    })();
  }
  function load(url) {
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('Cannot read the file (' + r.status + ')');
      return r.arrayBuffer();
    }).then(parse);
  }

  // ------------------------------------------------------------------ animations + slide transitions (present mode)
  // Entrance / exit / emphasis / motion-path effects and slide transitions are played with the Web Animations API.
  // Common effects are reproduced closely; exotic ones fall back to a fade so the show never stops.
  function numAttr(el, name, def) { var v = el ? el.getAttribute(name) : null; var n = v == null ? NaN : parseInt(v, 10); return isNaN(n) ? def : n; }

  function condDelay(ct) {
    var conds = kids(kid(ct, 'stCondLst'), 'cond');
    for (var i = 0; i < conds.length; i++) {
      var d = conds[i].getAttribute('delay');
      if (d != null && d !== 'indefinite' && !isNaN(parseInt(d, 10))) return parseInt(d, 10);
    }
    return 0;
  }
  function behaviorDur(n) {
    var ct = kid(kid(n, 'cBhvr'), 'cTn'), d = ct ? ct.getAttribute('dur') : null;
    return d && d !== 'indefinite' && !isNaN(parseInt(d, 10)) ? parseInt(d, 10) : 0;
  }
  function parseEffect(c, start) {
    var e = { cls: attr(c, 'presetClass', ''), id: numAttr(c, 'presetID', 0), sub: numAttr(c, 'presetSubtype', 0), start: start, dur: 0,
              spid: null, p0: null, p1: null, filter: '', fly: false, size: false, path: null, rot: null, scale: null };
    var all = c.getElementsByTagNameNS('*', '*');
    for (var i = 0; i < all.length; i++) {
      var n = all[i], ln = n.localName;
      if (ln === 'spTgt' && e.spid == null) {
        e.spid = n.getAttribute('spid');
        var pr = n.getElementsByTagNameNS('*', 'pRg')[0];
        if (pr) { e.p0 = numAttr(pr, 'st', 0); e.p1 = numAttr(pr, 'end', e.p0); }
      } else if (ln === 'animEffect') {
        e.filter = n.getAttribute('filter') || e.filter; e.dur = Math.max(e.dur, behaviorDur(n));
      } else if (ln === 'anim') {
        var names = n.getElementsByTagNameNS('*', 'attrName');
        for (var k = 0; k < names.length; k++) {
          var t = names[k].textContent;
          if (/ppt_x|ppt_y/.test(t)) e.fly = true;
          if (/ppt_w|ppt_h|style\.width|style\.height/.test(t)) e.size = true;
        }
        e.dur = Math.max(e.dur, behaviorDur(n));
      } else if (ln === 'animMotion') {
        e.path = n.getAttribute('path') || ''; e.dur = Math.max(e.dur, behaviorDur(n));
      } else if (ln === 'animRot') {
        e.rot = numAttr(n, 'by', 0) / 60000; e.dur = Math.max(e.dur, behaviorDur(n));
      } else if (ln === 'animScale') {
        var by = kid(n, 'by');
        e.scale = [numAttr(by, 'x', 100000) / 100000, numAttr(by, 'y', 100000) / 100000]; e.dur = Math.max(e.dur, behaviorDur(n));
      }
    }
    return e;
  }
  /** Click steps of the main sequence. A step is { auto, effects[] }; effects carry absolute start offsets (ms). */
  function parseTiming(sRoot) {
    var out = { steps: [] };
    var timing = sRoot.getElementsByTagNameNS('*', 'timing')[0];
    if (!timing) return out;
    var seq = null, cts = timing.getElementsByTagNameNS('*', 'cTn');
    for (var i = 0; i < cts.length; i++) if (cts[i].getAttribute('nodeType') === 'mainSeq') { seq = cts[i]; break; }
    if (!seq) return out;
    function walk(ct, base, effects) {
      kids(kid(ct, 'childTnLst'), 'par').forEach(function (par) {
        var c = kid(par, 'cTn');
        if (!c) return;
        var at = base + condDelay(c);
        if (c.hasAttribute('presetClass')) { var e = parseEffect(c, at); if (e.spid != null) effects.push(e); }
        else walk(c, at, effects);
      });
    }
    kids(kid(seq, 'childTnLst'), 'par').forEach(function (stepPar) {
      var ct = kid(stepPar, 'cTn');
      if (!ct) return;
      var auto = kids(kid(ct, 'stCondLst'), 'cond').some(function (c) { return c.getAttribute('evt') === 'onBegin'; });
      var effects = [];
      walk(ct, 0, effects);
      if (effects.length) out.steps.push({ auto: auto, effects: effects });
    });
    return out;
  }
  function parseTransition(sRoot) {
    var tr = sRoot.getElementsByTagNameNS('*', 'transition')[0];
    if (!tr) return null;
    var dur = numAttr(tr, 'p14:dur', 0);
    if (!dur) { var spd = tr.getAttribute('spd'); dur = spd === 'slow' ? 1000 : spd === 'med' ? 750 : 500; }
    var child = null;
    kids(tr).forEach(function (c) { if (!child && c.localName !== 'sndAc' && c.localName !== 'extLst') child = c; });
    var adv = tr.getAttribute('advTm');
    return {
      type: child ? child.localName : 'cut', dir: child ? (child.getAttribute('dir') || '') : '', orient: child ? (child.getAttribute('orient') || '') : '',
      spokes: child ? (child.getAttribute('spokes') || '') : '', dur: dur, advTm: adv != null && !isNaN(parseInt(adv, 10)) ? parseInt(adv, 10) : null
    };
  }
  Deck.prototype.timing = function (i) {
    var self = this;
    self.tcache = self.tcache || {};
    if (self.tcache[i]) return self.tcache[i];
    self.tcache[i] = self.prepare(i).then(function (p) {
      var r = p.slide.doc.documentElement;
      var t = parseTiming(r);
      t.trans = parseTransition(r);
      return t;
    }).catch(function () { return { steps: [], trans: null }; });
    return self.tcache[i];
  };

  function wipeInset(edge, from) {          // edge the wipe starts from; `from` = fully hidden state
    var hide = { l: 'inset(0 100% 0 0)', r: 'inset(0 0 0 100%)', u: 'inset(0 0 100% 0)', d: 'inset(100% 0 0 0)' };
    return hide[edge] || hide.l;
  }
  function edgeOf(word) {
    word = String(word || '').toLowerCase();
    if (word === 'left' || word === 'l') return 'l';
    if (word === 'right' || word === 'r') return 'r';
    if (word === 'up' || word === 'u' || word === 'top') return 'u';
    if (word === 'down' || word === 'd' || word === 'bottom') return 'd';
    return 'l';
  }
  function targetsOf(e, slideEl) {
    var nodes = slideEl.querySelectorAll('[data-spid="' + e.spid + '"]'), out = [], i;
    if (e.p0 != null) {
      for (i = 0; i < nodes.length; i++) {
        var ps = nodes[i].querySelectorAll('[data-para]');
        for (var j = 0; j < ps.length; j++) { var k = parseInt(ps[j].getAttribute('data-para'), 10); if (k >= e.p0 && k <= e.p1) out.push(ps[j]); }
      }
      if (out.length) return out;
    }
    for (i = 0; i < nodes.length; i++) out.push(nodes[i]);
    return out;
  }
  function motionPoints(path) {
    var toks = String(path || '').trim().split(/\s+/), pts = [[0, 0]], mode = '', nums = [];
    function flush() {
      var per = mode === 'C' || mode === 'c' ? 6 : (mode === 'L' || mode === 'M' || mode === 'l' || mode === 'm' ? 2 : 0);
      while (per && nums.length >= per) { var g = nums.splice(0, per); pts.push([g[per - 2], g[per - 1]]); }
      nums = [];
    }
    toks.forEach(function (t) {
      if (/^[A-Za-z]$/.test(t)) { flush(); mode = t; }
      else { var v = parseFloat(t); if (!isNaN(v)) nums.push(v); }
    });
    flush();
    if (pts.length > 1 && pts[0][0] === 0 && pts[0][1] === 0 && pts[1][0] === 0 && pts[1][1] === 0) pts.shift();   // leading "M 0 0"
    return pts;
  }

  /** Decide what an entrance effect looks like: { from: {css}, to: {css} }. */
  function entranceLook(e, el, ctl) {
    var f = e.filter || '', W = ctl.deck.width, H = ctl.deck.height, from = {}, to = {}, m = /\(([^)]*)\)/.exec(f), arg = m ? m[1] : '';
    var op = parseFloat(getComputedStyle(el).opacity); if (isNaN(op)) op = 1;
    if (e.fly) {
      var r = ctl.rel(el), x = 0, y = 0;
      if (e.sub & 8) x = -(r.x + r.w); else if (e.sub & 2) x = W - r.x;
      if (e.sub & 1) y = -(r.y + r.h); else if (e.sub & 4) y = H - r.y;
      if (!x && !y) y = H - r.y;
      if (e.id === 7 || e.id === 12) { x = Math.max(-W * 0.25, Math.min(W * 0.25, x)); y = Math.max(-H * 0.25, Math.min(H * 0.25, y)); }
      from.translate = x + 'px ' + y + 'px'; to.translate = '0px 0px';
    } else if (/^wipe/.test(f)) {
      from.clipPath = wipeInset(edgeOf(arg)); to.clipPath = 'inset(0 0 0 0)';
    } else if (/^barn/.test(f) && /out/i.test(arg)) {
      from.clipPath = /vertical/i.test(arg) ? 'inset(0 50% 0 50%)' : 'inset(50% 0 50% 0)'; to.clipPath = 'inset(0 0 0 0)';
    } else if (/^circle/.test(f)) {
      from.clipPath = 'circle(0% at 50% 50%)'; to.clipPath = 'circle(75% at 50% 50%)';
    } else if (/^diamond/.test(f)) {
      from.clipPath = 'polygon(50% 50%,50% 50%,50% 50%,50% 50%)'; to.clipPath = 'polygon(50% -50%,150% 50%,50% 150%,-50% 50%)';
    } else if (/^box/.test(f)) {
      from.clipPath = 'inset(50% 50% 50% 50%)'; to.clipPath = 'inset(0 0 0 0)';
    } else if (e.id === 23 || e.id === 53 || (e.size && !f)) {
      from.scale = '0.05'; from.opacity = 0; to.scale = '1'; to.opacity = op;
    } else if (e.id === 1 || (!f && !e.dur)) {
      return null;                                           // Appear
    } else {
      from.opacity = 0; to.opacity = op;                     // Fade and every effect without an exact equivalent
    }
    return { from: from, to: to };
  }

  function applyFinal(e, els) {
    els.forEach(function (el) {
      if (e.cls === 'entr') el.style.visibility = 'visible';
      else if (e.cls === 'exit') el.style.visibility = 'hidden';
      else if (e.cls === 'emph') {
        if (e.rot != null) el.style.rotate = e.rot + 'deg';
        else if (e.scale) el.style.scale = e.scale[0] + ' ' + e.scale[1];
      } else if (e.cls === 'path' && e.pts && e.pts.length) {
        var l = e.pts[e.pts.length - 1];
        el.style.translate = l[0] * e.W + 'px ' + l[1] * e.H + 'px';
      }
    });
  }

  var TRANSITIONS = [
    ['file', 'As set in each presentation'], ['none', 'None (instant)'], ['fade', 'Fade'], ['push', 'Push'], ['cover', 'Cover'],
    ['pull', 'Uncover'], ['wipe', 'Wipe'], ['split', 'Split'], ['zoom', 'Zoom'], ['circle', 'Circle'], ['diamond', 'Diamond'],
    ['plus', 'Plus'], ['blinds', 'Blinds'], ['checker', 'Checkerboard'], ['comb', 'Comb'], ['randomBar', 'Random bars'],
    ['dissolve', 'Dissolve'], ['wheel', 'Wheel'], ['wedge', 'Wedge'], ['strips', 'Diagonal strips'], ['newsflash', 'Spin zoom'],
    ['flash', 'Flash'], ['flip', 'Flip'], ['cube', 'Cube'], ['random', 'Random (different each slide)']
  ];
  // PowerPoint transitions without an exact equivalent are mapped to the closest one
  var TRANS_ALIAS = { vortex: 'wheel', ripple: 'circle', glitter: 'dissolve', honeycomb: 'dissolve', shred: 'dissolve', flythrough: 'zoom',
    gallery: 'push', conveyor: 'push', pan: 'push', ferris: 'push', reveal: 'pull', 'switch': 'flip', flipRight: 'flip', doors: 'split',
    'window': 'split', curtains: 'split', prism: 'cube', warp: 'zoom', checkerboard: 'checker', randombar: 'randomBar' };
  var RANDOM_POOL = ['fade', 'push', 'cover', 'pull', 'wipe', 'split', 'zoom', 'circle', 'diamond', 'plus', 'blinds', 'checker', 'comb',
    'randomBar', 'dissolve', 'wheel', 'wedge', 'strips', 'newsflash', 'flash', 'flip', 'cube'];
  /** Combine the slide's own transition with the operator's style / speed settings. Returns null for "no transition". */
  function resolveTransition(t, o) {
    var style = (o && o.style) || 'file', r;
    if (style === 'none') return null;
    if (style === 'file') {
      if (!t) return null;
      r = { type: t.type, dir: t.dir, orient: t.orient, spokes: t.spokes, dur: t.dur };
    } else {
      r = { type: style, dir: t ? t.dir : '', orient: t ? t.orient : '', spokes: t ? t.spokes : '', dur: t ? t.dur : 700 };
    }
    if (r.type === 'random') { r.type = RANDOM_POOL[Math.floor(Math.random() * RANDOM_POOL.length)]; r.dir = ''; r.orient = ''; r.spokes = ''; }
    r.type = TRANS_ALIAS[r.type] || r.type;
    if (r.type === 'cut') return null;
    if (o && o.speed > 0) r.dur = o.speed;
    if (!r.dur) r.dur = 700;
    return r;
  }

  function present(host, deck, opts) {
    opts = opts || {};
    if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
    host.style.overflow = 'hidden';
    host.innerHTML = '';
    var ctl = { deck: deck, idx: 0, step: 0, steps: [], cur: null, seq: 0, timer: null, anims: [], trCleanup: null, dead: false };

    ctl.rel = function (el) {
      var r = el.getBoundingClientRect(), s = ctl.cur.el.getBoundingClientRect(), sc = (s.width / deck.width) || 1;
      return { x: (r.left - s.left) / sc, y: (r.top - s.top) / sc, w: r.width / sc, h: r.height / sc };
    };
    function refit() { if (ctl.cur) fitHost(ctl.cur.layer, ctl.cur.el, deck); }
    var ro = null;
    if (root.ResizeObserver) { ro = new ResizeObserver(function () { refit(); }); ro.observe(host); }

    function makeLayer(i, upTo) {
      return Promise.all([deck.render(i), deck.timing(i)]).then(function (r) {
        var el = r[0], tm = r[1];
        return waitImages(el).then(function () {
          var layer = document.createElement('div');
          layer.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;overflow:hidden;visibility:hidden;';
          layer.appendChild(el);
          host.appendChild(layer);
          deck.postLayout(el);
          fitHost(layer, el, deck);
          var b = { i: i, layer: layer, el: el, steps: opts.animations === false ? [] : tm.steps, trans: tm.trans };
          // shapes that have an entrance effect start hidden; earlier steps are fast-forwarded
          b.steps.forEach(function (st) { st.effects.forEach(function (e) {
            e.W = deck.width; e.H = deck.height; if (e.cls === 'path') e.pts = motionPoints(e.path);
            if (e.cls === 'entr') targetsOf(e, el).forEach(function (t) { t.style.visibility = 'hidden'; });
          }); });
          for (var k = 0; k < Math.min(upTo, b.steps.length); k++) b.steps[k].effects.forEach(function (e) { applyFinal(e, targetsOf(e, el)); });
          return b;
        });
      });
    }

    function playEffect(e, b) {
      var els = targetsOf(e, b.el), W = deck.width, H = deck.height;
      els.forEach(function (el) {
        var frames = null, dur = Math.max(1, e.dur || 0), ease = 'ease-out';
        var persist = false;
        if (e.cls === 'entr') {
          var look = entranceLook(e, el, ctl);
          if (!look) { frames = [{ visibility: 'hidden' }, { visibility: 'visible' }]; dur = 1; }
          else frames = [Object.assign({ visibility: 'visible' }, look.from), Object.assign({ visibility: 'visible' }, look.to)];
        } else if (e.cls === 'exit') {
          var lk = entranceLook(e, el, ctl);
          if (!lk) { frames = [{ visibility: 'visible' }, { visibility: 'visible' }]; dur = 1; }
          else frames = [Object.assign({ visibility: 'visible' }, lk.to), Object.assign({ visibility: 'visible' }, lk.from)];
          ease = 'ease-in';
        } else if (e.cls === 'emph') {
          dur = Math.max(1, e.dur || 500);
          if (e.rot != null) { frames = [{ rotate: '0deg' }, { rotate: e.rot + 'deg' }]; persist = true; ease = 'linear'; }
          else if (e.scale && (e.scale[0] !== 1 || e.scale[1] !== 1)) { frames = [{ scale: '1 1' }, { scale: e.scale[0] + ' ' + e.scale[1] }]; persist = true; }
          else frames = [{ scale: '1' }, { scale: '1.08' }, { scale: '1' }];
          ease = 'ease-in-out';
        } else if (e.cls === 'path' && e.pts && e.pts.length > 1) {
          dur = Math.max(1, e.dur || 500);
          frames = e.pts.map(function (p) { return { translate: p[0] * W + 'px ' + p[1] * H + 'px' }; });
          persist = true; ease = 'linear';
        }
        if (!frames) return;
        var a = el.animate(frames, { duration: dur, delay: e.start, fill: 'both', easing: ease });
        ctl.anims.push(a);
        a.finished.then(function () {
          if (e.cls === 'entr' || e.cls === 'exit' || persist) applyFinal(e, [el]);
          try { a.cancel(); } catch (x) {}
          var ix = ctl.anims.indexOf(a); if (ix >= 0) ctl.anims.splice(ix, 1);
        }).catch(function () {});
      });
    }
    function runStep(k) {
      var b = ctl.cur;
      if (!b || !b.steps[k]) return;
      b.steps[k].effects.forEach(function (e) { try { playEffect(e, b); } catch (x) { console.warn('animation', x); applyFinal(e, targetsOf(e, b.el)); } });
    }

    function settle() {
      if (ctl.trCleanup) { var f = ctl.trCleanup; ctl.trCleanup = null; f(); }
    }

    function transit(oldB, newB, t) {
      var dur = t.dur || 700, anims = [], extras = [], nl = newB.layer, ol = oldB.layer;
      var W = host.clientWidth || 1, H = host.clientHeight || 1, d = t.dir || 'l';
      var vx = d.indexOf('l') >= 0 ? -1 : (d.indexOf('r') >= 0 ? 1 : 0), vy = d.indexOf('u') >= 0 ? -1 : (d.indexOf('d') >= 0 ? 1 : 0);
      if (!vx && !vy) vx = -1;
      function A(el, frames, o) {
        var a = el.animate(frames, Object.assign({ duration: dur, easing: 'ease-in-out', fill: 'both' }, o || {}));
        anims.push(a); return a;
      }
      function tr(x, y) { return 'translate(' + x + 'px,' + y + 'px)'; }
      // progress-driven animation (pattern reveals drawn as a clip-path); fn(p) with p in 0..1
      function P(fn) {
        var over = false, raf = 0, res, t0 = performance.now();
        var pr = new Promise(function (r) { res = r; });
        function ease(x) { return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; }
        function finish() { if (over) return; over = true; cancelAnimationFrame(raf); fn(1); res(); }
        function tick(now) { if (over) return; var x = Math.min(1, (now - t0) / dur); if (x >= 1) finish(); else { fn(ease(x)); raf = requestAnimationFrame(tick); } }
        fn(0); raf = requestAnimationFrame(tick);
        anims.push({ finished: pr, cancel: function () { over = true; cancelAnimationFrame(raf); res(); } });
      }
      function R(x, y, w, h) { return w > 0.3 && h > 0.3 ? 'M' + x.toFixed(1) + ' ' + y.toFixed(1) + 'h' + w.toFixed(1) + 'v' + h.toFixed(1) + 'h' + (-w).toFixed(1) + 'z' : ''; }
      function clip(s) { nl.style.clipPath = s ? "path('" + s + "')" : 'inset(100% 0 0 0)'; }
      function clamp(x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
      var seed = 12345;
      function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; }
      function fan(cx, cy, a0, a1) {            // pie slice from angle a0 to a1 (degrees)
        var rad = Math.hypot(W, H), s = 'M' + cx + ' ' + cy, n = Math.max(2, Math.ceil(Math.abs(a1 - a0) / 8));
        for (var i = 0; i <= n; i++) { var a = (a0 + (a1 - a0) * i / n) * Math.PI / 180; s += 'L' + (cx + rad * Math.cos(a)).toFixed(1) + ' ' + (cy + rad * Math.sin(a)).toFixed(1); }
        return s + 'z';
      }
      var vert = t.dir === 'vert', i, j;
      nl.style.zIndex = '2'; ol.style.zIndex = '1'; nl.style.visibility = 'visible';
      switch (t.type) {
        case 'push':
          A(nl, [{ transform: tr(-vx * W, -vy * H) }, { transform: tr(0, 0) }]);
          A(ol, [{ transform: tr(0, 0) }, { transform: tr(vx * W, vy * H) }]); break;
        case 'cover': A(nl, [{ transform: tr(-vx * W, -vy * H) }, { transform: tr(0, 0) }]); break;
        case 'pull': nl.style.zIndex = '1'; ol.style.zIndex = '3'; A(ol, [{ transform: tr(0, 0) }, { transform: tr(vx * W, vy * H) }]); break;
        case 'wipe': A(nl, [{ clipPath: wipeInset(edgeOf(t.dir || 'l')) }, { clipPath: 'inset(0 0 0 0)' }]); break;
        case 'split':
          if (t.dir === 'in') A(nl, [{ clipPath: t.orient === 'vert' ? 'inset(0 0 0 0)' : 'inset(0 0 0 0)', opacity: 0 }, { clipPath: 'inset(0 0 0 0)', opacity: 1 }]);
          else A(nl, [{ clipPath: t.orient === 'vert' ? 'inset(50% 0 50% 0)' : 'inset(0 50% 0 50%)' }, { clipPath: 'inset(0 0 0 0)' }]);
          break;
        case 'circle': A(nl, [{ clipPath: 'circle(0% at 50% 50%)' }, { clipPath: 'circle(75% at 50% 50%)' }]); break;
        case 'diamond': A(nl, [{ clipPath: 'polygon(50% 50%,50% 50%,50% 50%,50% 50%)' }, { clipPath: 'polygon(50% -50%,150% 50%,50% 150%,-50% 50%)' }]); break;
        case 'zoom':
          if (t.dir === 'out') { nl.style.zIndex = '1'; ol.style.zIndex = '3'; A(ol, [{ transform: 'scale(1)', opacity: 1 }, { transform: 'scale(1.7)', opacity: 0 }]); }
          else A(nl, [{ transform: 'scale(0.4)', opacity: 0 }, { transform: 'scale(1)', opacity: 1 }]);
          break;
        case 'newsflash': A(nl, [{ transform: 'rotate(-540deg) scale(0)', opacity: 0 }, { transform: 'rotate(0deg) scale(1)', opacity: 1 }]); break;
        case 'flash': {
          var fl = document.createElement('div');
          fl.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;background:#fff;z-index:5;pointer-events:none;';
          host.appendChild(fl); extras.push(fl);
          A(fl, [{ opacity: 0 }, { opacity: 1, offset: 0.45 }, { opacity: 0 }], { easing: 'linear' });
          A(nl, [{ opacity: 0 }, { opacity: 0, offset: 0.45 }, { opacity: 1, offset: 0.5 }, { opacity: 1 }], { easing: 'linear' });
          break;
        }
        case 'flip': {
          var pr = 'perspective(1600px) ', sg = vx > 0 ? -1 : 1;
          A(ol, [{ transform: pr + 'rotateY(0deg)' }, { transform: pr + 'rotateY(' + (-90 * sg) + 'deg)', offset: 0.5 }, { transform: pr + 'rotateY(' + (-90 * sg) + 'deg)' }]);
          A(nl, [{ transform: pr + 'rotateY(' + (90 * sg) + 'deg)' }, { transform: pr + 'rotateY(' + (90 * sg) + 'deg)', offset: 0.5 }, { transform: pr + 'rotateY(0deg)' }]);
          break;
        }
        case 'cube': {
          var sc = vx > 0 ? -1 : 1;
          var cb = function (a) { return 'perspective(2400px) translateZ(' + (-W / 2) + 'px) rotateY(' + a + 'deg) translateZ(' + (W / 2) + 'px)'; };
          A(ol, [{ transform: cb(0) }, { transform: cb(-90 * sc) }]);
          A(nl, [{ transform: cb(90 * sc) }, { transform: cb(0) }]);
          break;
        }
        case 'blinds': P(function (p) {
          var n = 10, s = '', k;
          for (k = 0; k < n; k++) s += vert ? R(k * W / n, 0, W / n * p, H) : R(0, k * H / n, W, H / n * p);
          clip(s);
        }); break;
        case 'checker': P(function (p) {
          var cols = 12, rows = Math.max(4, Math.round(cols * H / W)), cw = W / cols, ch = H / rows, s = '', r, c, q;
          for (r = 0; r < rows; r++) for (c = 0; c < cols; c++) {
            q = (r + c) % 2 ? clamp(p * 2 - 1) : clamp(p * 2);
            s += vert ? R(c * cw, r * ch, cw, ch * q) : R(c * cw, r * ch, cw * q, ch);
          }
          clip(s);
        }); break;
        case 'comb': P(function (p) {
          var n = 12, s = '', k;
          for (k = 0; k < n; k++) {
            if (vert) s += R(k * W / n, k % 2 ? H * (1 - p) : 0, W / n, H * p);
            else s += R(k % 2 ? W * (1 - p) : 0, k * H / n, W * p, H / n);
          }
          clip(s);
        }); break;
        case 'randomBar': {
          var nb = 24, thr = [];
          for (i = 0; i < nb; i++) thr.push(rnd());
          P(function (p) {
            var s = '', k, q;
            for (k = 0; k < nb; k++) {
              q = clamp((p - thr[k] * 0.55) / 0.45);
              s += vert ? R(k * W / nb, 0, W / nb, H * q) : R(0, k * H / nb, W * q, H / nb);
            }
            clip(s);
          }); break;
        }
        case 'dissolve': {
          var cols2 = 26, rows2 = Math.max(6, Math.round(cols2 * H / W)), cells = [];
          for (i = 0; i < rows2; i++) for (j = 0; j < cols2; j++) cells.push([j, i, rnd()]);
          P(function (p) {
            var s = '', cw = W / cols2, ch = H / rows2;
            for (var k = 0; k < cells.length; k++) if (p >= cells[k][2]) s += R(cells[k][0] * cw - 0.5, cells[k][1] * ch - 0.5, cw + 1, ch + 1);
            clip(s);
          }); break;
        }
        case 'wheel': P(function (p) {
          var n = Math.max(1, Math.min(8, parseInt(t.spokes, 10) || 4)), s = '', k;
          for (k = 0; k < n; k++) { var a0 = -90 + k * 360 / n; s += fan(W / 2, H / 2, a0, a0 + p * 360 / n); }
          clip(s);
        }); break;
        case 'wedge': P(function (p) { clip(p <= 0 ? '' : fan(W / 2, H / 2, -90 - p * 180, -90 + p * 180)); }); break;
        case 'plus': P(function (p) {
          clip(R(W / 2 - W * clamp(p * 2) / 2, H / 2 - H * p / 2, W * clamp(p * 2), H * p) + R(W / 2 - W * p / 2, H / 2 - H * clamp(p * 2) / 2, W * p, H * clamp(p * 2)));
        }); break;
        case 'strips': P(function (p) {
          var a = p * (W + H) * 1.02, dd = t.dir || 'lu', fx = dd.indexOf('r') >= 0, fy = dd.indexOf('d') >= 0;
          var x0 = fx ? W : 0, y0 = fy ? H : 0, sx = fx ? -1 : 1, sy = fy ? -1 : 1;
          clip(p <= 0 ? '' : 'M' + x0 + ' ' + y0 + 'L' + (x0 + sx * a) + ' ' + y0 + 'L' + x0 + ' ' + (y0 + sy * a) + 'z');
        }); break;
        default: A(nl, [{ opacity: 0 }, { opacity: 1 }]);          // fade and every transition without an exact equivalent
      }
      var finished = false;
      function done() {
        if (finished) return; finished = true;
        anims.forEach(function (a) { try { a.cancel(); } catch (x) {} });
        extras.forEach(function (x) { if (x.parentNode) x.parentNode.removeChild(x); });
        nl.style.zIndex = ''; nl.style.clipPath = '';
        if (ol.parentNode) ol.parentNode.removeChild(ol);
        if (ctl.trCleanup === done) ctl.trCleanup = null;
      }
      ctl.trCleanup = done;
      return Promise.all(anims.map(function (a) { return a.finished; })).then(done, done);
    }

    // timed advance: with a custom interval the remaining click-animations of the slide are played first
    function arm(ms, stepwise) {
      ctl.timer = setTimeout(function () {
        ctl.timer = null;
        if (ctl.dead) return;
        if (stepwise && ctl.step < ctl.steps.length) { runStep(ctl.step); ctl.step += 1; arm(ms, true); }
        else if (opts.onAdvance) opts.onAdvance();
      }, ms);
    }

    function clearTimers() { if (ctl.timer) { clearTimeout(ctl.timer); ctl.timer = null; } }

    /** Show slide i. opts: instant (no transition), upTo (steps already played, or 'all'), noAuto. */
    ctl.goto = function (i, o) {
      o = o || {};
      i = Math.max(0, Math.min(deck.count - 1, i));
      var my = ++ctl.seq;
      clearTimers(); settle();
      return makeLayer(i, 0).then(function (b0) {
        // steps are known only after the layer exists; rebuild the fast-forward when needed
        var upTo = o.upTo === 'all' ? b0.steps.length : (o.upTo || 0);
        if (upTo > 0) {
          if (my !== ctl.seq) { b0.layer.remove(); return; }
          b0.layer.remove();
          return makeLayer(i, upTo);
        }
        return b0;
      }).then(function (b) {
        if (!b) return;
        if (my !== ctl.seq || ctl.dead) { if (b.layer.parentNode) b.layer.parentNode.removeChild(b.layer); return; }
        var old = ctl.cur, upTo2 = o.upTo === 'all' ? b.steps.length : (o.upTo || 0);
        ctl.cur = b; ctl.idx = i; ctl.step = upTo2; ctl.steps = b.steps;
        refit();
        if (opts.onSlide) opts.onSlide(i);
        function shown() {
          if (my !== ctl.seq || ctl.dead) return;
          refit();
          if (!o.noAuto && upTo2 === 0 && b.steps[0] && b.steps[0].auto) { ctl.step = 1; runStep(0); }
          if (!o.noAuto && opts.onAdvance) {
            var mode = opts.advance || 'file', ms = null;
            if (mode === 'custom') ms = Math.max(1, opts.advanceSecs || 10) * 1000;
            else if (mode === 'file' && b.trans && b.trans.advTm != null) ms = b.trans.advTm;
            if (ms != null) arm(ms, mode === 'custom');
          }
        }
        var t = resolveTransition(b.trans, opts);
        if (old && !o.instant && t) { return transit(old, b, t).then(shown); }
        b.layer.style.visibility = 'visible';
        if (old && old.layer.parentNode) old.layer.parentNode.removeChild(old.layer);
        shown();
      }).catch(function (e) { if (opts.onError) opts.onError(e, i); else throw e; });
    };

    /** Next click: plays the next animation step, otherwise moves to the next slide. Returns 'step' | 'slide' | 'end'. */
    ctl.next = function () {
      if (!ctl.cur) return 'end';
      settle();
      if (ctl.step < ctl.steps.length) { runStep(ctl.step); ctl.step += 1; return 'step'; }
      return ctl.nextSlide();
    };
    ctl.nextSlide = function () {
      if (ctl.idx + 1 < deck.count) { ctl.goto(ctl.idx + 1); return 'slide'; }
      return 'end';
    };
    ctl.prev = function () {
      if (!ctl.cur) return;
      if (ctl.step > 0) ctl.goto(ctl.idx, { instant: true, upTo: ctl.step - 1, noAuto: true });
      else if (ctl.idx > 0) ctl.goto(ctl.idx - 1, { instant: true, upTo: 'all', noAuto: true });
    };
    ctl.dispose = function () {
      ctl.dead = true; ctl.seq += 1; clearTimers(); settle();
      ctl.anims.forEach(function (a) { try { a.cancel(); } catch (x) {} });
      if (ro) ro.disconnect();
      host.innerHTML = '';
    };
    return ctl;
  }

  root.ShowFlowPptx = { load: load, parse: parse, show: show, present: present, transitions: TRANSITIONS };
})(typeof window !== 'undefined' ? window : this);

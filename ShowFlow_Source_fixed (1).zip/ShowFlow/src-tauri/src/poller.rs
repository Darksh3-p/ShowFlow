//! Background watcher: PowerPoint slide/finish detection and automatic idle.
use std::time::Duration;

use serde_json::json;
use showflow_core::models::IdleMode;
use showflow_core::output::{OutputSource, PlaybackState};
use tauri::{AppHandle, Emitter, Manager};

use crate::orchestrator;
use crate::state::{lk, AppState};

pub fn start(app: AppHandle) {
    std::thread::spawn(move || {
        let mut last_pos: i64 = -1;
        let mut missing: u32 = 0;
        let mut errors: u32 = 0;
        let mut tick: u64 = 0;
        let mut warm: u32 = 0; // ticks to ignore after an item goes live (PowerPoint may still be loading)
        loop {
            std::thread::sleep(Duration::from_millis(600));
            tick += 1;
            let st = app.state::<AppState>();

            let (source, playback) = {
                let o = lk(&st.output);
                (o.state().source, o.state().playback)
            };

            // ---- PowerPoint watch ----
            let watching = matches!(source, OutputSource::PowerPoint | OutputSource::IdlePowerPoint)
                && matches!(playback, PlaybackState::Live | PlaybackState::Paused);
            if !watching {
                last_pos = -1;
                missing = 0;
                errors = 0;
                warm = 8;
            } else if st.switch_lock.try_lock().is_ok() {
                let status = match st.ppt.try_lock() {
                    Ok(mut p) => {
                        if p.builtin {
                            None // built-in viewer reports slides/finish through audience events
                        } else {
                            Some(p.status())
                        }
                    }
                    Err(_) => None,
                };
                match status {
                    Some(Ok(s)) => {
                        errors = 0;
                        if s.running {
                            missing = 0;
                            if s.position != last_pos {
                                last_pos = s.position;
                                let _ = app.emit("slide_changed", json!({ "position": s.position, "count": s.count }));
                            }
                            // ppSlideShowDone = 5
                            if s.state == 5 && warm == 0 {
                                tracing::info!("presentation finished (slide show state: done)");
                                finished(&app, source);
                            }
                        } else if warm == 0 {
                            missing += 1;
                            if missing >= 3 {
                                missing = 0;
                                tracing::info!("presentation finished (slide show window closed)");
                                finished(&app, source);
                            }
                        }
                    }
                    Some(Err(e)) => {
                        errors += 1;
                        tracing::warn!("PowerPoint status failed: {e}");
                        if errors >= 8 {
                            errors = 0;
                            lk(&st.output).mark_error(format!("PowerPoint stopped responding: {e}"));
                            orchestrator::emit_state(&app);
                        }
                    }
                    None => {}
                }
                if warm > 0 {
                    warm -= 1;
                }
            }

            // ---- automatic idle (only after the operator has used the output this session) ----
            if tick % 16 == 0 {
                auto_idle(&app);
            }
        }
    });
}

fn finished(app: &AppHandle, source: OutputSource) {
    if source == OutputSource::PowerPoint {
        orchestrator::on_item_finished(app);
    } else {
        let st = app.state::<AppState>();
        let _ = lk(&st.output).mark_completed();
        orchestrator::emit_state(app);
    }
}

fn auto_idle(app: &AppHandle) {
    let st = app.state::<AppState>();
    let cfg = lk(&st.idle).clone();
    let Some(mins) = cfg.auto_after_minutes else {
        return;
    };
    if mins == 0 || cfg.mode == IdleMode::None {
        return;
    }
    let elapsed = match *lk(&st.last_activity) {
        Some(t) => t.elapsed(),
        None => return, // never auto-project before the operator has started something
    };
    let eligible = {
        let o = lk(&st.output);
        let s = o.state();
        s.source == OutputSource::None || s.playback == PlaybackState::Completed
    };
    if eligible && elapsed >= Duration::from_secs(mins as u64 * 60) {
        tracing::info!("automatic idle screen after {mins} min of inactivity");
        if let Err(e) = orchestrator::activate_idle(app) {
            tracing::warn!("automatic idle failed: {e}");
        }
    }
}

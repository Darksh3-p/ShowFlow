# ShowFlow PowerPoint helper. Runs as a separate process so COM never blocks the UI.
# Protocol: one JSON command per stdin line; one JSON reply per stdout line (matched by "id").
# ASCII only (Windows PowerShell 5.1 reads BOM-less files as ANSI).
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class SFWin {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int i, int v);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
}
"@
[void][SFWin]::SetProcessDPIAware()

$script:app = $null
$script:pres = $null
$script:ownsApp = $false

function Reply($obj) {
  [Console]::Out.WriteLine(($obj | ConvertTo-Json -Compress -Depth 5))
  [Console]::Out.Flush()
}

function Get-App {
  if ($null -ne $script:app) {
    try { [void]$script:app.Version } catch { $script:app = $null; $script:ownsApp = $false }
  }
  if ($null -eq $script:app) {
    try {
      $script:app = [Runtime.InteropServices.Marshal]::GetActiveObject('PowerPoint.Application')
      $script:ownsApp = $false
    } catch {
      $script:app = New-Object -ComObject PowerPoint.Application
      $script:ownsApp = $true
    }
  }
  return $script:app
}

function Stop-Show {
  if ($null -ne $script:pres) {
    try { $script:pres.SlideShowWindow.View.Exit() } catch {}
    try { $script:pres.Saved = -1 } catch {}
    try { $script:pres.Close() } catch {}
    try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:pres) } catch {}
    $script:pres = $null
  }
}

function Quit-Owned {
  if ($script:ownsApp -and $null -ne $script:app) {
    try {
      if ($script:app.Presentations.Count -eq 0) {
        $script:app.Quit()
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:app)
      }
    } catch {}
  }
  $script:app = $null
  $script:ownsApp = $false
}

# Close read-only, window-less presentations left behind by a previous ShowFlow run or crash.
function Clear-Orphans($app) {
  try {
    for ($i = [int]$app.Presentations.Count; $i -ge 1; $i--) {
      try {
        $q = $app.Presentations.Item($i)
        if ($q.ReadOnly -eq -1 -and $q.Windows.Count -eq 0) { try { $q.Close() } catch {} }
      } catch {}
    }
  } catch {}
}

function Open-Show($cmd) {
  $app = Get-App
  Clear-Orphans $app
  # ReadOnly = msoTrue, Untitled = msoFalse, WithWindow = msoFalse
  $p = $app.Presentations.Open([string]$cmd.path, -1, 0, 0)
  $script:pres = $p
  $s = $p.SlideShowSettings
  $s.ShowType = 2            # ppShowTypeWindowed (we position/strip the window ourselves)
  $s.ShowPresenterView = 0
  $s.AdvanceMode = 2         # ppSlideShowUseSlideTimings
  if ($cmd.loop) { $s.LoopUntilStopped = -1 } else { $s.LoopUntilStopped = 0 }
  $w = $s.Run()
  Place-Window $w ([int]$cmd.x) ([int]$cmd.y) ([int]$cmd.w) ([int]$cmd.h) ([bool]$cmd.topmost)
  return [int]$p.Slides.Count
}

function Get-Status {
  $running = $false; $pos = 0; $state = 0; $count = 0
  if ($null -ne $script:pres) {
    # A COM error (PowerPoint busy / not responding) is reported as an error, NOT as "the show has ended".
    $count = [int]$script:pres.Slides.Count
    $shows = [int]$script:pres.Application.SlideShowWindows.Count
    if ($shows -gt 0) {
      $v = $script:pres.SlideShowWindow.View
      $pos = [int]$v.CurrentShowPosition
      $state = [int]$v.State
      $running = $true
    }
  }
  return @{ ok = $true; running = $running; position = $pos; count = $count; state = $state }
}

function Place-Window($w, $x, $y, $cw, $ch, $top) {
  $h = [IntPtr][int]$w.HWND
  $style = [SFWin]::GetWindowLong($h, -16)
  $style = $style -band (-bnot 0x00CF0000)
  [void][SFWin]::SetWindowLong($h, -16, $style)
  # HWND_TOPMOST = -1 (second display) ; HWND_NOTOPMOST = -2 (single display: operator window stays above)
  # SWP_FRAMECHANGED(0x20) | SWP_SHOWWINDOW(0x40)
  $after = -2
  if ($top) { $after = -1 }
  [void][SFWin]::SetWindowPos($h, [IntPtr]$after, $x, $y, $cw, $ch, 0x60)
}

while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }
  if ($line.Trim().Length -eq 0) { continue }
  $cmd = $null
  try {
    $cmd = $line | ConvertFrom-Json
    $r = $null
    switch ($cmd.cmd) {
      'detect' {
        $installed = Test-Path 'Registry::HKEY_CLASSES_ROOT\PowerPoint.Application'
        $prog = ''
        if ($installed) {
          try { $prog = (Get-ItemProperty 'Registry::HKEY_CLASSES_ROOT\PowerPoint.Application\CurVer').'(default)' } catch {}
        }
        $r = @{ ok = $true; installed = [bool]$installed; progid = $prog }
      }
      'open' {
        Stop-Show
        $count = 0
        try {
          $count = Open-Show $cmd
        } catch {
          # PowerPoint may still be closing or have a stale connection: reset, wait, retry once.
          $script:pres = $null
          $script:app = $null
          $script:ownsApp = $false
          Start-Sleep -Milliseconds 1200
          $count = Open-Show $cmd
        }
        $r = @{ ok = $true; count = $count }
      }
      'next'  { $script:pres.SlideShowWindow.View.Next();     $r = Get-Status }
      'prev'  { $script:pres.SlideShowWindow.View.Previous(); $r = Get-Status }
      'first' { $script:pres.SlideShowWindow.View.First();    $r = Get-Status }
      'last'  { $script:pres.SlideShowWindow.View.Last();     $r = Get-Status }
      'goto'  { $script:pres.SlideShowWindow.View.GotoSlide([int]$cmd.n); $r = Get-Status }
      'pause'  { $script:pres.SlideShowWindow.View.State = 2; $r = Get-Status }   # ppSlideShowPaused
      'resume' { $script:pres.SlideShowWindow.View.State = 1; $r = Get-Status }   # ppSlideShowRunning
      'status' { $r = Get-Status }
      'thumb' {
        $script:pres.Slides.Item([int]$cmd.n).Export([string]$cmd.path, 'PNG', 960, 540)
        $r = @{ ok = $true }
      }
      'stop' { Stop-Show; $r = @{ ok = $true } }
      'quit' { Stop-Show; Quit-Owned; Reply @{ ok = $true; id = $cmd.id }; exit 0 }
      default { throw "unknown command: $($cmd.cmd)" }
    }
    $r['id'] = $cmd.id
    Reply $r
  } catch {
    $id = $null
    if ($null -ne $cmd) { $id = $cmd.id }
    Reply @{ ok = $false; id = $id; error = $_.Exception.Message }
  }
}
Stop-Show
Quit-Owned

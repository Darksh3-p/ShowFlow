# ShowFlow — Claude One-Shot Build Kit

This package is the complete handoff brief for building **ShowFlow**, a Windows-first event presentation control application in **Rust**. It includes one consolidated visual mockup and the requirements, architecture, network/security rules, acceptance tests, and a master prompt for Claude Code.

## Start here
1. Extract this ZIP into a clean project folder.
2. Open that folder in Claude Code on a Windows machine.
3. Ensure Claude Code has permission to read/write the workspace and run terminal commands.
4. Open `CLAUDE_MASTER_BUILD_PROMPT.md`, copy the complete prompt, and submit it.
5. Tell Claude to treat this directory as the authoritative product brief and implement the application in the workspace.

## Package contents
- `CLAUDE_MASTER_BUILD_PROMPT.md` — full implementation prompt.
- `PRODUCT_SPECIFICATION.md` — product scope and user workflows.
- `ARCHITECTURE.md` — Rust-first architecture and Windows integrations.
- `SECURITY_AND_NETWORKING.md` — hotspot, Ethernet/LAN, WebRTC, local TLS, permissions.
- `WINDOWS_ACCEPTANCE_TESTS.md` — executable acceptance checklist and manual hardware tests.
- `UI_DESIGN_SPEC.md` — design system and layout guidance for the single mockup.
- `mockups/ShowFlow_Master_UI_Mockup.png` — the sole consolidated UI reference.

## Important engineering truth
No prompt can guarantee a defect-free one-shot implementation of a complex Windows application. Native PowerPoint automation, display routing, Windows hotspot support, browser screen capture, local HTTPS trust, and WebRTC must be tested on real Windows hardware. The master prompt requires Claude to build, compile, test, repair errors, document any platform limitation, and never claim an unverified feature is complete.

## Product name
ShowFlow is the working name. Keep it configurable in the application metadata so it can be renamed later.

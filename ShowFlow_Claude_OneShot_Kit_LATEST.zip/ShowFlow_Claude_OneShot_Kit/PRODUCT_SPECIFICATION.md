# ShowFlow — Product Specification

## 1. Product vision
ShowFlow is a polished, offline-first Windows event presentation controller. One operator uses one admin interface to manage a custom event playlist, launch native PowerPoint presentations on a projector/second display, play videos and images, receive browser-based speaker screen shares over a local network, and control a configurable idle screen.

The experience should feel like a refined combination of PowerPoint Presenter View and a simple event playlist controller. It must remain approachable for a single operator. Do not expand the MVP into a broadcast/streaming suite.

## 2. Target platform and implementation language
- Windows 10/11 x64, with Windows 11 preferred for validation.
- Rust is the primary application language.
- Recommended UI: Tauri 2 + Rust backend + TypeScript frontend (React or Svelte), unless a documented Windows-specific blocker requires a different Rust-compatible desktop UI. Keep all core business logic in Rust.
- Native Windows integration through carefully isolated Rust modules and minimal audited FFI/PowerShell/COM helper code where necessary.
- Local-first. No mandatory cloud account, subscription, or internet service.

## 3. Core user roles
- **Admin/operator:** manages media, playlists, outputs, speaker sharing, idle content, and live playback.
- **Speaker/guest:** opens a local browser URL, pairs with the event host, and explicitly shares a screen/window/tab.
- **Audience:** sees only the selected content on the projector/output display.

## 4. Media library and folder workflow
- Admin selects an event folder using a native folder picker.
- Recursively scan or scan the selected folder according to a user-configurable depth; default to the selected folder and its immediate children. Avoid silently scanning unrelated locations.
- Index supported files and show filename, type, duration (where relevant), file size, path, thumbnail, and availability.
- Supported primary media: `.ppt`, `.pptx`, common video formats supported by the selected playback engine, and common image formats. Audio may be supported as an optional playlist item if reliable.
- **A visible search bar is mandatory in the selected-folder media browser and playlist editor.** Search by filename; filters for All, Presentations, Videos, Images (and Audio if enabled). Search results must update promptly and allow adding a file to the playlist.
- Support add selected, add all filtered results, remove, reorder via drag-and-drop and move up/down, duplicate item, clear with confirmation, and save/load/rename/duplicate playlists.
- Playlist is a virtual arrangement; never move, rename, or modify original media files unless the user explicitly invokes a separate file-management action.
- Detect missing/moved files and provide relink/browse action. Never silently skip missing items.
- Multiple playlists can reference the same media library.

## 5. Playlist playback and PowerPoint
- Pressing **Go Live / Start Playlist** begins the selected item on the configured audience display, not on the operator display.
- For `.ppt` and `.pptx`, use the installed Microsoft PowerPoint Desktop application through native COM automation to preserve original slide rendering, animations, transitions, and embedded media as far as PowerPoint itself supports them. Do not convert presentations to PDF or static images as the primary playback path.
- Detect PowerPoint installation and report a clear setup error if unavailable. Explain licensing/activation requirements without attempting to bypass them.
- Run all COM automation on a dedicated STA thread/process; never block the UI thread. Include robust lifecycle cleanup and recovery.
- Operator UI should provide current slide preview, next slide preview, slide count, previous/next slide, first/last slide, and playlist previous/next controls. Slide thumbnails are previews and may not represent the exact live animation frame.
- On reaching the end of a presentation, follow per-item or global policy: wait for operator or auto-advance to next playlist item. Make the behavior visible and configurable.
- Next playlist item must switch to the next media item. Do not confuse slide navigation with playlist navigation.
- If the user presses Stop/Exit, return to the configured idle state or a safe black output according to settings.
- Prevent desktop/taskbar exposure during switching. Validate monitor arrangement and slideshow window placement.

## 6. Video and image playback
- Integrated playback in the audience output window; do not require the operator to manually open VLC or another player.
- Use a Rust-compatible VLC/libVLC integration or another proven Windows playback engine. Validate licensing and redistribution terms before bundling codecs/runtime.
- Provide play, pause, seek, volume, mute, restart, duration/progress, and stop.
- Per-item options: auto-advance at end, loop, start position (optional), and volume.
- Images display full-screen with fit/fill behavior and optional duration for automatic advance.
- Switching between PowerPoint, video, image, speaker share, and idle content must be orchestrated by one output controller so only one source owns the audience output at a time.

## 7. Output displays and wired connections
- Support the Windows extended desktop with operator UI on the admin monitor and audience output on a selected second display/projector.
- HDMI, DisplayPort, and USB-C display connections are supported automatically when Windows recognizes them as displays. These are physical display connections, not network protocols; ShowFlow should enumerate available Windows displays and let the operator select one.
- Include display selection, resolution/refresh information where available, test output, reconnect detection, and safe fallback if the projector disconnects.
- Support a single-screen development mode with a clearly labeled preview/simulation; never pretend a second display is connected.
- **Ethernet/LAN cable is supported for network connectivity and speaker sharing**, provided the PCs are on a reachable subnet and firewall rules permit traffic. Ethernet is not a video cable and does not directly drive a projector.
- Also support same Wi-Fi network and admin-hosted Windows Mobile Hotspot.

## 8. Browser-based speaker screen sharing
- Speaker does not need to install ShowFlow.
- Admin can choose either (a) ShowFlow-hosted Windows hotspot, or (b) existing Wi-Fi/Ethernet LAN where admin and speaker PCs can reach one another.
- ShowFlow starts a local pairing/signaling service and presents a QR code plus a manually copyable URL and short pairing code.
- Speaker opens the URL in a supported modern browser (initial target: current Microsoft Edge and Google Chrome on Windows), enters/preserves pairing code, and chooses browser screen/window/tab capture using the browser's native permission prompt.
- Use WebRTC for media transport. Use a local signaling channel (e.g. WebSocket) hosted by the admin app. No cloud relay or internet dependency in the MVP. Clearly report if direct peer connection cannot be established; do not silently send screen content to a cloud service.
- Admin sees incoming request, speaker/device label if available, live preview, and Accept & Show / Reject controls. Never route the share to the projector before explicit admin acceptance.
- During sharing, show speaker connected state, stream health, stop sharing, and return-to-playlist controls. Speaker can stop sharing from browser.
- On disconnect, freeze/blank safely and offer return to prior playlist item or idle screen. Never leave stale confidential content visible indefinitely.
- Optional system audio sharing only if browser/OS capture path supports it; clearly indicate browser limitations. Video-only screen share is acceptable for MVP if audio cannot be made reliable.
- Multiple simultaneous incoming shares are out of MVP; one active speaker stream at a time.

## 9. Network modes and constraints
### Mode A: Admin-hosted hotspot
- Provide a guided workflow to open Windows Mobile Hotspot settings or activate/control it only through supported documented Windows APIs.
- Do not promise every Wi-Fi adapter supports hotspot hosting. Detect/report unsupported hardware or Windows configuration and offer existing-network mode.
- After hotspot is enabled, detect the host's reachable local IPv4 address and bind the local service to the correct interface.
- Show SSID/connection instructions where Windows exposes them; do not display or log hotspot passwords unnecessarily.
### Mode B: Existing Wi-Fi or Ethernet LAN
- Detect candidate local interfaces and display the correct reachable address for speaker devices.
- Provide QR and copy URL.
- Handle multiple network adapters, VPNs, Windows firewall, client isolation, and changing IP addresses with actionable diagnostics.
- Do not assume that two devices on the same Wi-Fi name can communicate; verify reachability or guide the user to disable AP/client isolation.

## 10. Idle Screen Studio and blackout
- Distinguish **Black Screen** (immediate pure black output) from **Idle Screen** (configured content).
- Idle content modes: native PowerPoint idle slideshow, looping video, static image; pure black remains a separate quick action.
- Allow selecting source file, previewing it, configuring loop/repeat, mute/volume, and optional automatic activation after configurable inactivity.
- Idle activation must not interrupt a live speaker share or active playlist item unless the operator explicitly chooses to switch.
- One-click return to live playlist.

## 11. Main interface / design
- Dark glassmorphism with translucent navy panels, subtle blur, fine borders, soft shadows, restrained cyan/blue/purple accents, high contrast text, and clear status indicators.
- Use the single image in `mockups/ShowFlow_Master_UI_Mockup.png` as the primary visual reference. It is a visual target, not a pixel-perfect requirement.
- Sidebar: Dashboard, Playlist Manager, Media Library, Wireless Share, Idle Screen Studio, Display Manager, Settings.
- Main dashboard: large Live Output Preview; playlist panel with **Search files...** field and media filters; next item card; central transport controls; quick actions; network/hotspot card with QR; speaker-share card; idle screen card; output display card; connected devices/status.
- Use readable typography and spacing. Avoid excessive glow, tiny labels, crowded panels, and decorative controls that do nothing.
- Responsive within common desktop window sizes, but optimize for 1920×1080 and 16:9 operator monitors.
- Every visible control must work or be clearly disabled with an explanation. No fake buttons or simulated success in production mode.

## 12. Data and persistence
- SQLite local database.
- Persist media index, playlists, playlist item order/settings, display preference, idle configuration, recent sessions, and app settings.
- Store paths in a robust way; validate paths on load and support relinking.
- Provide automatic safe recovery after crash/restart: restore last selected program/playlist and offer to resume, but do not unexpectedly start projecting without operator confirmation.
- Use migrations and transactional writes.

## 13. Keyboard and operator usability
Suggested configurable shortcuts:
- Space: play/pause current video (or slideshow action only when safe and unambiguous).
- Left/Right: previous/next slide while PowerPoint is active.
- Ctrl+Left / Ctrl+Right: previous/next playlist item.
- Enter: Go Live / play selected item.
- B: instant black screen.
- Esc: stop/exit current source, with confirmation where destructive.
- F: toggle output fullscreen only if safe.
Avoid stealing shortcuts from PowerPoint; show current shortcut context and allow remapping.

## 14. MVP exclusions
Do not implement cloud accounts, remote internet control, multiple simultaneous speaker shares, complex broadcast graphics, lower thirds, live streaming, multi-projector independent outputs, or elaborate audio mixing in the first release. Keep extension points for later.

## 15. Definition of done
The application is not complete merely because a UI mockup or scaffold exists. It must build on Windows, persist playlists, search selected-folder files, launch native PowerPoint on the selected external display, play video, switch sources, display an idle loop/black screen, and accept a browser screen share over both supported network modes on validated hardware. All unsupported or untested features must be identified honestly.

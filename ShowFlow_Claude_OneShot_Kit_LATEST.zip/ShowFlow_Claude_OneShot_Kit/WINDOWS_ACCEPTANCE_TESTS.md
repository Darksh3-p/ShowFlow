# ShowFlow — Windows Acceptance Test Plan

Run on real Windows 10/11 hardware. Record Windows build, Office version, Wi-Fi adapter/driver, display adapter, monitor topology, and test result. Mark unsupported cases honestly.

## A. Build and startup
- [ ] Clean checkout builds with documented commands.
- [ ] Installer installs/uninstalls cleanly.
- [ ] App starts without internet.
- [ ] Missing PowerPoint is detected with a useful message.
- [ ] Logs are written locally and contain no secrets.

## B. Media library and playlist
- [ ] Select a folder containing PPTX, PPT, MP4, MOV, JPG and PNG samples.
- [ ] Search bar filters filenames in the selected folder.
- [ ] Presentation/video/image filters work.
- [ ] Add one search result to playlist.
- [ ] Add multiple selected results and add all filtered results.
- [ ] Reorder, remove, duplicate, save, rename, reload and duplicate playlists.
- [ ] Original media files are not moved or modified.
- [ ] Missing file warning and relink flow work.

## C. Native PowerPoint output
- [ ] With PowerPoint installed, Go Live opens PPTX as a native slideshow.
- [ ] Slideshow appears on the selected second display/projector, not admin screen.
- [ ] Animations, transitions, embedded media behave as PowerPoint supports.
- [ ] Previous/next slide controls work.
- [ ] Slide end wait/auto-advance policy works.
- [ ] Playlist Next switches to the next media item.
- [ ] Stop closes only ShowFlow-owned presentation/session and does not close unrelated PowerPoint files.
- [ ] PowerPoint crash/automation timeout recovers safely.

## D. Video and image output
- [ ] Supported sample video plays full-screen on audience display.
- [ ] Play, pause, seek, volume, mute and stop work.
- [ ] Video auto-advance and loop options work.
- [ ] Image fit/fill and optional timed advance work.
- [ ] PPT -> video -> PPT switching does not show desktop/taskbar or overlapping outputs.

## E. Displays and wired outputs
- [ ] HDMI projector is detected as a Windows display.
- [ ] DisplayPort and USB-C display are detected when supported by hardware.
- [ ] Operator remains on admin display while audience content is on projector.
- [ ] Unplug/replug projector is detected and safe recovery offered.
- [ ] Single-display fallback is clearly labeled as preview/simulation.
- [ ] Ethernet-connected admin and speaker PCs can reach local sharing service on a suitable LAN.

## F. Speaker browser screen share — existing network
- [ ] Admin and speaker connect to same Wi-Fi/LAN.
- [ ] Admin generates QR code and pairing URL reachable from speaker PC.
- [ ] Speaker opens in current Edge and Chrome without installing app.
- [ ] HTTPS/certificate onboarding is clear and does not silently weaken browser security.
- [ ] Browser prompts user to choose screen/window/tab.
- [ ] Admin receives request and preview.
- [ ] Share is not projected before admin acceptance.
- [ ] Accept, reject, stop and speaker-side stop work.
- [ ] Disconnect and firewall/client-isolation diagnostics are useful.
- [ ] No cloud relay or internet required.

## G. Speaker browser screen share — admin hotspot
- [ ] Supported adapter can enable Windows Mobile Hotspot.
- [ ] Speaker connects to hotspot and opens QR URL.
- [ ] Correct host interface/IP is selected.
- [ ] Unsupported adapter or disabled policy produces an honest actionable message.

## H. Idle and blackout
- [ ] Pure Black action immediately displays full black.
- [ ] Idle video loops on audience display.
- [ ] Native PowerPoint idle slideshow displays correctly.
- [ ] Static image mode works.
- [ ] Auto-idle activates only according to configured policy.
- [ ] Active speaker share is not interrupted by idle timer.
- [ ] Return to playlist works.

## I. Recovery and reliability
- [ ] Restart restores playlists/settings.
- [ ] App crash does not auto-project without operator confirmation.
- [ ] Missing media, no projector, lost network, dropped WebRTC stream, PowerPoint unavailable and playback errors have recoverable UI.
- [ ] Run a 60-minute mixed playlist with repeated PPT/video/share transitions without resource leak or stuck state.

## Demo acceptance scenario
Prepare one folder with at least three PPT/PPTX files, three videos and two images. Search and add specific files to a playlist, reorder it, start on projector, navigate slides from admin, advance to video, receive a browser screen share over LAN, accept it to projector, stop and return to playlist, activate idle video, switch to native PowerPoint idle slideshow, then use instant Black Screen. Repeat sharing via hosted hotspot if adapter supports it.

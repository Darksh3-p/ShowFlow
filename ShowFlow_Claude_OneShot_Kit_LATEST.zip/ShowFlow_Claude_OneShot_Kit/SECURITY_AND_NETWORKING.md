# ShowFlow — Security and Networking Requirements

## Network topology
ShowFlow supports both modes:
1. **Admin-hosted hotspot:** the admin PC uses Windows Mobile Hotspot when the Wi-Fi adapter and Windows configuration support it.
2. **Existing network:** admin and speaker connect to the same reachable Wi-Fi or Ethernet LAN. The admin PC may be connected by Ethernet while the speaker is on Wi-Fi, as long as the router bridges the clients and does not isolate them.

The projector connects to the admin PC as a Windows-recognized display over HDMI, DisplayPort, or USB-C. This display cable is separate from the LAN connection.

## Local sharing design
- Local web page and signaling server run on the admin PC.
- WebRTC carries the actual screen/audio media.
- Pairing URL and code are generated per session; code should be high entropy or short-lived and rate-limited.
- Admin must explicitly accept every share before it can become the audience output.
- One active share at a time in MVP.
- No cloud signaling, TURN relay, or third-party media relay in MVP. Clearly report NAT/firewall/network failures rather than quietly falling back to an internet relay.

## HTTPS / browser capture
Modern browsers restrict `getDisplayMedia()` to secure contexts and user gestures. A LAN IP over plain HTTP is not a reliable deployment path. Implement a practical local HTTPS approach:
- Generate a per-install local certificate and private key, protect the key using Windows user-scoped storage/DPAPI where practical.
- Provide a clear first-use trust/setup flow. Do not silently install a root certificate or weaken browser security.
- Prefer a stable local hostname with a certificate SAN matching it; explain limitations of IP-address certificates and browser trust.
- Offer a fallback diagnostic page and copyable URL.
- Never request screen capture without the speaker clicking the browser's share button and choosing a target.

## Windows firewall and interface selection
- Bind only to selected private/local interfaces; do not bind to all interfaces by default.
- Explain required inbound ports and create firewall rules only with explicit user consent and least privilege. Provide manual instructions if elevation is unavailable.
- Detect VPNs, multiple NICs, changing DHCP addresses, client/AP isolation, and Windows firewall blocks where possible.
- Show the chosen IPv4 address and interface name. QR payload must point to a reachable URL, not `localhost`.
- Avoid exposing admin controls through the speaker webpage. The speaker endpoint only creates/ends its own share and shows status.
- Pairing endpoints must have CSRF/origin protections appropriate to local web app, input validation, rate limits, and session expiry.

## Privacy
- Do not record or save speaker screen content by default.
- Do not retain streams after stop/disconnect.
- Display a visible sharing indicator on both admin and speaker browser.
- Do not log screen content, audio, passwords, private keys, or raw pairing secrets.
- Make speaker identity labels user-editable/optional; do not claim browser identity is verified.

## Hotspot constraints
Windows Mobile Hotspot capability depends on Windows version, adapter/driver, and device policy. ShowFlow must detect and guide; it must not claim hotspot hosting is available on every PC. If unavailable, guide the admin to enable Windows Mobile Hotspot manually or use existing Wi-Fi/Ethernet LAN.

# ShowFlow — Technical Architecture

## Recommended stack
- **Desktop shell:** Tauri 2.
- **Backend/core:** Rust stable, async Tokio where appropriate.
- **Frontend:** TypeScript + React (or Svelte) with a component system and CSS glassmorphism design tokens.
- **Persistence:** SQLite via `sqlx` or `rusqlite` (choose one; use migrations).
- **Local HTTP/WebSocket signaling:** Axum + Tokio, bound only to intended local interfaces.
- **Screen sharing:** WebRTC via a maintained Rust-compatible WebRTC implementation, or a narrowly scoped, documented native/browser integration. Validate Windows support and maturity before committing.
- **PowerPoint:** Windows COM automation via `windows` crate / generated COM bindings or a small isolated helper process. All COM calls on an STA thread.
- **Display enumeration:** Windows DisplayConfig APIs via `windows` crate.
- **Video:** select a maintained Rust-friendly playback backend with Windows packaging/licensing validated. If using libVLC, document runtime DLL/plugin packaging and LGPL/GPL implications; do not assume a NuGet/C# wrapper is directly usable from Rust.
- **Logging:** `tracing` + rolling file output.
- **Packaging:** Tauri Windows installer/bundle; include prerequisite checks and a clean uninstall path.

## Architectural principles
1. Keep UI state separate from playback/network state.
2. All output sources go through a single `OutputController` / state machine.
3. Treat PowerPoint COM as a separate adapter with strict thread affinity.
4. Treat network services as local-only by default; never expose admin APIs to untrusted networks.
5. Keep file indexing and thumbnail work off the UI thread.
6. Persist user changes transactionally.
7. Use explicit capability detection for Windows features; never assume a device supports hotspot or a second display.

## Suggested workspace layout
```text
showflow/
  Cargo.toml                  # workspace
  src-tauri/                  # Tauri entrypoint and Rust command registration
  crates/
    showflow-core/            # domain models, traits, state machine
    showflow-media/           # folder scan, metadata, thumbnails
    showflow-playlist/        # playlist operations and validation
    showflow-storage/         # SQLite, migrations, repositories
    showflow-powerpoint/      # isolated Windows COM adapter
    showflow-video/           # playback adapter
    showflow-display/         # monitor enumeration and audience window routing
    showflow-sharing/         # local host, pairing, signaling, WebRTC
    showflow-idle/            # idle content policy
    showflow-logging/         # tracing setup
  frontend/
    src/
      app/
      components/
      pages/
      styles/
      state/
  tests/
  docs/
  scripts/
```

## Domain models (minimum)
- `MediaFile { id, path, filename, media_type, size_bytes, duration_ms?, modified_at, availability, thumbnail_path? }`
- `Playlist { id, name, folder_root, created_at, updated_at }`
- `PlaylistItem { id, playlist_id, media_file_id, position, auto_advance, loop, volume, start_position_ms? }`
- `DisplayTarget { id, device_name, bounds, resolution, is_primary, connected }`
- `OutputSource = PowerPoint | Video | Image | SpeakerShare | IdleVideo | IdlePowerPoint | Black`
- `PlaybackState = Idle | Loading | Live | Paused | Completed | Error`
- `NetworkMode = HostedHotspot | ExistingNetwork | Offline`
- `ShareSession { id, pairing_code_hash, state, peer_label?, started_at?, last_seen_at? }`

## Core services / interfaces
- `MediaLibraryService`: scan folder, search, filter, refresh, detect missing files, relink.
- `PlaylistService`: CRUD, add/remove/reorder/duplicate, validation, persistence.
- `PowerPointService`: detect installation, open, launch slideshow on audience display, slide navigation, monitor events, close safely.
- `VideoService`: load/play/pause/seek/volume/stop and report events.
- `DisplayService`: enumerate displays, select audience target, watch topology changes, create audience window.
- `OutputController`: serialize transitions between sources; ensure only one active source; recover from errors.
- `SharingService`: network interface discovery, local signaling, QR payload, pairing, WebRTC lifecycle, consent state.
- `IdleService`: configure and activate idle source according to policy.
- `SettingsService`: validated settings and migrations.

## Output state machine
```text
Idle -> Loading -> Live <-> Paused -> Completed
                     |                 |
                     v                 v
                   Error          AutoAdvance -> Loading(next)

Any source -> Switching -> next source
Any source -> Black (operator quick action)
Idle/Completed -> configured Idle content (if enabled)
```
The output controller must serialize switching and await the old source being stopped/hidden before showing the new source. Use a short controlled transition/black frame if required to avoid overlapping windows; never promise seamless transitions unless measured.

## PowerPoint COM isolation
- Initialize COM apartment as STA on a dedicated thread.
- Marshal commands to that thread through a channel.
- Do not pass COM interface pointers across threads.
- Detect PowerPoint process/application state; avoid closing unrelated user sessions or documents.
- Track the presentation/slideshow window created by ShowFlow and only control/close that instance.
- Use a watchdog and bounded timeouts. On automation failure, report a recoverable error and avoid leaving orphaned PowerPoint windows.
- Test with actual installed Office versions and both `.ppt` and `.pptx`.

## Frontend/backend contract
Use typed Tauri commands/events. Examples:
- Commands: `scan_folder`, `search_media`, `create_playlist`, `add_playlist_items`, `reorder_playlist_item`, `start_playlist`, `go_live_item`, `next_slide`, `next_playlist_item`, `select_audience_display`, `start_hotspot_guide`, `start_lan_host`, `create_pairing_session`, `accept_share`, `reject_share`, `stop_share`, `set_idle_mode`, `activate_black_screen`.
- Events: `media_scan_progress`, `playlist_changed`, `output_state_changed`, `slide_changed`, `display_topology_changed`, `network_status_changed`, `share_request_received`, `share_stream_state_changed`, `playback_error`.
- Validate all command inputs in Rust. Do not trust frontend-provided paths, pairing codes, or network addresses.

## Build strategy
Implement in vertical slices that compile and run after each milestone. Avoid generating the entire codebase before first compilation. Keep `cargo fmt`, `cargo clippy`, unit tests, and frontend type checks green. Include a Windows CI/build script if feasible, plus a documented manual hardware test matrix.

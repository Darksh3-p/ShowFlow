# Claude Handoff Instructions

Read the following files completely before coding:
1. `PRODUCT_SPECIFICATION.md`
2. `ARCHITECTURE.md`
3. `SECURITY_AND_NETWORKING.md`
4. `UI_DESIGN_SPEC.md`
5. `WINDOWS_ACCEPTANCE_TESTS.md`
6. `mockups/ShowFlow_Master_UI_Mockup.png`

The master prompt is in `CLAUDE_MASTER_BUILD_PROMPT.md`.

Authority order: product and security requirements take precedence over visual mockup details. If a library or Windows API cannot meet a requirement, investigate a supported alternative and explain the tradeoff before silently dropping functionality. Do not fake a working feature. Keep the user informed with concise milestone summaries and exact commands/results.

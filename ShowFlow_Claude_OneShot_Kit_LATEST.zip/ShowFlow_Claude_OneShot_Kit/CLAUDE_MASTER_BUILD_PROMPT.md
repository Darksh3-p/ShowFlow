# MASTER PROMPT — BUILD SHOWFLOW FOR WINDOWS IN RUST

You are the senior Windows desktop engineer, Rust architect, product designer, QA engineer, and release engineer responsible for delivering **ShowFlow**. Build the real application in the current workspace. Do not merely describe it, create a mockup, or produce a scaffold and stop.

## Read first
Before writing code, read all project handoff files:
- `PRODUCT_SPECIFICATION.md`
- `ARCHITECTURE.md`
- `SECURITY_AND_NETWORKING.md`
- `UI_DESIGN_SPEC.md`
- `WINDOWS_ACCEPTANCE_TESTS.md`
- `mockups/ShowFlow_Master_UI_Mockup.png`

Treat these files as the complete product brief. The user should not need to re-explain any requirements in chat. If requirements conflict, follow security and product specification first, architecture second, mockup third.

## Mission
Deliver a working Windows 10/11 x64 desktop application named ShowFlow, implemented primarily in **Rust**. Recommended stack is Tauri 2 + Rust backend + TypeScript frontend. Keep all core logic, media indexing, playlist state, output orchestration, persistence, network services, and integration adapters in Rust. Small frontend code is acceptable for UI. Use minimal Windows-native interop only where necessary.

The application must provide:
1. Modern premium dark glassmorphism admin interface.
2. Selected-folder media library with a visible filename search bar.
3. Search and filter PPT/PPTX, videos, and images, then add results to a custom playlist.
4. Save/reopen/reorder/duplicate playlists without changing original files.
5. Native PowerPoint Desktop slideshow playback on the selected projector/second monitor.
6. Integrated video and image playback on that same audience output.
7. Operator preview and separate audience display.
8. Browser-based speaker screen sharing without requiring speaker software installation.
9. Two network modes: admin-hosted Windows hotspot OR existing Wi-Fi/Ethernet LAN.
10. Admin preview and explicit Accept & Show before speaker content reaches projector.
11. Idle Screen Studio with both native PowerPoint idle slideshow and looping video, plus static image.
12. Separate instant pure Black Screen action.
13. HDMI/DisplayPort/USB-C external display support through Windows display enumeration; Ethernet/LAN support for network sharing.
14. Local SQLite persistence, recovery, diagnostics, logs, and installer.

## Non-negotiable workflow behavior
- Selecting a folder populates the media browser. The search field filters files within that selected folder. The user can search `welcome`, find `Welcome.pptx`, and add it directly to the playlist. Search filters must not silently search the entire PC.
- Starting a playlist automatically launches its first item on the selected projector/second monitor. PPT/PPTX must use native installed Microsoft PowerPoint automation, not PDF/image conversion as the main playback method.
- Slide navigation and playlist navigation are separate controls.
- Playlist Next switches to the next media item. PowerPoint Next Slide advances within the current presentation.
- A playlist can contain PowerPoint, video, and image items in a manually arranged order.
- HDMI/DP/USB-C are display connections. Ethernet/Wi-Fi/hotspot are network connections. Implement both types correctly; never describe an Ethernet cable as a projector video cable.
- Speaker can connect via the admin's Windows hotspot or the same reachable Wi-Fi/Ethernet LAN. Speaker uses a browser and does not install ShowFlow.
- The admin sees a pending request and preview. Only Accept & Show routes it to projector.
- Idle content supports a PowerPoint slideshow and looping video. Black Screen is a separate instant pure-black action.
- Never automatically project after app restart without operator confirmation.

## Implementation discipline
Do not generate a huge uncompiled code dump. Work in vertical slices and keep the project building after every milestone. Start by checking the environment and creating a concise implementation plan, then proceed without asking the user to restate the brief. Ask only if an unavoidable product decision is genuinely missing.

### Milestone 0 — Environment and feasibility
- Inspect OS, Rust toolchain, Node/package manager, Tauri prerequisites, installed Office/PowerPoint if available, and display/network capabilities.
- Verify current crate/API support for Windows and selected media/WebRTC integrations from authoritative docs or crate metadata. Do not invent crate APIs.
- Validate licensing and redistribution implications for video engines and codecs.
- Write `docs/FEASIBILITY_AND_DEPENDENCIES.md` listing chosen versions, prerequisites, risks, and any hardware-dependent validation.
- If running outside Windows, still implement portable core/UI and compile what is possible, but clearly identify Windows-only integration tests that cannot be executed in this environment.

### Milestone 1 — Workspace and design system
- Create Cargo workspace and Tauri app.
- Implement the full navigation and responsive glassmorphism UI based on the single mockup.
- Create typed models, command/event contracts, error handling, logging, settings, and SQLite migrations.
- Every control must be wired to a real action or shown disabled with a reason. No fake success states.

### Milestone 2 — Media library and playlist
- Native folder picker, indexing, supported extension detection, metadata and thumbnails.
- Selected-folder search bar, media-type filters, add selected/add all, playlist search, drag/drop reorder, remove, duplicate, save/load/rename.
- Missing-file detection and relink.
- Unit tests for search, filtering, ordering, persistence and paths.

### Milestone 3 — Audience output and display management
- Enumerate Windows displays; choose audience display; create dedicated full-screen output window.
- Implement single OutputController/state machine to ensure only one active source.
- Add display disconnect/reconnect handling and safe preview fallback.
- Implement HDMI/DP/USB-C support via Windows display enumeration; these work when Windows recognizes the connected monitor/projector.

### Milestone 4 — Video and images
- Integrate a real Windows playback engine with correct runtime packaging and license notices.
- Implement controls, seek, mute/volume, loop, auto-advance and image output.
- Test transitions and resource cleanup.

### Milestone 5 — Native PowerPoint
- Implement PowerPoint detection and native COM automation in a dedicated STA thread or isolated helper process.
- Open PPT/PPTX and start native slideshow on audience display.
- Implement slide controls, current/next slide preview where feasible, completion events, auto-advance/wait behavior, and safe stop.
- Never close unrelated PowerPoint presentations or processes.
- If the host lacks PowerPoint, show a clear prerequisite message and keep other app features usable.

### Milestone 6 — Browser speaker sharing
- Local Axum/WebSocket signaling and WebRTC media transport.
- QR code and manually copyable local URL plus pairing code.
- Implement both existing LAN mode and hosted hotspot guidance/activation where supported.
- Browser page must use explicit user gesture and native getDisplayMedia permission.
- Provide HTTPS certificate setup/trust flow without silently installing a root CA or weakening browser security.
- Admin preview, accept, reject, stop, disconnect, reconnect diagnostics.
- No cloud relay, cloud account, or internet dependency. If peer connectivity fails, show a specific error and troubleshoot path.
- Test Edge and Chrome on actual Windows devices where available.

### Milestone 7 — Idle Screen Studio
- Native PowerPoint idle slideshow, looping video, static image, auto-idle settings.
- Instant pure black screen action.
- Idle must not interrupt active sharing or live playback unless operator explicitly switches.

### Milestone 8 — Hardening and release
- Run format, clippy, unit/integration tests, frontend lint/typecheck/build, and package build.
- Fix all errors that can be reproduced in the current environment. Repeat until clean or document an external prerequisite.
- Add startup diagnostics, clear errors, recovery, logs, installer, README, user guide, troubleshooting guide, and license notices.
- Complete acceptance checklist and label each test PASS / FAIL / NOT TESTABLE with evidence.
- Do not claim Windows-only behavior is verified if the environment cannot run it.

## Engineering requirements
- Use typed errors and validated commands; do not panic on normal failures.
- No long-running file scans, COM calls, or network operations on the UI thread.
- COM must be STA-thread-affine; never move COM pointers between threads.
- Use transactions and schema migrations for SQLite.
- Use bounded channels/timeouts and cancellation for playback/network operations.
- Do not log credentials, private keys, pairing secrets, or captured screen/audio.
- Local network services bind only to selected private interfaces; require explicit consent for firewall rules/elevation.
- No automatic cloud fallback for WebRTC.
- Do not bundle proprietary dependencies without confirming license/redistribution rights.
- Provide keyboard shortcuts, tooltips, empty/loading/error states, and accessibility labels.
- Keep MVP scope controlled. Do not add cloud accounts, streaming, lower-thirds, complex audio mixing, multiple simultaneous speaker streams, or independent multi-projector outputs.

## Definition of done
A buildable, installable Windows application with a real UI and real backend integrations. At minimum, it must demonstrably:
- Search media in selected folder and add search results to playlist.
- Save/reload/reorder playlist.
- Start a PPT/PPTX natively on selected external display when PowerPoint is installed.
- Play video/image on audience display.
- Switch between playlist sources.
- Use pure black and configured idle PowerPoint/video.
- Pair a speaker browser on LAN and, on supported hardware, admin hotspot; receive screen share; preview; accept; project; stop.
- Distinguish display cable output from network cable connectivity.

If a feature cannot be completed or verified, do not fake it. Implement the safest useful subset, clearly mark it as incomplete, state exactly what is missing and why, and provide a precise manual validation procedure.

## Final response format
When finished, report:
1. What was implemented.
2. Exact build/run/package commands and outputs.
3. Tests run with pass/fail/not-testable status.
4. Required Windows/Office/hardware prerequisites.
5. Known limitations and anything requiring real-device validation.
6. Paths to installer, source, logs, and user guide.

Begin by reading all handoff documents and inspecting the current workspace. Then build ShowFlow.

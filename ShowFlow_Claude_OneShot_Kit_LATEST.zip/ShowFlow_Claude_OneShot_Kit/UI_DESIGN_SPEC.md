# ShowFlow — UI Design Specification

Use `mockups/ShowFlow_Master_UI_Mockup.png` as the single visual north star.

## Visual language
- Premium dark glassmorphism: deep navy background, translucent indigo panels, subtle blur, fine cool-blue borders.
- Accent palette: cyan/electric blue for primary actions, restrained violet for secondary emphasis, green for healthy/connected states, amber for warnings, red for stop/error.
- High contrast body text; do not use tiny low-contrast labels despite the visual reference.
- Soft rounded corners, consistent spacing, restrained glow only on active states.
- Use Lucide-style icons consistently. Icons must have labels or accessible names.

## Main dashboard composition
- Top bar: ShowFlow logo/name, active event/program selector, selected output status, window controls.
- Left navigation: Dashboard, Playlist Manager, Media Library, Wireless Share, Idle Screen Studio, Display Manager, Settings.
- Center: large Live Output Preview with explicit audience display label.
- Right: Playlist panel with a prominent **Search files...** input and filters All / Presentations / Videos / Images. Results display file type icon, thumbnail, filename, duration and add/play action. Selected-folder context must be visible.
- Below preview: Next Item card and central controls Previous, Black Screen, Go Live, Next.
- Lower cards: Screen Share status/preview/stop; Idle Screen configured mode/edit; Output Control selected display and connection; Network & Devices mode, IP/URL, QR code and connected speakers.
- Quick Actions: Idle Screen, Black Screen, Pause, Stop All.
- Bottom status bar: Ready/Live/error, output display and resolution, network status.

## Playlist search interaction
- Search input is always visible when browsing a selected folder or adding playlist media.
- Typing filters the selected folder's indexed media immediately by filename.
- Tabs/filter chips distinguish presentations, videos and images.
- Each result has an Add action; multiple selection and Add Selected are supported.
- Search must not silently search the whole PC. Show the active folder path and offer Change Folder.
- Search also supports filtering the current playlist separately from searching the media library; label these two scopes clearly.

## Output / connection labels
Use explicit labels to prevent confusion:
- Audience display: Projector (HDMI), DisplayPort Monitor, USB-C Display, etc.
- Network mode: ShowFlow Hotspot / Existing Wi-Fi / Ethernet LAN.
- Explain HDMI/DP/USB-C are display connections; Ethernet/Wi-Fi are network connections.

## Accessibility and behavior
- Keyboard focus, readable contrast, scalable text, tooltips, and confirmation for Stop All/clear playlist.
- Connected states must be based on actual backend status.
- Loading, empty, offline, missing-file, no-projector, PowerPoint-not-installed, network-blocked and share-request states must all have designed UI.
- Never use static mock data in production screens once backend integration is expected.

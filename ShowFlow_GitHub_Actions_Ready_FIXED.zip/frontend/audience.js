import { PptxRenderer } from 'pptx-browser';
(function () {
  'use strict';
  var T = window.__TAURI__;
  var invoke = T.core.invoke;
  var convert = T.core.convertFileSrc;
  var stage = document.getElementById('stage');
  var token = 0;
  var videoEl = null;
  var pptRenderer = null;
  var pptCanvas = null;
  var pptIndex = 0;
  var pptCount = 0;
  var pptLoop = false;
  var pptPaused = false;
  var pptRenderWidth = 0;
  var lastTimeEmit = 0;
  var imageTimer = null;
  var share = { ws: null, pc: null, conn: null, active: false, retry: null };

  function emit(payload) {
    payload.token = token;
    try { T.event.emit('audience_event', payload); } catch (e) {}
  }

  function clearStage() {
    if (imageTimer) { clearTimeout(imageTimer); imageTimer = null; }
    closeShare();
    if (pptRenderer) { try { pptRenderer.destroy(); } catch (e) {} pptRenderer = null; }
    pptCanvas = null; pptIndex = 0; pptCount = 0; pptPaused = false;
    if (videoEl) { try { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); } catch (e) {} videoEl = null; }
    stage.innerHTML = '';
  }

  function apply(cmd) {
    if (!cmd || !cmd.kind) return;
    if (cmd.kind === 'control') return control(cmd);
    if (cmd.kind === 'pptx_control') return controlPptx(cmd);
    token = cmd.token || token;
    clearStage();
    switch (cmd.kind) {
      case 'black': break;
      case 'test': showTest(cmd); break;
      case 'video': showVideo(cmd); break;
      case 'image': showImage(cmd); break;
      case 'share': startShare(cmd); break;
      case 'pptx': startPptx(cmd); break;
      case 'pptx_control': controlPptx(cmd); break;
    }
  }

  function showTest(cmd) {
    var d = document.createElement('div');
    d.className = 'test';
    d.innerHTML = '<span>ShowFlow output test<br>' + (cmd.label || '') + '</span>';
    stage.appendChild(d);
  }

  function showImage(cmd) {
    var img = document.createElement('img');
    img.className = cmd.fit === 'fill' ? 'fill' : 'fit';
    img.onerror = function () { emit({ type: 'error', message: 'Image failed to load' }); };
    img.src = convert(cmd.path);
    stage.appendChild(img);
    if (cmd.advance_after_secs) {
      var t = token;
      imageTimer = setTimeout(function () { token = t; emit({ type: 'ended' }); }, cmd.advance_after_secs * 1000);
    }
  }

  function showVideo(cmd) {
    var v = document.createElement('video');
    v.className = 'fit';
    v.autoplay = true;
    v.loop = !!cmd.loop;
    v.muted = !!cmd.muted;
    v.volume = typeof cmd.volume === 'number' ? Math.max(0, Math.min(1, cmd.volume)) : 1;
    v.playsInline = true;
    v.addEventListener('loadedmetadata', function () {
      if (cmd.start_ms && cmd.start_ms > 0) { v.currentTime = cmd.start_ms / 1000; }
    });
    v.addEventListener('ended', function () { if (!v.loop) emit({ type: 'ended' }); });
    v.addEventListener('error', function () {
      var code = v.error ? v.error.code : 0;
      emit({ type: 'error', message: 'This video cannot be played (codec/format not supported by WebView2, code ' + code + '). Re-encode to H.264/AAC MP4.' });
    });
    v.addEventListener('timeupdate', function () {
      var now = Date.now();
      if (now - lastTimeEmit < 500) return;
      lastTimeEmit = now;
      emit({ type: 'time', t: v.currentTime, d: isFinite(v.duration) ? v.duration : 0, paused: v.paused, muted: v.muted, volume: v.volume });
    });
    v.src = convert(cmd.path);
    stage.appendChild(v);
    videoEl = v;
    var p = v.play();
    if (p && p.catch) p.catch(function (e) { emit({ type: 'error', message: 'Playback could not start: ' + e }); });
  }

  // ---------------- bundled, offline PPTX renderer ----------------
  async function startPptx(cmd) {
    var canvas = document.createElement('canvas');
    canvas.setAttribute('aria-label', 'Presentation slide');
    stage.appendChild(canvas);
    pptCanvas = canvas;
    pptLoop = !!cmd.loop;
    try {
      emit({ type: 'pptx_loading', message: 'Loading presentation…' });
      var response = await fetch(convert(cmd.path));
      if (!response.ok) throw new Error('Could not read presentation file (' + response.status + ').');
      var bytes = await response.arrayBuffer();
      pptRenderer = new PptxRenderer();
      await pptRenderer.load(bytes, function (progress, message) {
        emit({ type: 'pptx_progress', progress: progress, message: message || 'Loading presentation…' });
      });
      pptCount = pptRenderer.slideCount;
      if (!pptCount) throw new Error('This PPTX file contains no readable slides.');
      pptIndex = 0;
      await renderPptxSlide();
      emit({ type: 'pptx_ready', position: 1, count: pptCount });
    } catch (e) {
      emit({ type: 'error', message: 'ShowFlow could not render this PPTX: ' + (e && e.message ? e.message : e) });
    }
  }

  async function renderPptxSlide() {
    if (!pptRenderer || !pptCanvas) return;
    var width = Math.max(640, Math.floor(stage.clientWidth || window.innerWidth || 1280));
    await pptRenderer.renderSlide(pptIndex, pptCanvas, width);
    pptRenderWidth = width;
    emit({ type: 'slide_changed', position: pptIndex + 1, count: pptCount, preview: pptCanvas.toDataURL('image/jpeg', 0.72) });
  }

  async function controlPptx(cmd) {
    if (!pptRenderer) return;
    var action = cmd.action;
    if (action === 'pause') { pptPaused = true; emit({ type: 'pptx_paused', paused: true }); return; }
    if (action === 'play') { pptPaused = false; emit({ type: 'pptx_paused', paused: false }); return; }
    var next = pptIndex;
    if (action === 'next') next++;
    else if (action === 'prev') next--;
    else if (action === 'first') next = 0;
    else if (action === 'last') next = pptCount - 1;
    else return;
    if (next >= pptCount) {
      if (pptLoop) next = 0;
      else { emit({ type: 'ended' }); return; }
    }
    next = Math.max(0, Math.min(pptCount - 1, next));
    if (next === pptIndex) return;
    pptIndex = next;
    try { await renderPptxSlide(); }
    catch (e) { emit({ type: 'error', message: 'Slide rendering failed: ' + e }); }
  }

  window.addEventListener('resize', function () {
    if (pptRenderer && pptCanvas) {
      clearTimeout(window.__pptResizeTimer);
      window.__pptResizeTimer = setTimeout(function () { renderPptxSlide().catch(function () {}); }, 180);
    }
  });

  function control(cmd) {
    if (!videoEl) return;
    var v = videoEl;
    switch (cmd.action) {
      case 'pause': v.pause(); break;
      case 'play': v.play(); break;
      case 'seek': v.currentTime = Math.max(0, cmd.value || 0); break;
      case 'volume': v.volume = Math.max(0, Math.min(1, cmd.value == null ? 1 : cmd.value)); break;
      case 'mute': v.muted = true; break;
      case 'unmute': v.muted = false; break;
      case 'restart': v.currentTime = 0; v.play(); break;
    }
    emit({ type: 'time', t: v.currentTime, d: isFinite(v.duration) ? v.duration : 0, paused: v.paused, muted: v.muted, volume: v.volume });
  }

  // ---------------- speaker share (WebRTC receiver) ----------------
  function startShare(cmd) {
    share.conn = cmd;
    share.active = true;
    var v = document.createElement('video');
    v.className = 'fit';
    v.autoplay = true;
    v.playsInline = true;
    stage.appendChild(v);
    videoEl = null;
    share.video = v;
    connectShareWs();
  }

  function connectShareWs() {
    if (!share.active) return;
    var ws = new WebSocket(share.conn.ws_url);
    share.ws = ws;
    ws.onopen = function () { ws.send(JSON.stringify({ type: 'hello', role: 'audience', token: share.conn.token })); };
    ws.onmessage = function (ev) { onShareMsg(JSON.parse(ev.data)); };
    ws.onclose = function () {
      if (share.active) { share.retry = setTimeout(connectShareWs, 1500); }
    };
  }

  function sendShare(obj) { if (share.ws && share.ws.readyState === 1) share.ws.send(JSON.stringify(obj)); }

  async function onShareMsg(m) {
    if (m.type === 'event' && m.event === 'speaker_disconnected') {
      emit({ type: 'share_ended' });
      return;
    }
    if (m.type !== 'signal' || m.channel !== 'audience') return;
    var d = m.data || {};
    try {
      if (d.kind === 'offer') {
        if (share.pc) { try { share.pc.close(); } catch (e) {} }
        var pc = new RTCPeerConnection({ iceServers: [] });
        share.pc = pc;
        pc.ontrack = function (e) {
          if (share.video) { share.video.srcObject = e.streams[0]; share.video.play().catch(function () {}); }
        };
        pc.onicecandidate = function (e) {
          if (e.candidate) sendShare({ type: 'signal', to: 'speaker', channel: 'audience', data: { kind: 'candidate', candidate: e.candidate } });
        };
        await pc.setRemoteDescription(d.sdp);
        var ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        sendShare({ type: 'signal', to: 'speaker', channel: 'audience', data: { kind: 'answer', sdp: pc.localDescription } });
      } else if (d.kind === 'candidate' && share.pc && d.candidate) {
        await share.pc.addIceCandidate(d.candidate);
      }
    } catch (e) {
      emit({ type: 'error', message: 'Screen share failed: ' + e });
    }
  }

  function closeShare() {
    share.active = false;
    if (share.retry) { clearTimeout(share.retry); share.retry = null; }
    if (share.pc) { try { share.pc.close(); } catch (e) {} share.pc = null; }
    if (share.ws) { try { share.ws.close(); } catch (e) {} share.ws = null; }
    share.video = null;
  }

  // ---------------- startup ----------------
  T.event.listen('audience_cmd', function (ev) { apply(ev.payload); });
  invoke('audience_ready').then(function (cmd) { if (cmd) apply(cmd); }).catch(function () {});
})();

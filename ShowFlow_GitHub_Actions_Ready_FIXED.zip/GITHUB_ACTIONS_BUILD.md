# ShowFlow GitHub Actions workflow

Replace the complete contents of `.github/workflows/unpack.yml` with the workflow in this file.

The workflow:
1. Checks out the repository.
2. Finds and extracts the ShowFlow source ZIP.
3. Exposes the extracted project directory as a step output.
4. Sets up Node.js and Rust on a Windows runner.
5. Runs Rust workspace tests.
6. Installs npm dependencies and builds the Tauri installer.
7. Verifies the NSIS `.exe` exists.
8. Uploads the installer as the `ShowFlow-Windows-Installer` artifact.

After pushing the change, open the successful workflow run. The run summary should show
`ShowFlow-Windows-Installer` under Artifacts. Download it and extract the artifact ZIP to
get `ShowFlow_1.0.0_x64-setup.exe`.

The earlier YAML file I provided was accidentally truncated after the toolchain check.
This file is the complete replacement. The prior Rust warnings were non-fatal; the missing
artifact was caused by the upload stage not being present in the supplied workflow file.

# ShowFlow GitHub Actions build

Use the included `.github/workflows/build.yml` in your repository.

1. Put `ShowFlow_GitHub_Actions_Ready_FIXED.zip` in the repository root.
2. Put this workflow at `.github/workflows/build.yml`.
3. Commit and push to `main` or `master`, or manually run the workflow.
4. Download the `ShowFlow-Windows-Installer` artifact from the successful Actions run.

This workflow exports the extracted project directory as a step output and uses that
output directly for all working directories and the artifact path. It also checks that
the installer path is non-empty and that an EXE exists before upload.

The reported Rust dead-code warnings are non-fatal. The actual failure was in the
artifact upload step, not Rust compilation or NSIS packaging. The supplied log shows
the installer was successfully created at 3.37 MiB.

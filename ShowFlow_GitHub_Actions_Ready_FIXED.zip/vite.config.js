import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const here = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  // Tauri loads bundled assets from the app resource protocol.
  // Relative asset URLs ensure JS/CSS work when packaged offline.
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      // Keep the primary Tauri entry named dist/index.html.
      // Tauri's frontendDist points to ../dist and expects index.html.
      input: {
        index: resolve(here, 'frontend/index.html'),
        audience: resolve(here, 'frontend/audience.html')
      }
    }
  },
  server: {
    strictPort: true,
    port: 1420
  }
});

import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const here = fileURLToPath(new URL('.', import.meta.url));
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: resolve(here, 'frontend/index.html'),
        audience: resolve(here, 'frontend/audience.html')
      }
    }
  },
  server: { strictPort: true, port: 1420 }
});

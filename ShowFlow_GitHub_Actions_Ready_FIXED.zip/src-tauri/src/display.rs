use serde::Serialize;
use tauri::{AppHandle, Manager, PhysicalPosition, PhysicalSize, WebviewWindow};

/// Must be identical for every WebView2 window of this app (they share one user-data folder).
#[cfg(windows)]
pub const BROWSER_ARGS: &str = "--autoplay-policy=no-user-gesture-required";

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct DisplayInfo {
    pub id: String,
    pub name: String,
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
    pub scale: f64,
    pub primary: bool,
}

#[derive(Debug, Clone)]
pub struct Bounds {
    pub x: i32,
    pub y: i32,
    pub w: u32,
    pub h: u32,
}

pub fn list_displays(app: &AppHandle) -> Vec<DisplayInfo> {
    let Some(win) = app.get_webview_window("main") else {
        return vec![];
    };
    let primary_pos = win
        .primary_monitor()
        .ok()
        .flatten()
        .map(|m| (m.position().x, m.position().y));
    let monitors = win.available_monitors().unwrap_or_default();
    monitors
        .iter()
        .enumerate()
        .map(|(i, m)| {
            let pos = m.position();
            let size = m.size();
            let name = m.name().map(|s| s.to_string()).unwrap_or_else(|| format!("Display {}", i + 1));
            DisplayInfo {
                id: format!("{}|{},{}", name, pos.x, pos.y),
                name,
                x: pos.x,
                y: pos.y,
                width: size.width,
                height: size.height,
                scale: m.scale_factor(),
                primary: Some((pos.x, pos.y)) == primary_pos,
            }
        })
        .collect()
}

/// Resolve where the audience output goes. Returns (bounds, background_mode).
/// When no secondary display is available (or the primary display was selected), the audience
/// output occupies the primary display full-screen but is deliberately kept behind the operator
/// window. This mirrors a single-monitor slideshow: playback continues while the operator UI
/// remains usable in front. When a secondary display is available, output is full-screen there.
pub fn resolve_audience(app: &AppHandle, selected: Option<&str>) -> (Bounds, bool) {
    let displays = list_displays(app);
    let chosen = selected
        .and_then(|id| displays.iter().find(|d| d.id == id))
        .or_else(|| displays.iter().find(|d| !d.primary));
    match chosen {
        Some(d) if !d.primary => (Bounds { x: d.x, y: d.y, w: d.width, h: d.height }, false),
        _ => {
            // Single-display fallback: use the full primary display as the slideshow surface.
            // The operator window is raised after the audience window, leaving the slideshow
            // alive underneath it instead of showing a small floating preview.
            let primary = displays.iter().find(|d| d.primary);
            match primary {
                Some(d) => (Bounds { x: d.x, y: d.y, w: d.width, h: d.height }, true),
                None => (Bounds { x: 0, y: 0, w: 1280, h: 720 }, true),
            }
        }
    }
}

fn place(w: &WebviewWindow, b: &Bounds, background_mode: bool) -> Result<(), String> {
    w.set_title(if background_mode {
        "ShowFlow Audience Output (single-display background mode)"
    } else {
        "ShowFlow Audience Output"
    })
    .map_err(|e| e.to_string())?;

    // Always create a real full-screen presentation surface. In single-display mode it is
    // intentionally not topmost; the admin window is focused after it is shown, so PPTX/video
    // playback continues in this window behind the operator controls.
    w.set_fullscreen(false).map_err(|e| e.to_string())?;
    w.set_decorations(false).map_err(|e| e.to_string())?;
    w.set_position(PhysicalPosition::new(b.x, b.y)).map_err(|e| e.to_string())?;
    w.set_size(PhysicalSize::new(b.w, b.h)).map_err(|e| e.to_string())?;
    w.set_always_on_top(!background_mode).map_err(|e| e.to_string())?;
    w.show().map_err(|e| e.to_string())?;
    w.set_fullscreen(true).map_err(|e| e.to_string())?;

    if background_mode {
        // Keep the admin/operator UI accessible and in front of the full-screen audience surface.
        if let Some(operator) = w.app_handle().get_webview_window("main") {
            let _ = operator.show();
            let _ = operator.set_focus();
        }
    }
    Ok(())
}

pub fn ensure_audience(app: &AppHandle, b: &Bounds, background_mode: bool) -> Result<(), String> {
    if let Some(w) = app.get_webview_window("audience") {
        return place(&w, b, background_mode);
    }
    let builder = tauri::WebviewWindowBuilder::new(app, "audience", tauri::WebviewUrl::App("audience.html".into()))
        .title("ShowFlow Audience Output")
        .visible(false)
        .focused(false)
        .skip_taskbar(true);
    #[cfg(windows)]
    let builder = builder.additional_browser_args(BROWSER_ARGS);
    let w = builder.build().map_err(|e| format!("cannot create audience window: {e}"))?;
    place(&w, b, background_mode)
}


/// Re-apply the selected/automatic audience monitor bounds after a display topology change.
/// The operator window is intentionally left on the primary monitor; only the audience output
/// is resized to the projector's current physical pixel dimensions.
pub fn sync_audience(app: &AppHandle) -> Result<(), String> {
    let Some(_) = app.get_webview_window("audience") else {
        return Ok(());
    };
    let selected = app
        .try_state::<crate::state::AppState>()
        .and_then(|state| {
            crate::state::lk(&state.settings).audience_display.clone()
        });
    let (bounds, background_mode) = resolve_audience(app, selected.as_deref());
    ensure_audience(app, &bounds, background_mode)
}

pub fn close_audience(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("audience") {
        let _ = w.close();
    }
}

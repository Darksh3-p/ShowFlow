#[allow(dead_code)]
fn hide_window(cmd: &mut std::process::Command) {
    #[cfg(windows)] { use std::os::windows::process::CommandExt; cmd.creation_flags(0x0800_0000); }
    #[cfg(not(windows))] { let _ = cmd; }
}
use std::path::Path;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use serde_json::Value;


const SCRIPT: &str = include_str!("../scripts/hotspot.ps1");

fn run_with_timeout(mut cmd: Command, secs: u64) -> Result<String, String> {
    cmd.stdout(Stdio::piped()).stderr(Stdio::null()).stdin(Stdio::null());
    hide_window(&mut cmd);
    let mut child = cmd.spawn().map_err(|e| format!("cannot start PowerShell: {e}"))?;
    let mut stdout = child.stdout.take().ok_or("no stdout")?;
    let deadline = Instant::now() + Duration::from_secs(secs);
    loop {
        match child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) => {
                if Instant::now() > deadline {
                    let _ = child.kill();
                    return Err("The hotspot request timed out.".into());
                }
                std::thread::sleep(Duration::from_millis(100));
            }
            Err(e) => return Err(e.to_string()),
        }
    }
    let mut out = String::new();
    use std::io::Read;
    stdout.read_to_string(&mut out).map_err(|e| e.to_string())?;
    Ok(out)
}

/// action: "status" | "start" | "stop"
pub fn run(data_dir: &Path, action: &str) -> Result<Value, String> {
    if !matches!(action, "status" | "start" | "stop") {
        return Err("invalid hotspot action".into());
    }
    let script = data_dir.join("hotspot.ps1");
    std::fs::write(&script, SCRIPT).map_err(|e| e.to_string())?;
    let mut cmd = Command::new("powershell.exe");
    cmd.args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"])
        .arg(&script)
        .args(["-Action", action]);
    let out = run_with_timeout(cmd, 45)?;
    let line = out
        .lines()
        .map(|l| l.trim().trim_start_matches('\u{feff}'))
        .find(|l| l.starts_with('{'))
        .unwrap_or("");
    serde_json::from_str(line).map_err(|_| "Unexpected reply from the hotspot helper.".to_string())
}

pub fn open_settings() -> Result<(), String> {
    let mut cmd = Command::new("cmd");
    cmd.args(["/C", "start", "", "ms-settings:network-mobilehotspot"]);
    hide_window(&mut cmd);
    cmd.spawn().map(|_| ()).map_err(|e| e.to_string())
}

/// Adds a Windows Firewall rule for the speaker-share port (UAC prompt; private profile only).
pub fn add_firewall_rule(port: u16) -> Result<(), String> {
    let ps = format!(
        "Start-Process -FilePath netsh -ArgumentList 'advfirewall firewall add rule name=ShowFlow-SpeakerShare dir=in action=allow protocol=TCP localport={port} profile=private' -Verb RunAs"
    );
    let mut cmd = Command::new("powershell.exe");
    cmd.args(["-NoProfile", "-NonInteractive", "-Command", &ps]);
    hide_window(&mut cmd);
    cmd.spawn().map(|_| ()).map_err(|e| e.to_string())
}

pub fn open_path(path: &Path) -> Result<(), String> {
    Command::new("explorer.exe")
        .arg(path)
        .spawn()
        .map(|_| ())
        .map_err(|e| e.to_string())
}

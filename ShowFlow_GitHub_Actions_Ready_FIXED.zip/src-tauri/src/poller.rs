//! Background watcher for display hot-plug and automatic idle output.
use std::time::Duration;
use showflow_core::models::IdleMode;
use showflow_core::output::{OutputSource, PlaybackState};
use tauri::{AppHandle, Emitter, Manager};
use crate::display;
use crate::orchestrator;
use crate::state::{lk, AppState};

pub fn start(app: AppHandle) {
    std::thread::spawn(move || {
        let mut tick: u64 = 0;
        let mut last_displays = display::list_displays(&app);
        loop {
            std::thread::sleep(Duration::from_millis(600));
            tick += 1;
            if tick % 4 == 0 {
                let displays = display::list_displays(&app);
                if displays != last_displays {
                    last_displays = displays;
                    if let Err(e) = display::sync_audience(&app) {
                        tracing::warn!("audience display refresh failed: {e}");
                    }
                    let _ = app.emit("displays_changed", &last_displays);
                }
            }
            if tick % 16 == 0 { auto_idle(&app); }
        }
    });
}

fn auto_idle(app: &AppHandle) {
    let st = app.state::<AppState>();
    let cfg = lk(&st.idle).clone();
    let Some(mins) = cfg.auto_after_minutes else {
        return;
    };
    if mins == 0 || cfg.mode == IdleMode::None {
        return;
    }
    let elapsed = match *lk(&st.last_activity) {
        Some(t) => t.elapsed(),
        None => return, // never auto-project before the operator has started something
    };
    let eligible = {
        let o = lk(&st.output);
        let s = o.state();
        s.source == OutputSource::None || s.playback == PlaybackState::Completed
    };
    if eligible && elapsed >= Duration::from_secs(mins as u64 * 60) {
        tracing::info!("automatic idle screen after {mins} min of inactivity");
        if let Err(e) = orchestrator::activate_idle(app) {
            tracing::warn!("automatic idle failed: {e}");
        }
    }
}

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod commands;
mod display;
mod hotspot;
mod logging;
mod orchestrator;
mod poller;
mod state;

use tauri::{Listener, Manager};

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            let data_dir = app.path().app_data_dir()?;
            std::fs::create_dir_all(&data_dir)?;
            let guard = logging::init(&data_dir.join("logs"));
            tracing::info!("ShowFlow {} starting", env!("CARGO_PKG_VERSION"));
            let st = state::AppState::new(data_dir, guard)?;
            app.manage(st);

            poller::start(app.handle().clone());

            let handle = app.handle().clone();
            app.listen("audience_event", move |ev| {
                orchestrator::on_audience_event(&handle, ev.payload());
            });
            Ok(())
        })
        .on_window_event(|window, event| {
            if window.label() == "main" {
                if let tauri::WindowEvent::CloseRequested { .. } = event {
                    let app = window.app_handle();
                    orchestrator::shutdown(app);
                    app.exit(0);
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            commands::scan_folder,
            commands::get_folder,
            commands::search_media,
            commands::set_media_duration,
            commands::relink_media,
            commands::list_playlists,
            commands::create_playlist,
            commands::rename_playlist,
            commands::duplicate_playlist,
            commands::delete_playlist,
            commands::get_playlist_entries,
            commands::add_items,
            commands::remove_item,
            commands::clear_playlist,
            commands::move_item,
            commands::duplicate_item,
            commands::update_item_options,
            commands::get_settings,
            commands::update_settings,
            commands::get_idle,
            commands::set_idle,
            commands::list_displays,
            commands::select_display,
            commands::test_output,
            commands::audience_ready,
            commands::get_output_state,
            commands::start_playlist,
            commands::go_live_item,
            commands::next_item,
            commands::prev_item,
            commands::return_to_playlist,
            commands::slide_control,
            commands::video_control,
            commands::black_screen,
            commands::activate_idle,
            commands::stop_all,
            commands::ppt_detect,
            commands::sharing_interfaces,
            commands::sharing_start,
            commands::sharing_stop,
            commands::sharing_status,
            commands::sharing_info,
            commands::sharing_new_code,
            commands::sharing_admin_conn,
            commands::route_share,
            commands::firewall_help,
            commands::add_firewall_rule,
            commands::hotspot_control,
            commands::open_hotspot_settings,
            commands::open_logs_folder,
            commands::get_diagnostics,
        ])
        .run(tauri::generate_context!())
        .expect("error while running ShowFlow");
}

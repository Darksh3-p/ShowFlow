use std::path::PathBuf;
use std::sync::{Mutex, MutexGuard};
use std::time::Instant;

use showflow_core::models::{IdleConfig, MediaFile, PlaylistEntry, Settings};
use showflow_core::output::OutputController;
use showflow_core::storage::Database;
use showflow_sharing::SharingServer;
use tracing_appender::non_blocking::WorkerGuard;


/// Lock a std mutex, recovering from poisoning (a panicked thread must not brick the show).
pub fn lk<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|p| p.into_inner())
}

#[derive(Default)]
pub struct FolderIndex {
    pub root: Option<String>,
    pub files: Vec<MediaFile>,
}

#[derive(Default)]
pub struct LiveContext {
    pub playlist_id: Option<i64>,
    pub entries: Vec<PlaylistEntry>,
    pub index: Option<usize>,
    /// Incremented on every output switch; stale audience events are ignored.
    pub generation: u64,
}

pub struct AppState {
    pub data_dir: PathBuf,
    pub db: Mutex<Database>,
    pub settings: Mutex<Settings>,
    pub idle: Mutex<IdleConfig>,
    pub folder: Mutex<FolderIndex>,
    pub output: Mutex<OutputController>,
    pub live: Mutex<LiveContext>,
    pub sharing: tokio::sync::Mutex<Option<SharingServer>>,
    /// Serialises output transitions (one switch at a time).
    pub switch_lock: Mutex<()>,
    pub last_audience_cmd: Mutex<Option<serde_json::Value>>,
    /// Set once the operator has used the output this session (gates automatic idle).
    pub last_activity: Mutex<Option<Instant>>,
    pub log_guard: Mutex<Option<WorkerGuard>>,
}

impl AppState {
    pub fn new(data_dir: PathBuf, guard: Option<WorkerGuard>) -> Result<Self, String> {
        let db = Database::open(&data_dir.join("showflow.db")).map_err(|e| format!("database: {e}"))?;
        let settings = db.load_settings().map_err(|e| e.to_string())?;
        let idle = db.load_idle().map_err(|e| e.to_string())?;
        Ok(AppState {
            data_dir,
            db: Mutex::new(db),
            settings: Mutex::new(settings),
            idle: Mutex::new(idle),
            folder: Mutex::new(FolderIndex::default()),
            output: Mutex::new(OutputController::new()),
            live: Mutex::new(LiveContext::default()),
            sharing: tokio::sync::Mutex::new(None),
            switch_lock: Mutex::new(()),
            last_audience_cmd: Mutex::new(None),
            last_activity: Mutex::new(None),
            log_guard: Mutex::new(guard),
        })
    }
}

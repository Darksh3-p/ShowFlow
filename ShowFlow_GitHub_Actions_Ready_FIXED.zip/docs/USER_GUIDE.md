# ShowFlow quick guide

**Before the event:** Media Library → choose the folder → add files to a playlist → Display Manager → pick the projector → *Test output* → Idle Screen Studio (optional).

**During the event:** select an item → **Go Live**. **Next/Previous** step through the playlist. For PowerPoint use the slide buttons (or ← →). For video use Play/Pause, the seek bar and volume. **Black Screen** blanks the projector instantly; **Idle Screen** shows your idle content; **Stop All** (confirms) returns to black and ends any speaker share.

**Speaker screen share:** Wireless Share → pick adapter → Start. Speaker scans the QR code, accepts the certificate warning, enters the 6-digit code and presses Start sharing. Review the preview, then **Accept & Show**. **Stop sharing** returns to the playlist item that was live.

**Keyboard** (remappable in Settings): Space pause · ← → slides · Ctrl+← → items · Enter go live · B black · Esc stop all.

**If something goes wrong:** Settings → Diagnostics (copy the text) and Open logs folder. Problems with sharing are usually Wi-Fi client isolation or the firewall — use the hotspot or a dedicated router and the "Add firewall rule" button.

### Single-display presentation mode

When ShowFlow cannot detect a secondary monitor, it creates a full-screen audience output on the primary display and places the administrator window in front of it. The audience output remains alive behind the admin window, so PPTX slide rendering and video playback can continue while the operator uses ShowFlow. Minimizing or moving the admin window away reveals the full-screen audience output. When a secondary monitor is connected, the display watcher relocates the audience output to that monitor and uses its detected pixel dimensions.

# Acceptance status (from WINDOWS_ACCEPTANCE_TESTS.md)

Legend: **Impl** = code exists for it, **Untested** = nothing has been run. No row is claimed as passed.

| Area | Item | Status |
|---|---|---|
| A | Clean build with documented commands | Untested (not yet compiled) |
| A | Installer (NSIS) | Configured, untested |
| A | Bundled PPTX renderer with no Office/WPS dependency | Integrated in source; npm/Windows build not run; offline font fallback still requires verification |
| A | Built-in renderer status check | Impl (`ppt_detect`, Settings → Check PPTX renderer) — Untested |
| A | Logs local, no secrets | Impl — Untested |
| B | Folder scan, search, type filters | Impl, unit-tested logic (not run) |
| B | Add one / selected / all filtered | Impl |
| B | Reorder, remove, duplicate, rename, duplicate playlist, reload | Impl (storage unit tests written, not run) |
| B | Files never modified | Impl (only read / opened read-only) |
| B | Missing-file warning and relink | Impl |
| C | Bundled PPTX canvas on projector, slide controls, playlist end policy | Integrated in source — npm/Windows build and hardware validation pending |
| C | Renderer load/error handling | Impl — untested |
| D | Video play/pause/seek/volume/mute/loop/auto-advance | Impl — Untested |
| D | Image fit/fill/timed advance | Impl — Untested |
| D | PPTX→video→PPT without desktop flash | Impl (audience window is reused) — Untested |
| E | Display detection, operator stays on admin screen | Impl — needs hardware |
| E | Single-display simulation clearly labelled | Impl (window title + banner) |
| F | QR + pairing URL, HTTPS, preview, accept/reject/stop, no auto-projection | Impl — needs two PCs |
| G | Hotspot start/stop/status with honest errors | Impl — needs supported adapter |
| H | Black, idle video/PPT/image, auto-idle policy, return to playlist | Impl — Untested |
| I | Restart restores playlists/settings; no auto-project on launch | Impl — Untested |
| I | 60-minute soak | Not run |

### Single-display presentation mode

When ShowFlow cannot detect a secondary monitor, it creates a full-screen audience output on the primary display and places the administrator window in front of it. The audience output remains alive behind the admin window, so PPTX slide rendering and video playback can continue while the operator uses ShowFlow. Minimizing or moving the admin window away reveals the full-screen audience output. When a secondary monitor is connected, the display watcher relocates the audience output to that monitor and uses its detected pixel dimensions.

# ShowFlow standalone PPTX renderer

ShowFlow now uses the bundled `pptx-browser` JavaScript renderer inside its Tauri/WebView2 audience window. It reads `.pptx` OOXML files locally, renders slides to a canvas, and does not automate Microsoft PowerPoint or WPS Office. The renderer dependency is included in the Vite production bundle and therefore ships with the ShowFlow installer after `npm install` and `npm run build`.

## Runtime flow

1. Rust orchestration opens the audience window on the selected secondary display.
2. Rust sends the local PPTX path to the audience window using the `audience_cmd` event.
3. The audience window reads the file through Tauri's asset URL and passes its bytes to `PptxRenderer`.
4. The renderer draws the current slide to a canvas sized to the audience viewport.
5. The audience window emits slide position/count and a compressed preview data URL to the admin window.
6. Next/previous/first/last commands are handled by the renderer in the audience window. The final Next emits `ended` so playlist policy remains controlled by Rust.

## Supported baseline

The selected renderer documents support for text, wrapping, alignment, common preset/custom shapes, images and image fills, tables, gradients, shadows, theme colors, master/layout inheritance, rotation and groups. It documents charts and SmartArt as placeholder boxes. Complex animations, transitions, embedded media, OLE objects, and full Office font parity must not be assumed. This is an independent renderer, not a Microsoft PowerPoint implementation.

## Offline and packaging

The renderer's JavaScript is bundled locally by Vite. PPTX file parsing and drawing happen on the PC. The renderer's documented font substitution may request Google Fonts; to guarantee full offline operation, package approved font files locally and configure substitutions to local fonts before release. Current code does not intentionally fetch presentation files or slides to a server.

## Build

```powershell
npm install
npm run build
```

The generated NSIS installer contains the compiled frontend and renderer bundle. A clean Windows test machine must be used to verify installation and playback without Office/WPS. WebView2 Runtime remains a Windows platform prerequisite for Tauri 2; it is not an Office dependency.

## Known limitations / validation gates

- `pptx-browser` is an independent renderer; it does not promise pixel-identical PowerPoint output.
- The current renderer API supports `.pptx`; legacy `.ppt` files must be converted to `.pptx` before playback.
- The documented renderer marks charts and SmartArt as placeholders.
- Advanced animation, transitions, embedded video/audio, equations, and OLE/ActiveX require dedicated implementation or fallback behavior.
- The current environment did not install npm dependencies or run a Windows build. Run the acceptance suite on Windows with representative decks before calling the feature production-ready.

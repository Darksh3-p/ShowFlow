use std::path::Path;
use std::time::UNIX_EPOCH;

use walkdir::WalkDir;

use crate::error::{CoreError, Result};
use crate::models::{MediaFile, MediaType, TypeFilter};

pub const PRESENTATION_EXT: &[&str] = &["pptx"];
pub const VIDEO_EXT: &[&str] = &["mp4", "m4v", "mov", "webm", "mkv", "avi", "wmv"];
pub const IMAGE_EXT: &[&str] = &["jpg", "jpeg", "png", "gif", "bmp", "webp"];

#[derive(Debug, Clone)]
pub struct ScannedFile {
    pub path: String,
    pub filename: String,
    pub media_type: MediaType,
    pub size_bytes: i64,
    pub modified_at: i64,
}

pub fn media_type_for(path: &Path) -> Option<MediaType> {
    let ext = path.extension()?.to_str()?.to_ascii_lowercase();
    if PRESENTATION_EXT.contains(&ext.as_str()) {
        Some(MediaType::Presentation)
    } else if VIDEO_EXT.contains(&ext.as_str()) {
        Some(MediaType::Video)
    } else if IMAGE_EXT.contains(&ext.as_str()) {
        Some(MediaType::Image)
    } else {
        None
    }
}

/// Scan `root`. `depth` = number of sub-folder levels below the root (0 = root only, 1 = immediate children...).
/// Skips hidden files and Office lock files (`~$name.pptx`).
pub fn scan_folder(root: &Path, depth: u32) -> Result<Vec<ScannedFile>> {
    if !root.is_dir() {
        return Err(CoreError::Invalid(format!("not a folder: {}", root.display())));
    }
    let mut out = Vec::new();
    for entry in WalkDir::new(root)
        .max_depth(depth as usize + 1)
        .follow_links(false)
        .into_iter()
        .filter_map(|e| e.ok())
    {
        if !entry.file_type().is_file() {
            continue;
        }
        let name = entry.file_name().to_string_lossy().to_string();
        if name.starts_with("~$") || name.starts_with('.') {
            continue;
        }
        let Some(media_type) = media_type_for(entry.path()) else {
            continue;
        };
        let meta = match entry.metadata() {
            Ok(m) => m,
            Err(_) => continue,
        };
        let modified_at = meta
            .modified()
            .ok()
            .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0);
        out.push(ScannedFile {
            path: entry.path().to_string_lossy().to_string(),
            filename: name,
            media_type,
            size_bytes: meta.len() as i64,
            modified_at,
        });
    }
    out.sort_by(|a, b| a.filename.to_lowercase().cmp(&b.filename.to_lowercase()));
    Ok(out)
}

fn type_matches(t: MediaType, f: TypeFilter) -> bool {
    match f {
        TypeFilter::All => true,
        TypeFilter::Presentations => t == MediaType::Presentation,
        TypeFilter::Videos => t == MediaType::Video,
        TypeFilter::Images => t == MediaType::Image,
    }
}

/// Case-insensitive search. Every whitespace-separated token must appear in the file name.
pub fn search(files: &[MediaFile], query: &str, filter: TypeFilter) -> Vec<MediaFile> {
    let tokens: Vec<String> = query
        .split_whitespace()
        .map(|t| t.to_lowercase())
        .collect();
    files
        .iter()
        .filter(|f| type_matches(f.media_type, filter))
        .filter(|f| {
            let name = f.filename.to_lowercase();
            tokens.iter().all(|t| name.contains(t))
        })
        .cloned()
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    fn mf(id: i64, name: &str, t: MediaType) -> MediaFile {
        MediaFile {
            id,
            path: format!("C:\\x\\{name}"),
            filename: name.to_string(),
            media_type: t,
            size_bytes: 1,
            duration_ms: None,
            modified_at: 0,
            folder_root: "C:\\x".into(),
            available: true,
        }
    }

    #[test]
    fn detects_types() {
        assert_eq!(media_type_for(Path::new("a.PPTX")), Some(MediaType::Presentation));
        assert_eq!(media_type_for(Path::new("a.mp4")), Some(MediaType::Video));
        assert_eq!(media_type_for(Path::new("a.JPG")), Some(MediaType::Image));
        assert_eq!(media_type_for(Path::new("a.txt")), None);
        assert_eq!(media_type_for(Path::new("noext")), None);
    }

    #[test]
    fn search_is_case_insensitive_and_multi_token() {
        let files = vec![
            mf(1, "Welcome Slide.pptx", MediaType::Presentation),
            mf(2, "Product Demo.mp4", MediaType::Video),
            mf(3, "Product Photo.png", MediaType::Image),
        ];
        assert_eq!(search(&files, "PRODUCT", TypeFilter::All).len(), 2);
        assert_eq!(search(&files, "product demo", TypeFilter::All).len(), 1);
        assert_eq!(search(&files, "product", TypeFilter::Videos).len(), 1);
        assert_eq!(search(&files, "", TypeFilter::Images).len(), 1);
        assert_eq!(search(&files, "zzz", TypeFilter::All).len(), 0);
    }

    #[test]
    fn scan_respects_depth_and_skips_lock_files() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path();
        fs::write(root.join("a.pptx"), b"x").unwrap();
        fs::write(root.join("~$a.pptx"), b"x").unwrap();
        fs::write(root.join("notes.txt"), b"x").unwrap();
        fs::create_dir(root.join("sub")).unwrap();
        fs::write(root.join("sub").join("b.mp4"), b"x").unwrap();
        fs::create_dir_all(root.join("sub").join("deep")).unwrap();
        fs::write(root.join("sub").join("deep").join("c.png"), b"x").unwrap();

        let d0 = scan_folder(root, 0).unwrap();
        assert_eq!(d0.len(), 1);
        let d1 = scan_folder(root, 1).unwrap();
        assert_eq!(d1.len(), 2);
        let d2 = scan_folder(root, 2).unwrap();
        assert_eq!(d2.len(), 3);
    }
}

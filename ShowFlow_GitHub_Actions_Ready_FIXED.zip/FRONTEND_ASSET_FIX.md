# Fix for `asset not found: index.html`

Root cause: Vite's multi-page build input used the key `main` for
`frontend/index.html`. Vite uses the input key as the emitted HTML filename,
so this can emit `dist/main.html`, while Tauri's `frontendDist: ../dist`
expects `dist/index.html`.

The Vite input key is now `index`, so the primary page is emitted as
`dist/index.html`. The secondary presentation page remains `dist/audience.html`.

The existing Tauri configuration is retained:
- `beforeBuildCommand`: `npm run build:frontend`
- `frontendDist`: `../dist`

The GitHub workflow should run `npm run build` from the extracted ShowFlow
project directory. Tauri then runs the frontend build hook before bundling.

Validation after building on Windows:
1. Confirm `dist/index.html` and `dist/audience.html` exist after `npm run build:frontend`.
2. Run `npm run build`.
3. Install the generated NSIS installer on a clean Windows machine and launch ShowFlow.
4. Confirm the main window loads and the audience window route loads when presentation starts.

# ShowFlow v1.0 — source code

Windows event-presentation controller: standalone PPTX / video / image playlists on a projector,
black screen, idle screen, and wireless speaker screen sharing over the local network.

**Stack:** Rust + Tauri 2 (WebView2) · Vite + JavaScript front end · bundled `pptx-browser` renderer · SQLite · Axum signaling hub · PowerShell helper for Windows hotspot integration.

> **Build status — please read.** This source was written without access to a Rust toolchain or Windows,
> so it has **not been compiled or run**. Only the JavaScript syntax, JSON and TOML files were machine-checked.
> Expect to fix a small number of compile errors on first build (see `docs/KNOWN_RISKS.md`).
> Nothing in `docs/ACCEPTANCE_STATUS.md` is marked as passed.

## Prerequisites (Windows 10/11, 64-bit)
1. Rust (stable, MSVC toolchain): https://rustup.rs
2. Visual Studio Build Tools with "Desktop development with C++"
3. WebView2 runtime (preinstalled on Windows 11; the installer bootstraps it on Windows 10)
4. Node.js 18+ and npm (to bundle the renderer and run the Tauri CLI).
5. No Microsoft PowerPoint or WPS Office installation is required for `.pptx` playback. The bundled renderer supports `.pptx`; legacy `.ppt` files are not supported by the standalone renderer.

## Build and run
```powershell
npm install                 # installs the Tauri CLI
npm run dev                 # run in development
npm run build               # produces an NSIS installer in target\release\bundle\nsis\
```
Or use `scripts\build.ps1`. Portable-logic tests (work without Windows UI):
```powershell
cargo test -p showflow-core -p showflow-sharing
```
`cargo test -p showflow-core` also runs on Linux/macOS.

## First run
1. **Media Library → Choose folder** (PPTX, MP4/MOV/WebM, JPG/PNG...). Use the **Search files...** box and type filters.
2. Add files to a playlist (the Event/Playlist selector in the top bar). Drag rows to reorder.
3. **Display Manager**: connect the projector as an *extended* display. ShowFlow automatically selects the first non-primary display when no saved selection is available. While the app is running, it polls for monitor changes and repositions/resizes the audience output to the selected projector's current physical pixel resolution. With one display, output runs in a clearly-labelled 960×540 simulation window.
4. Select an item → **Go Live**. Next/Previous move through the playlist; slide controls operate the bundled PPTX renderer.
5. **Wireless Share**: pick the network adapter → *Start speaker sharing* → speaker scans the QR code, accepts the browser certificate warning, enters the pairing code, presses *Start sharing*. You see a preview; nothing reaches the projector until **Accept & Show**.

Nothing is ever projected automatically after launch. Automatic idle only starts after you have used the output in the current session.

**Offline note:** PPTX bytes and renderer code are processed locally. The selected renderer may request online font substitutes when a presentation uses fonts unavailable on the PC; for strict air-gapped deployment, package and configure local font substitutes before release.

## Layout
```
crates/showflow-core      media scan/search, playlists, SQLite storage, output state machine (unit-tested)
crates/showflow-sharing   HTTPS speaker page + WebSocket signaling hub, self-signed cert, QR, adapter discovery
src-tauri                 Tauri app: commands, display handling, orchestrator, hotspot helper
src-tauri/scripts         hotspot.ps1 (Windows Mobile Hotspot)
frontend                  operator UI (index.html, app.js, share.js) and audience output page (audience.html/js), bundled by Vite
docs                      architecture notes, risks, acceptance status, user guide
```

## Design decisions (and where they differ from the kit's suggestions)
| Topic | Choice | Why |
|---|---|---|
| Front end | Vanilla JavaScript with Vite bundling | Keeps the UI framework-free while bundling the offline PPTX renderer into the installer. |
| PPTX renderer | Bundled `pptx-browser` in the local Vite frontend; parses `.pptx` in the audience WebView and draws to canvas | No Office/WPS COM automation or separate presentation application. Renderer limitations are documented in `docs/STANDALONE_PPTX_ENGINE.md`. |
| Video/images | HTML5 `<video>`/`<img>` in a dedicated audience WebView2 window | No libVLC licensing/packaging. Trade-off: codec support is whatever WebView2 supports (H.264/AAC MP4 is safe; MKV/AVI/WMV may fail with a clear error). |
| Screen share | Browser-to-WebView2 WebRTC; Rust only relays signaling | No native WebRTC stack to build. The speaker's stream goes to the operator window (preview) and, after acceptance, to the audience window as a second peer connection. |
| TLS | Self-signed certificate (`rcgen`), persisted per host IP | Browsers require a secure context for screen capture. The speaker clicks through a one-time warning; nothing is installed on their machine. |
| Hotspot | WinRT `NetworkOperatorTetheringManager` via PowerShell | Honest errors when Windows cannot start a hotspot (e.g. no connection profile to share). |


## Current modification notes (2026-11-26)

- Added automatic monitor-topology polling while ShowFlow is running. When a monitor is connected, disconnected, moved, or its reported resolution changes, the audience window is re-resolved and resized to the selected/automatic secondary display.
- The admin/operator window remains on the primary monitor; it is not forced to the projector's resolution. The audience output window is the one that matches the projector.
- **Standalone PPTX renderer is integrated but not yet validated in a Windows build.** It is bundled by Vite and does not automate Office/WPS. Charts and SmartArt are documented placeholders; advanced effects and legacy `.ppt` files are outside the current support baseline. See `docs/STANDALONE_PPTX_ENGINE.md`.

### Single-display presentation mode

When ShowFlow cannot detect a secondary monitor, it creates a full-screen audience output on the primary display and places the administrator window in front of it. The audience output remains alive behind the admin window, so PPTX slide rendering and video playback can continue while the operator uses ShowFlow. Minimizing or moving the admin window away reveals the full-screen audience output. When a secondary monitor is connected, the display watcher relocates the audience output to that monitor and uses its detected pixel dimensions.

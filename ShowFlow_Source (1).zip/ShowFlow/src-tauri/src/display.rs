use serde::Serialize;
use tauri::{AppHandle, Manager, PhysicalPosition, PhysicalSize, WebviewWindow};

/// Must be identical for every WebView2 window of this app (they share one user-data folder).
#[cfg(windows)]
pub const BROWSER_ARGS: &str = "--autoplay-policy=no-user-gesture-required";

#[derive(Debug, Clone, Serialize)]
pub struct DisplayInfo {
    pub id: String,
    pub name: String,
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
    pub scale: f64,
    pub primary: bool,
}

#[derive(Debug, Clone)]
pub struct Bounds {
    pub x: i32,
    pub y: i32,
    pub w: u32,
    pub h: u32,
}

pub fn list_displays(app: &AppHandle) -> Vec<DisplayInfo> {
    let Some(win) = app.get_webview_window("main") else {
        return vec![];
    };
    let primary_pos = win
        .primary_monitor()
        .ok()
        .flatten()
        .map(|m| (m.position().x, m.position().y));
    let monitors = win.available_monitors().unwrap_or_default();
    monitors
        .iter()
        .enumerate()
        .map(|(i, m)| {
            let pos = m.position();
            let size = m.size();
            let name = m.name().map(|s| s.to_string()).unwrap_or_else(|| format!("Display {}", i + 1));
            DisplayInfo {
                id: format!("{}|{},{}", name, pos.x, pos.y),
                name,
                x: pos.x,
                y: pos.y,
                width: size.width,
                height: size.height,
                scale: m.scale_factor(),
                primary: Some((pos.x, pos.y)) == primary_pos,
            }
        })
        .collect()
}

/// Resolve where the audience output goes. Returns (bounds, simulated).
/// With a single display (or when the chosen display is the operator's primary), output is a
/// window shaped like the main screen (about 960 px wide) so the operator UI stays usable: "simulation mode".
pub fn resolve_audience(app: &AppHandle, selected: Option<&str>) -> (Bounds, bool) {
    let displays = list_displays(app);
    let chosen = selected
        .and_then(|id| displays.iter().find(|d| d.id == id))
        .or_else(|| displays.iter().find(|d| !d.primary));
    match chosen {
        Some(d) if !d.primary => (Bounds { x: d.x, y: d.y, w: d.width, h: d.height }, false),
        _ => {
            // Single display: a windowed simulation with the same shape (aspect ratio) as the main screen.
            let prim = displays.iter().find(|d| d.primary).or_else(|| displays.first());
            let (px, py, pw, ph) = prim
                .map(|d| (d.x, d.y, d.width, d.height))
                .unwrap_or((0, 0, 1920, 1080));
            let pw = pw.max(1);
            let ph = ph.max(1);
            let mut w: u32 = 960u32.min(pw.max(320));
            let mut h: u32 = (w as u64 * ph as u64 / pw as u64) as u32;
            let max_h = (ph as u64 * 8 / 10) as u32;
            if max_h > 0 && h > max_h {
                h = max_h;
                w = (h as u64 * pw as u64 / ph as u64) as u32;
            }
            (Bounds { x: px + 80, y: py + 80, w, h }, true)
        }
    }
}

fn place(w: &WebviewWindow, b: &Bounds, simulated: bool) -> Result<(), String> {
    w.set_title(if simulated {
        "ShowFlow Audience Output (SIMULATION - connect a second display)"
    } else {
        "ShowFlow Audience Output"
    })
    .map_err(|e| e.to_string())?;
    w.set_fullscreen(false).map_err(|e| e.to_string())?;
    w.set_decorations(simulated).map_err(|e| e.to_string())?;
    w.set_position(PhysicalPosition::new(b.x, b.y)).map_err(|e| e.to_string())?;
    w.set_size(PhysicalSize::new(b.w, b.h)).map_err(|e| e.to_string())?;
    w.set_always_on_top(!simulated).map_err(|e| e.to_string())?;
    w.show().map_err(|e| e.to_string())?;
    if !simulated {
        // Position first so fullscreen lands on the intended monitor.
        w.set_fullscreen(true).map_err(|e| e.to_string())?;
    }
    Ok(())
}

pub fn ensure_audience(app: &AppHandle, b: &Bounds, simulated: bool) -> Result<(), String> {
    if let Some(w) = app.get_webview_window("audience") {
        return place(&w, b, simulated);
    }
    let builder = tauri::WebviewWindowBuilder::new(app, "audience", tauri::WebviewUrl::App("audience.html".into()))
        .title("ShowFlow Audience Output")
        .visible(false)
        .focused(false)
        .skip_taskbar(!simulated);
    #[cfg(windows)]
    let builder = builder.additional_browser_args(BROWSER_ARGS);
    let w = builder.build().map_err(|e| format!("cannot create audience window: {e}"))?;
    place(&w, b, simulated)
}

pub fn close_audience(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("audience") {
        let _ = w.close();
    }
}

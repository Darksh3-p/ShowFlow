# ShowFlow v1.0 — source code

Windows event-presentation controller: PowerPoint / video / image playlists on a projector,
black screen, idle screen, and wireless speaker screen sharing over the local network.

**Stack:** Rust + Tauri 2 (WebView2) · vanilla JavaScript front end (no npm build step) · SQLite · Axum signaling hub · PowerShell helper for PowerPoint COM.

> **Build status — please read.** This source was written without access to a Rust toolchain or Windows,
> so it has **not been compiled or run**. Only the JavaScript syntax, JSON and TOML files were machine-checked.
> Expect to fix a small number of compile errors on first build (see `docs/KNOWN_RISKS.md`).
> Nothing in `docs/ACCEPTANCE_STATUS.md` is marked as passed.

## Prerequisites (Windows 10/11, 64-bit)
1. Rust (stable, MSVC toolchain): https://rustup.rs
2. Visual Studio Build Tools with "Desktop development with C++"
3. WebView2 runtime (preinstalled on Windows 11; the installer bootstraps it on Windows 10)
4. Node.js 18+ (only to run the Tauri CLI) — or `cargo install tauri-cli --version "^2"`
5. Microsoft PowerPoint (desktop) — **optional**. Without it ShowFlow plays `.pptx`/`.ppsx` files with its built-in viewer (see below)

## Build and run
```powershell
npm install                 # installs the Tauri CLI
npm run dev                 # run in development
npm run build               # produces an NSIS installer in target\release\bundle\nsis\
```
Or use `scripts\build.ps1`. Portable-logic tests (work without Windows UI):
```powershell
cargo test -p showflow-core -p showflow-sharing
```
`cargo test -p showflow-core` also runs on Linux/macOS.

## First run
1. **Media Library → Choose folder** (PPTX/PPT, MP4/MOV/WebM, JPG/PNG...). Use the **Search files...** box and type filters.
2. Add files to a playlist (the Event/Playlist selector in the top bar). Drag rows to reorder.
3. **Display Manager**: connect the projector as an *extended* display and pick it. With one display, output runs in a clearly-labelled 960×540 simulation window.
4. Select an item → **Go Live**. Next/Previous move through the playlist; slide controls appear for PowerPoint.
5. **Wireless Share**: pick the network adapter → *Start speaker sharing* → speaker scans the QR code, accepts the browser certificate warning, enters the pairing code, presses *Start sharing*. You see a preview; nothing reaches the projector until **Accept & Show**.

Nothing is ever projected automatically after launch. Automatic idle only starts after you have used the output in the current session.

## Layout
```
crates/showflow-core      media scan/search, playlists, SQLite storage, output state machine (unit-tested)
crates/showflow-sharing   HTTPS speaker page + WebSocket signaling hub, self-signed cert, QR, adapter discovery
src-tauri                 Tauri app: commands, display handling, PowerPoint helper, orchestrator, hotspot helper
src-tauri/scripts         ppt_host.ps1 (PowerPoint COM), hotspot.ps1 (Windows Mobile Hotspot)
frontend                  operator UI (index.html, app.js, share.js) and audience output page (audience.html/js)
docs                      architecture notes, risks, acceptance status, user guide
```

## Design decisions (and where they differ from the kit's suggestions)
| Topic | Choice | Why |
|---|---|---|
| Front end | Vanilla JS, no bundler | Removes an entire class of build failures; easy to audit. The kit recommends TS/React but does not require it. |
| PowerPoint engine | **Built-in viewer when PowerPoint is not installed** (`frontend/pptx.js`, runs in the audience window); otherwise the isolated `powershell.exe -STA` helper process using COM automation, JSON lines over stdio | No COM on the UI thread; a hung helper is killed and restarted; avoids `windows-rs` COM boilerplate. Opens presentations read-only and closes only its own. |
| Video/images | HTML5 `<video>`/`<img>` in a dedicated audience WebView2 window | No libVLC licensing/packaging. Trade-off: codec support is whatever WebView2 supports (H.264/AAC MP4 is safe; MKV/AVI/WMV may fail with a clear error). |
| Screen share | Browser-to-WebView2 WebRTC; Rust only relays signaling | No native WebRTC stack to build. The speaker's stream goes to the operator window (preview) and, after acceptance, to the audience window as a second peer connection. |
| TLS | Self-signed certificate (`rcgen`), persisted per host IP | Browsers require a secure context for screen capture. The speaker clicks through a one-time warning; nothing is installed on their machine. |
| Hotspot | WinRT `NetworkOperatorTetheringManager` via PowerShell | Honest errors when Windows cannot start a hotspot (e.g. no connection profile to share). |

## Built-in presentation viewer (no PowerPoint needed)
If Microsoft PowerPoint is not installed, ShowFlow draws `.pptx` / `.ppsx` slides itself on the second monitor
(`frontend/pptx.js`, no external libraries). Slide controls, playlists, idle-screen loops and keyboard shortcuts work the same.
* **Supported:** text (placeholders, bullets, autofit), shapes, pictures with cropping, groups, lines, tables, basic charts
  (bar/column, line, area, pie, doughnut), SmartArt (its stored drawing), slide masters/layouts, backgrounds, hidden slides are skipped.
* **Not supported:** animations, slide transitions, embedded video/audio, OLE objects, shadows/3-D, exotic fonts that are not installed.
  Old binary `.ppt`/`.pps` files must be saved as `.pptx` first. Always check important decks in the output preview before the event.
* To force an engine (for testing), set the environment variable `SHOWFLOW_PPT_ENGINE` to `builtin` or `powerpoint`.

## Output preview shape
The Live Output Preview on the dashboard is locked to the shape (aspect ratio) of the screen the audience output uses - the chosen
second display, or the main screen when there is only one display (then the output runs in a window of the same shape, so the
operator UI stays usable). Slides, videos and images letterbox in the preview exactly as they will on that screen.


(function () {
  'use strict';
  var T = window.__TAURI__;
  var invoke = T.core.invoke;
  var convert = T.core.convertFileSrc;
  var stage = document.getElementById('stage');
  var token = 0;
  var videoEl = null;
  var lastTimeEmit = 0;
  var imageTimer = null;
  var share = { ws: null, pc: null, conn: null, active: false, retry: null };
  var pp = { deck: null, idx: 0, loop: false, host: null };   // built-in PowerPoint viewer state

  function emit(payload) {
    payload.token = token;
    try { T.event.emit('audience_event', payload); } catch (e) {}
  }

  function clearStage() {
    if (imageTimer) { clearTimeout(imageTimer); imageTimer = null; }
    closeShare();
    if (videoEl) { try { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); } catch (e) {} videoEl = null; }
    if (pp.deck) { try { pp.deck.dispose(); } catch (e) {} }
    pp.deck = null; pp.host = null;
    stage.innerHTML = '';
  }

  function apply(cmd) {
    if (!cmd || !cmd.kind) return;
    if (cmd.kind === 'control') return control(cmd);
    token = cmd.token || token;
    clearStage();
    switch (cmd.kind) {
      case 'black': break;
      case 'test': showTest(cmd); break;
      case 'video': showVideo(cmd); break;
      case 'image': showImage(cmd); break;
      case 'share': startShare(cmd); break;
      case 'pptx': showPptx(cmd); break;
    }
  }

  function showTest(cmd) {
    var d = document.createElement('div');
    d.className = 'test';
    d.innerHTML = '<span>ShowFlow output test<br>' + (cmd.label || '') + '</span>';
    stage.appendChild(d);
  }

  function showImage(cmd) {
    var img = document.createElement('img');
    img.className = cmd.fit === 'fill' ? 'fill' : 'fit';
    img.onerror = function () { emit({ type: 'error', message: 'Image failed to load' }); };
    img.src = convert(cmd.path);
    stage.appendChild(img);
    if (cmd.advance_after_secs) {
      var t = token;
      imageTimer = setTimeout(function () { token = t; emit({ type: 'ended' }); }, cmd.advance_after_secs * 1000);
    }
  }

  function showVideo(cmd) {
    var v = document.createElement('video');
    v.className = 'fit';
    v.autoplay = true;
    v.loop = !!cmd.loop;
    v.muted = !!cmd.muted;
    v.volume = typeof cmd.volume === 'number' ? Math.max(0, Math.min(1, cmd.volume)) : 1;
    v.playsInline = true;
    v.addEventListener('loadedmetadata', function () {
      if (cmd.start_ms && cmd.start_ms > 0) { v.currentTime = cmd.start_ms / 1000; }
    });
    v.addEventListener('ended', function () { if (!v.loop) emit({ type: 'ended' }); });
    v.addEventListener('error', function () {
      var code = v.error ? v.error.code : 0;
      emit({ type: 'error', message: 'This video cannot be played (codec/format not supported by WebView2, code ' + code + '). Re-encode to H.264/AAC MP4.' });
    });
    v.addEventListener('timeupdate', function () {
      var now = Date.now();
      if (now - lastTimeEmit < 500) return;
      lastTimeEmit = now;
      emit({ type: 'time', t: v.currentTime, d: isFinite(v.duration) ? v.duration : 0, paused: v.paused, muted: v.muted, volume: v.volume });
    });
    v.src = convert(cmd.path);
    stage.appendChild(v);
    videoEl = v;
    var p = v.play();
    if (p && p.catch) p.catch(function (e) { emit({ type: 'error', message: 'Playback could not start: ' + e }); });
  }

  function control(cmd) {
    if (pp.deck) return pptxControl(cmd);
    if (!videoEl) return;
    var v = videoEl;
    switch (cmd.action) {
      case 'pause': v.pause(); break;
      case 'play': v.play(); break;
      case 'seek': v.currentTime = Math.max(0, cmd.value || 0); break;
      case 'volume': v.volume = Math.max(0, Math.min(1, cmd.value == null ? 1 : cmd.value)); break;
      case 'mute': v.muted = true; break;
      case 'unmute': v.muted = false; break;
      case 'restart': v.currentTime = 0; v.play(); break;
    }
    emit({ type: 'time', t: v.currentTime, d: isFinite(v.duration) ? v.duration : 0, paused: v.paused, muted: v.muted, volume: v.volume });
  }

  // ---------------- built-in PowerPoint viewer (used when PowerPoint is not installed) ----------------
  function showPptx(cmd) {
    var t = token;
    var host = document.createElement('div');
    host.className = 'pptx';
    stage.appendChild(host);
    pp.host = host;
    pp.loop = !!cmd.loop;
    if (!window.ShowFlowPptx) { emit({ type: 'error', message: 'Built-in presentation viewer is missing (pptx.js not loaded).' }); return; }
    window.ShowFlowPptx.load(convert(cmd.path)).then(function (deck) {
      if (t !== token || pp.host !== host) { deck.dispose(); return; }
      pp.deck = deck;
      pp.idx = 0;
      return gotoSlide(0);
    }).catch(function (e) {
      if (t === token) { token = t; emit({ type: 'error', message: 'Cannot display this presentation: ' + (e && e.message ? e.message : e) }); }
    });
  }

  function gotoSlide(i) {
    var deck = pp.deck, host = pp.host;
    if (!deck || !host) return Promise.resolve();
    var t = token;
    i = Math.max(0, Math.min(deck.count - 1, i));
    pp.idx = i;
    return window.ShowFlowPptx.show(host, deck, i).then(function () {
      if (t === token) emit({ type: 'slide', position: i + 1, count: deck.count });
    }).catch(function (e) {
      if (t === token) emit({ type: 'error', message: 'Slide ' + (i + 1) + ' could not be drawn: ' + (e && e.message ? e.message : e) });
    });
  }

  function pptxControl(cmd) {
    var deck = pp.deck;
    if (!deck) return;
    switch (cmd.action) {
      case 'next':
        if (pp.idx + 1 < deck.count) gotoSlide(pp.idx + 1);
        else if (pp.loop) gotoSlide(0);
        else emit({ type: 'ended' });
        break;
      case 'prev': gotoSlide(pp.idx - 1); break;
      case 'first': gotoSlide(0); break;
      case 'last': gotoSlide(deck.count - 1); break;
    }
  }

  // ---------------- speaker share (WebRTC receiver) ----------------
  function startShare(cmd) {
    share.conn = cmd;
    share.active = true;
    var v = document.createElement('video');
    v.className = 'fit';
    v.autoplay = true;
    v.playsInline = true;
    stage.appendChild(v);
    videoEl = null;
    share.video = v;
    connectShareWs();
  }

  function connectShareWs() {
    if (!share.active) return;
    var ws = new WebSocket(share.conn.ws_url);
    share.ws = ws;
    ws.onopen = function () { ws.send(JSON.stringify({ type: 'hello', role: 'audience', token: share.conn.token })); };
    ws.onmessage = function (ev) { onShareMsg(JSON.parse(ev.data)); };
    ws.onclose = function () {
      if (share.active) { share.retry = setTimeout(connectShareWs, 1500); }
    };
  }

  function sendShare(obj) { if (share.ws && share.ws.readyState === 1) share.ws.send(JSON.stringify(obj)); }

  async function onShareMsg(m) {
    if (m.type === 'event' && m.event === 'speaker_disconnected') {
      emit({ type: 'share_ended' });
      return;
    }
    if (m.type !== 'signal' || m.channel !== 'audience') return;
    var d = m.data || {};
    try {
      if (d.kind === 'offer') {
        if (share.pc) { try { share.pc.close(); } catch (e) {} }
        var pc = new RTCPeerConnection({ iceServers: [] });
        share.pc = pc;
        pc.ontrack = function (e) {
          if (share.video) { share.video.srcObject = e.streams[0]; share.video.play().catch(function () {}); }
        };
        pc.onicecandidate = function (e) {
          if (e.candidate) sendShare({ type: 'signal', to: 'speaker', channel: 'audience', data: { kind: 'candidate', candidate: e.candidate } });
        };
        await pc.setRemoteDescription(d.sdp);
        var ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        sendShare({ type: 'signal', to: 'speaker', channel: 'audience', data: { kind: 'answer', sdp: pc.localDescription } });
      } else if (d.kind === 'candidate' && share.pc && d.candidate) {
        await share.pc.addIceCandidate(d.candidate);
      }
    } catch (e) {
      emit({ type: 'error', message: 'Screen share failed: ' + e });
    }
  }

  function closeShare() {
    share.active = false;
    if (share.retry) { clearTimeout(share.retry); share.retry = null; }
    if (share.pc) { try { share.pc.close(); } catch (e) {} share.pc = null; }
    if (share.ws) { try { share.ws.close(); } catch (e) {} share.ws = null; }
    share.video = null;
  }

  // ---------------- startup ----------------
  T.event.listen('audience_cmd', function (ev) { apply(ev.payload); });
  invoke('audience_ready').then(function (cmd) { if (cmd) apply(cmd); }).catch(function () {});
})();

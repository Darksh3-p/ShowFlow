# Build ShowFlow with GitHub Actions

1. Upload `ShowFlow_GitHub_Actions_Ready.zip` to the root of your GitHub repository.
2. Create `.github/workflows/build.yml` in the repository and paste the included `build.yml` content.
3. Commit and push to `main` or `master`, or open Actions and run **Build ShowFlow Windows Installer** manually.
4. Wait for the workflow to finish.
5. Open the successful workflow run and download the `ShowFlow-Windows-Installer` artifact.

The workflow extracts the ShowFlow project from the ZIP, installs Node.js and Rust on
GitHub's Windows runner, runs the Rust workspace tests, installs npm dependencies,
builds the Tauri NSIS installer, verifies that an `.exe` exists, and uploads it.

Notes:
- This workflow builds a Windows installer; it does not test actual projector/display behavior.
- The app still requires the Microsoft Edge WebView2 Runtime as a Tauri platform dependency.
- Microsoft PowerPoint and WPS Office are not required by the bundled PPTX renderer.
- The supplied source has no package-lock.json, so the workflow uses `npm install`.
- Build failures caused by Rust compilation or unsupported PPTX features must be fixed in source;
  GitHub Actions cannot automatically correct application code.

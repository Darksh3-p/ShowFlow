//! Output orchestration: every change of what the audience sees goes through `switch_to`,
//! which serialises transitions, stops the previous source and then starts the new one.
use std::path::Path;
use std::time::Instant;

use serde_json::{json, Value};
use showflow_core::models::*;
use showflow_core::output::{OutputSource, PlaybackState};
use showflow_core::playlist;
use tauri::{AppHandle, Emitter, Manager};

use crate::display::{self, Bounds};
use crate::state::{lk, AppState};

// ---------------------------------------------------------------- helpers

pub fn touch_activity(app: &AppHandle) {
    let st = app.state::<AppState>();
    *lk(&st.last_activity) = Some(Instant::now());
}

pub fn emit_state(app: &AppHandle) {
    let st = app.state::<AppState>();
    let out = lk(&st.output).state().clone();
    let (index, total, playlist_id) = {
        let l = lk(&st.live);
        (l.index, l.entries.len(), l.playlist_id)
    };
    let _ = app.emit(
        "output_state_changed",
        json!({ "state": out, "live_index": index, "live_total": total, "playlist_id": playlist_id }),
    );
}

/// Embedded-music preferences for the built-in presentation viewer.
fn music_cfg(app: &AppHandle) -> Value {
    let st = app.state::<AppState>();
    let s = lk(&st.settings);
    json!({ "enabled": s.music_enabled, "delay_s": s.music_delay_s, "loop": s.music_loop, "volume": s.music_volume })
}

/// Animation and slide-advance preferences for the built-in presentation viewer.
fn view_cfg(app: &AppHandle) -> Value {
    let st = app.state::<AppState>();
    let s = lk(&st.settings);
    json!({ "animations": s.animations_enabled, "advance": s.slide_advance, "advance_secs": s.slide_advance_secs })
}

/// Slide-transition preferences for the built-in presentation viewer.
fn transition_cfg(app: &AppHandle) -> Value {
    let st = app.state::<AppState>();
    let s = lk(&st.settings);
    json!({ "ms": s.transition_ms, "style": s.transition_style })
}

fn send_audience(app: &AppHandle, cmd: Value) {
    let st = app.state::<AppState>();
    *lk(&st.last_audience_cmd) = Some(cmd.clone());
    let _ = app.emit_to("audience", "audience_cmd", cmd);
}

fn bump_generation(app: &AppHandle) -> u64 {
    let st = app.state::<AppState>();
    let mut l = lk(&st.live);
    l.generation += 1;
    l.generation
}

/// True when the built-in .pptx viewer (not PowerPoint) is showing the current presentation.
fn is_builtin(app: &AppHandle) -> bool {
    let st = app.state::<AppState>();
    let b = lk(&st.ppt).builtin;
    b
}

fn set_builtin(app: &AppHandle, v: bool) {
    let st = app.state::<AppState>();
    lk(&st.ppt).builtin = v;
}

/// Use the built-in viewer when Microsoft PowerPoint is not installed.
fn want_builtin(app: &AppHandle) -> bool {
    let st = app.state::<AppState>();
    let installed = lk(&st.ppt).is_installed();
    !installed
}

fn target(app: &AppHandle) -> (Bounds, bool) {
    let st = app.state::<AppState>();
    let sel = lk(&st.settings).audience_display.clone();
    display::resolve_audience(app, sel.as_deref())
}

fn stop_source(app: &AppHandle, prev: OutputSource) {
    if matches!(prev, OutputSource::PowerPoint | OutputSource::IdlePowerPoint) {
        let st = app.state::<AppState>();
        let result = lk(&st.ppt).stop();
        if let Err(e) = result {
            tracing::warn!("stopping PowerPoint failed: {e}");
        }
    }
}

/// Serialised output transition. `body` performs the side effects for the new source.
fn switch_to<F>(app: &AppHandle, tgt: OutputSource, item_id: Option<i64>, body: F) -> Result<(), String>
where
    F: FnOnce(&AppHandle) -> Result<(), String>,
{
    let st = app.state::<AppState>();
    let _guard = lk(&st.switch_lock);
    let prev = lk(&st.output)
        .begin_switch(tgt, item_id)
        .map_err(|e| e.to_string())?;
    stop_source(app, prev);
    match body(app) {
        Ok(()) => {
            let _ = lk(&st.output).mark_live();
            touch_activity(app);
            emit_state(app);
            Ok(())
        }
        Err(e) => {
            tracing::error!("output switch to {:?} failed: {}", tgt, e);
            lk(&st.output).mark_error(e.clone());
            emit_state(app);
            Err(e)
        }
    }
}

// ---------------------------------------------------------------- playing items

pub fn play_entry(app: &AppHandle, entry: &PlaylistEntry) -> Result<(), String> {
    let m = &entry.media;
    if !Path::new(&m.path).exists() {
        let msg = format!("File is missing: {}", m.path);
        let st = app.state::<AppState>();
        lk(&st.output).mark_error(msg.clone());
        emit_state(app);
        return Err(msg);
    }
    let (b, sim) = target(app);
    let st = app.state::<AppState>();
    let settings = lk(&st.settings).clone();
    let item = entry.item.clone();
    let item_id = Some(item.id);
    let auto = item.auto_advance || settings.end_policy == EndPolicy::AutoAdvance;

    match m.media_type {
        MediaType::Presentation => switch_to(app, OutputSource::PowerPoint, item_id, |app| {
            display::ensure_audience(app, &b, sim)?;
            if want_builtin(app) {
                let token = bump_generation(app);
                set_builtin(app, true);
                send_audience(app, json!({ "kind": "pptx", "path": m.path, "loop": false, "token": token, "transition": transition_cfg(app), "view": view_cfg(app), "music": music_cfg(app) }));
                return Ok(());
            }
            set_builtin(app, false);
            send_audience(app, json!({ "kind": "black" }));
            bump_generation(app);
            let st = app.state::<AppState>();
            let count = lk(&st.ppt).open(&m.path, &b, false, !sim)?;
            let _ = app.emit("slide_changed", json!({ "position": 1, "count": count }));
            Ok(())
        }),
        MediaType::Video => switch_to(app, OutputSource::Video, item_id, |app| {
            display::ensure_audience(app, &b, sim)?;
            let token = bump_generation(app);
            send_audience(
                app,
                json!({
                    "kind": "video", "path": m.path, "loop": item.looped, "volume": item.volume,
                    "start_ms": item.start_position_ms, "token": token, "muted": false
                }),
            );
            Ok(())
        }),
        MediaType::Image => switch_to(app, OutputSource::Image, item_id, |app| {
            display::ensure_audience(app, &b, sim)?;
            let token = bump_generation(app);
            let advance: Option<i64> = if auto {
                Some(item.image_duration_secs.unwrap_or(settings.default_image_secs as i64))
            } else {
                None
            };
            let fit = if settings.image_fit == ImageFit::Fill { "fill" } else { "fit" };
            send_audience(
                app,
                json!({ "kind": "image", "path": m.path, "fit": fit, "advance_after_secs": advance, "token": token }),
            );
            Ok(())
        }),
    }
}

fn load_entries(app: &AppHandle, playlist_id: i64) -> Result<Vec<PlaylistEntry>, String> {
    let st = app.state::<AppState>();
    let entries = lk(&st.db).playlist_entries(playlist_id).map_err(|e| e.to_string())?;
    Ok(entries)
}

/// Go live with a specific playlist item (operator action).
pub fn go_live(app: &AppHandle, playlist_id: i64, item_id: Option<i64>) -> Result<(), String> {
    let entries = load_entries(app, playlist_id)?;
    if entries.is_empty() {
        return Err("This playlist is empty.".into());
    }
    let idx = match item_id {
        Some(id) => entries
            .iter()
            .position(|e| e.item.id == id)
            .ok_or("That item is not in the playlist.")?,
        None => 0,
    };
    let entry = entries[idx].clone();
    {
        let st = app.state::<AppState>();
        let mut l = lk(&st.live);
        l.playlist_id = Some(playlist_id);
        l.entries = entries;
        l.index = Some(idx);
        let mut s = lk(&st.settings);
        s.last_playlist_id = Some(playlist_id);
        let _ = lk(&st.db).save_settings(&s);
    }
    play_entry(app, &entry)
}

fn refresh_live(app: &AppHandle) {
    let st = app.state::<AppState>();
    let (pid, cur_item) = {
        let l = lk(&st.live);
        (
            l.playlist_id,
            l.index.and_then(|i| l.entries.get(i)).map(|e| e.item.id),
        )
    };
    if let Some(pid) = pid {
        if let Ok(entries) = load_entries(app, pid) {
            let mut l = lk(&st.live);
            l.index = cur_item.and_then(|id| entries.iter().position(|e| e.item.id == id));
            l.entries = entries;
        }
    }
}

/// delta = +1 next item, -1 previous item.
pub fn step_playlist(app: &AppHandle, delta: i64) -> Result<(), String> {
    refresh_live(app);
    let next = {
        let st = app.state::<AppState>();
        let l = lk(&st.live);
        if l.playlist_id.is_none() {
            return Err("No playlist is active. Start a playlist first.".into());
        }
        playlist::step(l.index, l.entries.len(), delta).map(|i| (i, l.entries[i].clone()))
    };
    match next {
        Some((i, entry)) => {
            {
                let st = app.state::<AppState>();
                lk(&st.live).index = Some(i);
            }
            play_entry(app, &entry)
        }
        None if delta > 0 => end_of_playlist(app),
        None => Ok(()),
    }
}

pub fn end_of_playlist(app: &AppHandle) -> Result<(), String> {
    let st = app.state::<AppState>();
    lk(&st.live).index = None;
    let policy = lk(&st.settings).after_stop;
    match policy {
        AfterStop::Idle => activate_idle(app),
        AfterStop::Black => black(app),
    }
}

/// Restart the playlist item that was live before idle/black/share took over.
pub fn return_to_playlist(app: &AppHandle) -> Result<(), String> {
    let (pid, item) = {
        let st = app.state::<AppState>();
        let l = lk(&st.live);
        (l.playlist_id, l.index.and_then(|i| l.entries.get(i)).map(|e| e.item.id))
    };
    match pid {
        Some(pid) => go_live(app, pid, item),
        None => Err("There is no playlist to return to.".into()),
    }
}

/// Called when the current item finished by itself (video ended, last slide done, image timer).
pub fn on_item_finished(app: &AppHandle) {
    let st = app.state::<AppState>();
    let finished_source = {
        let mut o = lk(&st.output);
        let src = o.state().source;
        if o.mark_completed().is_err() {
            return; // not live (already handled, paused, or switched)
        }
        src
    };
    let was_presentation = finished_source == OutputSource::PowerPoint;
    if was_presentation {
        // Close the presenter right away so nothing is left open behind the next item.
        let _g = lk(&st.switch_lock);
        stop_source(app, finished_source);
    }
    let (auto, has_next) = {
        let l = lk(&st.live);
        let item_auto = l
            .index
            .and_then(|i| l.entries.get(i))
            .map(|e| e.item.auto_advance)
            .unwrap_or(false);
        let has_next = l.index.map(|i| i + 1 < l.entries.len()).unwrap_or(false);
        (item_auto, has_next)
    };
    let policy = lk(&st.settings).end_policy;
    if auto || policy == EndPolicy::AutoAdvance || (was_presentation && has_next) {
        if let Err(e) = step_playlist(app, 1) {
            tracing::warn!("auto-advance failed: {e}");
        }
    } else {
        let _ = app.emit("playlist_waiting", json!({ "has_next": has_next }));
        emit_state(app);
    }
}

// ---------------------------------------------------------------- black / idle / share / stop

pub fn black(app: &AppHandle) -> Result<(), String> {
    switch_to(app, OutputSource::Black, None, |app| {
        let (b, sim) = target(app);
        display::ensure_audience(app, &b, sim)?;
        bump_generation(app);
        send_audience(app, json!({ "kind": "black" }));
        Ok(())
    })
}

pub fn activate_idle(app: &AppHandle) -> Result<(), String> {
    let st = app.state::<AppState>();
    let cfg = lk(&st.idle).clone();
    let (b, sim) = target(app);
    let need_path = |cfg: &IdleConfig| -> Result<String, String> {
        let p = cfg.path.clone().ok_or("No idle file is configured.")?;
        if !Path::new(&p).exists() {
            return Err(format!("Idle file is missing: {p}"));
        }
        Ok(p)
    };
    match cfg.mode {
        IdleMode::None => black(app),
        IdleMode::PowerPoint => {
            let p = need_path(&cfg)?;
            switch_to(app, OutputSource::IdlePowerPoint, None, |app| {
                display::ensure_audience(app, &b, sim)?;
                if want_builtin(app) {
                    let token = bump_generation(app);
                    set_builtin(app, true);
                    send_audience(app, json!({ "kind": "pptx", "path": p, "loop": true, "token": token, "transition": transition_cfg(app), "view": view_cfg(app) }));
                    return Ok(());
                }
                set_builtin(app, false);
                send_audience(app, json!({ "kind": "black" }));
                bump_generation(app);
                let st = app.state::<AppState>();
                let opened = lk(&st.ppt).open(&p, &b, true, !sim);
                opened.map(|_| ())
            })
        }
        IdleMode::Video => {
            let p = need_path(&cfg)?;
            switch_to(app, OutputSource::IdleVideo, None, |app| {
                display::ensure_audience(app, &b, sim)?;
                let token = bump_generation(app);
                send_audience(
                    app,
                    json!({ "kind": "video", "path": p, "loop": cfg.loop_video, "volume": 1.0,
                            "muted": cfg.muted, "token": token, "idle": true }),
                );
                Ok(())
            })
        }
        IdleMode::Image => {
            let p = need_path(&cfg)?;
            switch_to(app, OutputSource::IdleImage, None, |app| {
                display::ensure_audience(app, &b, sim)?;
                let token = bump_generation(app);
                send_audience(
                    app,
                    json!({ "kind": "image", "path": p, "fit": "fit", "advance_after_secs": null, "token": token }),
                );
                Ok(())
            })
        }
    }
}

/// Route the accepted speaker share to the projector. The audience page connects to the signaling hub itself.
pub fn show_share(app: &AppHandle, ws_url: String, token: String) -> Result<(), String> {
    switch_to(app, OutputSource::SpeakerShare, None, |app| {
        let (b, sim) = target(app);
        display::ensure_audience(app, &b, sim)?;
        bump_generation(app);
        send_audience(app, json!({ "kind": "share", "ws_url": ws_url, "token": token }));
        Ok(())
    })
}

pub fn stop_all(app: &AppHandle) -> Result<(), String> {
    {
        let st = app.state::<AppState>();
        lk(&st.live).index = None;
    }
    black(app)
}

// ---------------------------------------------------------------- transport

pub fn video_control(app: &AppHandle, action: &str, value: Option<f64>) -> Result<(), String> {
    let st = app.state::<AppState>();
    let src = lk(&st.output).state().source;
    match src {
        OutputSource::Video | OutputSource::IdleVideo => {
            match action {
                "pause" => {
                    let _ = lk(&st.output).mark_paused(true);
                }
                "play" => {
                    let _ = lk(&st.output).mark_paused(false);
                }
                "seek" | "volume" | "mute" | "unmute" | "restart" => {}
                _ => return Err(format!("unknown video action: {action}")),
            }
            let _ = app.emit_to("audience", "audience_cmd", json!({ "kind": "control", "action": action, "value": value }));
            emit_state(app);
            Ok(())
        }
        OutputSource::PowerPoint | OutputSource::IdlePowerPoint => {
            if is_builtin(app) {
                // The built-in viewer has no slide timings, so there is nothing to pause.
                return Ok(());
            }
            let r = match action {
                "pause" => lk(&st.ppt).simple("pause"),
                "play" => lk(&st.ppt).simple("resume"),
                _ => return Err("not supported for presentations".into()),
            };
            r?;
            let _ = lk(&st.output).mark_paused(action == "pause");
            emit_state(app);
            Ok(())
        }
        _ => Err("Nothing is playing that can be paused.".into()),
    }
}

/// action: next | prev | first | last
pub fn slide_control(app: &AppHandle, action: &str) -> Result<(), String> {
    let st = app.state::<AppState>();
    let src = lk(&st.output).state().source;
    if !matches!(src, OutputSource::PowerPoint | OutputSource::IdlePowerPoint) {
        return Err("PowerPoint is not live.".into());
    }
    if is_builtin(app) {
        return match action {
            "next" | "prev" | "first" | "last" => {
                let _ = app.emit_to("audience", "audience_cmd", json!({ "kind": "control", "action": action }));
                Ok(())
            }
            _ => Err(format!("unknown slide action: {action}")),
        };
    }
    let status = {
        let mut ppt = lk(&st.ppt);
        if action == "next" {
            let s = ppt.status()?;
            if s.running && s.count > 0 && s.position >= s.count && src == OutputSource::PowerPoint {
                drop(ppt);
                on_item_finished(app);
                return Ok(());
            }
        }
        let res = match action {
            "next" | "prev" | "first" | "last" => ppt.simple(action)?,
            _ => return Err(format!("unknown slide action: {action}")),
        };
        res
    };
    let _ = app.emit("slide_changed", json!({ "position": status.position, "count": status.count }));
    Ok(())
}

// ---------------------------------------------------------------- audience events

/// Audience page reports (ended / error / time ...). Runs on a worker thread.
pub fn on_audience_event(app: &AppHandle, payload: &str) {
    let Ok(v) = serde_json::from_str::<Value>(payload) else {
        return;
    };
    let ty = v.get("type").and_then(|t| t.as_str()).unwrap_or("").to_string();
    let token = v.get("token").and_then(|t| t.as_u64());
    let st = app.state::<AppState>();
    let current = lk(&st.live).generation;
    match ty.as_str() {
        "ended" if token == Some(current) => {
            let app2 = app.clone();
            std::thread::spawn(move || on_item_finished(&app2));
        }
        "slide" if token == Some(current) => {
            let position = v.get("position").and_then(|x| x.as_i64()).unwrap_or(0);
            let count = v.get("count").and_then(|x| x.as_i64()).unwrap_or(0);
            let _ = app.emit("slide_changed", json!({ "position": position, "count": count, "builtin": true }));
        }
        "error" if token == Some(current) => {
            let msg = v
                .get("message")
                .and_then(|m| m.as_str())
                .unwrap_or("Playback error")
                .to_string();
            tracing::error!("audience playback error: {msg}");
            lk(&st.output).mark_error(msg);
            emit_state(app);
        }
        _ => {}
    }
}

pub fn shutdown(app: &AppHandle) {
    let st = app.state::<AppState>();
    {
        let mut p = lk(&st.ppt);
        let _ = p.stop();
        p.shutdown();
    }
    display::close_audience(app);
}

pub fn is_presentation_live(app: &AppHandle) -> bool {
    let st = app.state::<AppState>();
    let o = lk(&st.output);
    let s = o.state();
    matches!(s.source, OutputSource::PowerPoint | OutputSource::IdlePowerPoint)
        && matches!(s.playback, PlaybackState::Live | PlaybackState::Paused)
}

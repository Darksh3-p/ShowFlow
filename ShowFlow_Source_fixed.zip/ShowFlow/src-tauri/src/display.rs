use serde::Serialize;
use tauri::{AppHandle, Manager, PhysicalPosition, PhysicalSize, WebviewWindow};

/// Must be identical for every WebView2 window of this app (they share one user-data folder).
#[cfg(windows)]
pub const BROWSER_ARGS: &str = "--autoplay-policy=no-user-gesture-required";

#[derive(Debug, Clone, Serialize)]
pub struct DisplayInfo {
    pub id: String,
    pub name: String,
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
    pub scale: f64,
    pub primary: bool,
}

#[derive(Debug, Clone)]
pub struct Bounds {
    pub x: i32,
    pub y: i32,
    pub w: u32,
    pub h: u32,
}

pub fn list_displays(app: &AppHandle) -> Vec<DisplayInfo> {
    let Some(win) = app.get_webview_window("main") else {
        return vec![];
    };
    let primary_pos = win
        .primary_monitor()
        .ok()
        .flatten()
        .map(|m| (m.position().x, m.position().y));
    let monitors = win.available_monitors().unwrap_or_default();
    monitors
        .iter()
        .enumerate()
        .map(|(i, m)| {
            let pos = m.position();
            let size = m.size();
            let name = m.name().map(|s| s.to_string()).unwrap_or_else(|| format!("Display {}", i + 1));
            DisplayInfo {
                id: format!("{}|{},{}", name, pos.x, pos.y),
                name,
                x: pos.x,
                y: pos.y,
                width: size.width,
                height: size.height,
                scale: m.scale_factor(),
                primary: Some((pos.x, pos.y)) == primary_pos,
            }
        })
        .collect()
}

/// Resolve where the audience output goes. Returns (bounds, single_display).
/// With a second display the output is fullscreen there. With only one display the output is fullscreen on
/// the main screen and the operator window is kept always-on-top above it.
pub fn resolve_audience(app: &AppHandle, selected: Option<&str>) -> (Bounds, bool) {
    let displays = list_displays(app);
    let chosen = selected
        .and_then(|id| displays.iter().find(|d| d.id == id))
        .or_else(|| displays.iter().find(|d| !d.primary));
    match chosen {
        Some(d) if !d.primary => (Bounds { x: d.x, y: d.y, w: d.width, h: d.height }, false),
        _ => {
            let prim = displays.iter().find(|d| d.primary).or_else(|| displays.first());
            let (px, py, pw, ph) = prim
                .map(|d| (d.x, d.y, d.width, d.height))
                .unwrap_or((0, 0, 1920, 1080));
            (Bounds { x: px, y: py, w: pw.max(1), h: ph.max(1) }, true)
        }
    }
}

fn place(app: &AppHandle, w: &WebviewWindow, b: &Bounds, single: bool) -> Result<(), String> {
    w.set_title("ShowFlow Audience Output").map_err(|e| e.to_string())?;
    w.set_fullscreen(false).map_err(|e| e.to_string())?;
    w.set_decorations(false).map_err(|e| e.to_string())?;
    w.set_position(PhysicalPosition::new(b.x, b.y)).map_err(|e| e.to_string())?;
    w.set_size(PhysicalSize::new(b.w, b.h)).map_err(|e| e.to_string())?;
    // Single display: the operator window must stay above the output, so the output is NOT topmost.
    w.set_always_on_top(!single).map_err(|e| e.to_string())?;
    w.show().map_err(|e| e.to_string())?;
    // Position first so fullscreen lands on the intended monitor.
    w.set_fullscreen(true).map_err(|e| e.to_string())?;
    if let Some(main) = app.get_webview_window("main") {
        let _ = main.set_always_on_top(single);
    }
    Ok(())
}

pub fn ensure_audience(app: &AppHandle, b: &Bounds, single: bool) -> Result<(), String> {
    if let Some(w) = app.get_webview_window("audience") {
        return place(app, &w, b, single);
    }
    let builder = tauri::WebviewWindowBuilder::new(app, "audience", tauri::WebviewUrl::App("audience.html".into()))
        .title("ShowFlow Audience Output")
        .visible(false)
        .focused(false)
        .skip_taskbar(true);
    #[cfg(windows)]
    let builder = builder.additional_browser_args(BROWSER_ARGS);
    let w = builder.build().map_err(|e| format!("cannot create audience window: {e}"))?;
    place(app, &w, b, single)
}

pub fn close_audience(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("audience") {
        let _ = w.close();
    }
    if let Some(main) = app.get_webview_window("main") {
        let _ = main.set_always_on_top(false);
    }
}

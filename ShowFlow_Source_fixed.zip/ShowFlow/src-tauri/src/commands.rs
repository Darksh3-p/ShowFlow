use std::net::IpAddr;
use std::path::PathBuf;

use serde::Serialize;
use serde_json::{json, Value};
use showflow_core::media;
use showflow_core::models::*;
use showflow_core::storage::Database;
use showflow_sharing::{NetInterface, ServerConfig, SharingInfo, SharingServer, SharingStatus};
use tauri::{AppHandle, Manager, State};

use crate::display::{self, DisplayInfo};
use crate::hotspot;
use crate::orchestrator as orch;
use crate::state::{lk, AppState};

type CmdResult<T> = Result<T, String>;

fn with_db<T>(
    st: &AppState,
    f: impl FnOnce(&mut Database) -> showflow_core::error::Result<T>,
) -> CmdResult<T> {
    let mut db = lk(&st.db);
    f(&mut db).map_err(|e| e.to_string())
}

// ================================================================ media library

#[derive(Serialize)]
pub struct FolderResult {
    pub root: Option<String>,
    pub files: Vec<MediaFile>,
}

#[tauri::command]
pub async fn scan_folder(state: State<'_, AppState>, path: String) -> CmdResult<FolderResult> {
    let root = PathBuf::from(&path);
    if !root.is_dir() {
        return Err(format!("Not a folder: {path}"));
    }
    let depth = lk(&state.settings).scan_depth;
    let r2 = root.clone();
    let scanned = tauri::async_runtime::spawn_blocking(move || media::scan_folder(&r2, depth))
        .await
        .map_err(|e| e.to_string())?
        .map_err(|e| e.to_string())?;
    let root_s = root.to_string_lossy().to_string();
    let files = with_db(&state, |db| db.upsert_scanned(&root_s, &scanned))?;
    {
        let mut f = lk(&state.folder);
        f.root = Some(root_s.clone());
        f.files = files.clone();
    }
    {
        let mut s = lk(&state.settings);
        s.last_folder = Some(root_s.clone());
        let _ = lk(&state.db).save_settings(&s);
    }
    Ok(FolderResult { root: Some(root_s), files })
}

#[tauri::command]
pub fn get_folder(state: State<'_, AppState>) -> FolderResult {
    let f = lk(&state.folder);
    // Refresh availability flags (files may have been removed since the scan).
    let files = f
        .files
        .iter()
        .cloned()
        .map(|mut m| {
            m.available = std::path::Path::new(&m.path).exists();
            m
        })
        .collect();
    FolderResult { root: f.root.clone(), files }
}

#[tauri::command]
pub fn search_media(state: State<'_, AppState>, query: String, filter: Option<TypeFilter>) -> Vec<MediaFile> {
    let f = lk(&state.folder);
    media::search(&f.files, &query, filter.unwrap_or_default())
}

#[tauri::command]
pub fn set_media_duration(state: State<'_, AppState>, id: i64, duration_ms: i64) -> CmdResult<()> {
    if duration_ms <= 0 {
        return Ok(());
    }
    with_db(&state, |db| db.set_duration(id, duration_ms))?;
    let mut f = lk(&state.folder);
    if let Some(m) = f.files.iter_mut().find(|m| m.id == id) {
        m.duration_ms = Some(duration_ms);
    }
    Ok(())
}

#[tauri::command]
pub fn relink_media(state: State<'_, AppState>, id: i64, new_path: String) -> CmdResult<MediaFile> {
    with_db(&state, |db| db.relink_media(id, &new_path))
}

// ================================================================ playlists

#[tauri::command]
pub fn list_playlists(state: State<'_, AppState>) -> CmdResult<Vec<Playlist>> {
    with_db(&state, |db| db.list_playlists())
}

#[tauri::command]
pub fn create_playlist(state: State<'_, AppState>, name: String) -> CmdResult<Playlist> {
    let root = lk(&state.folder).root.clone();
    with_db(&state, |db| db.create_playlist(&name, root.as_deref()))
}

#[tauri::command]
pub fn rename_playlist(state: State<'_, AppState>, id: i64, name: String) -> CmdResult<()> {
    with_db(&state, |db| db.rename_playlist(id, &name))
}

#[tauri::command]
pub fn duplicate_playlist(state: State<'_, AppState>, id: i64) -> CmdResult<Playlist> {
    with_db(&state, |db| db.duplicate_playlist(id))
}

#[tauri::command]
pub fn delete_playlist(state: State<'_, AppState>, id: i64) -> CmdResult<()> {
    with_db(&state, |db| db.delete_playlist(id))
}

#[tauri::command]
pub fn get_playlist_entries(state: State<'_, AppState>, playlist_id: i64) -> CmdResult<Vec<PlaylistEntry>> {
    with_db(&state, |db| db.playlist_entries(playlist_id))
}

#[tauri::command]
pub fn add_items(state: State<'_, AppState>, playlist_id: i64, media_ids: Vec<i64>) -> CmdResult<Vec<i64>> {
    with_db(&state, |db| db.add_items(playlist_id, &media_ids))
}

#[tauri::command]
pub fn remove_item(state: State<'_, AppState>, item_id: i64) -> CmdResult<()> {
    with_db(&state, |db| db.remove_item(item_id))
}

#[tauri::command]
pub fn clear_playlist(state: State<'_, AppState>, playlist_id: i64) -> CmdResult<()> {
    with_db(&state, |db| db.clear_playlist(playlist_id))
}

#[tauri::command]
pub fn move_item(state: State<'_, AppState>, item_id: i64, new_index: usize) -> CmdResult<()> {
    with_db(&state, |db| db.move_item(item_id, new_index))
}

#[tauri::command]
pub fn duplicate_item(state: State<'_, AppState>, item_id: i64) -> CmdResult<i64> {
    with_db(&state, |db| db.duplicate_item(item_id))
}

#[tauri::command]
pub fn update_item_options(state: State<'_, AppState>, item_id: i64, options: ItemOptions) -> CmdResult<()> {
    with_db(&state, |db| db.update_item_options(item_id, &options))
}

// ================================================================ settings / idle

#[tauri::command]
pub fn get_settings(state: State<'_, AppState>) -> Settings {
    lk(&state.settings).clone()
}

#[tauri::command]
pub fn update_settings(state: State<'_, AppState>, settings: Settings) -> CmdResult<Settings> {
    let mut s = settings;
    s.scan_depth = s.scan_depth.min(5);
    s.default_image_secs = s.default_image_secs.clamp(1, 3600);
    s.transition_ms = s.transition_ms.min(5000);
    s.music_delay_s = s.music_delay_s.min(600);
    s.music_volume = s.music_volume.min(100);
    s.slide_advance_secs = s.slide_advance_secs.clamp(1, 3600);
    if !matches!(s.slide_advance.as_str(), "file" | "off" | "custom") {
        s.slide_advance = "file".to_string();
    }
    if s.transition_style.trim().is_empty() || s.transition_style.len() > 24 || !s.transition_style.chars().all(|c| c.is_ascii_alphanumeric()) {
        s.transition_style = "file".to_string();
    }
    if s.share_port < 1024 {
        return Err("Choose a port of 1024 or higher.".into());
    }
    with_db(&state, |db| db.save_settings(&s))?;
    *lk(&state.settings) = s.clone();
    Ok(s)
}

#[tauri::command]
pub fn get_idle(state: State<'_, AppState>) -> IdleConfig {
    lk(&state.idle).clone()
}

#[tauri::command]
pub fn set_idle(state: State<'_, AppState>, config: IdleConfig) -> CmdResult<IdleConfig> {
    if config.mode != IdleMode::None {
        let p = config.path.clone().ok_or("Choose an idle file.")?;
        if !std::path::Path::new(&p).exists() {
            return Err(format!("File not found: {p}"));
        }
    }
    with_db(&state, |db| db.save_idle(&config))?;
    *lk(&state.idle) = config.clone();
    Ok(config)
}

// ================================================================ displays

#[tauri::command]
pub fn list_displays(app: AppHandle) -> Vec<DisplayInfo> {
    display::list_displays(&app)
}

#[tauri::command]
pub fn select_display(state: State<'_, AppState>, id: Option<String>) -> CmdResult<()> {
    let mut s = lk(&state.settings);
    s.audience_display = id;
    let r = lk(&state.db).save_settings(&s).map_err(|e| e.to_string());
    r
}

/// Shows a test pattern on the audience output. Refused while something is live.
#[tauri::command]
pub async fn test_output(app: AppHandle) -> CmdResult<()> {
    use showflow_core::output::{OutputSource, PlaybackState};
    {
        let st = app.state::<AppState>();
        let o = lk(&st.output);
        let s = o.state();
        let busy = !matches!(s.source, OutputSource::None | OutputSource::Black)
            && matches!(s.playback, PlaybackState::Live | PlaybackState::Paused | PlaybackState::Loading);
        if busy {
            return Err("Output is live. Use Black Screen first, then test.".into());
        }
    }
    orch::black(&app)?;
    let st = app.state::<AppState>();
    let sel = lk(&st.settings).audience_display.clone();
    let (b, sim) = display::resolve_audience(&app, sel.as_deref());
    let cmd = json!({ "kind": "test", "label": format!("{}x{} at {},{}{}", b.w, b.h, b.x, b.y, if sim { " (main screen)" } else { "" }) });
    *lk(&st.last_audience_cmd) = Some(cmd.clone());
    use tauri::Emitter;
    let _ = app.emit_to("audience", "audience_cmd", cmd);
    Ok(())
}

#[tauri::command]
pub fn audience_ready(state: State<'_, AppState>) -> Option<Value> {
    lk(&state.last_audience_cmd).clone()
}

// ================================================================ playback

#[derive(Serialize)]
pub struct OutputSnapshot {
    pub state: showflow_core::output::OutputState,
    pub live_index: Option<usize>,
    pub live_total: usize,
    pub playlist_id: Option<i64>,
}

#[tauri::command]
pub fn get_output_state(state: State<'_, AppState>) -> OutputSnapshot {
    let out = lk(&state.output).state().clone();
    let l = lk(&state.live);
    OutputSnapshot { state: out, live_index: l.index, live_total: l.entries.len(), playlist_id: l.playlist_id }
}

#[tauri::command]
pub async fn start_playlist(app: AppHandle, playlist_id: i64) -> CmdResult<()> {
    orch::go_live(&app, playlist_id, None)
}

#[tauri::command]
pub async fn go_live_item(app: AppHandle, playlist_id: i64, item_id: i64) -> CmdResult<()> {
    orch::go_live(&app, playlist_id, Some(item_id))
}

#[tauri::command]
pub async fn next_item(app: AppHandle) -> CmdResult<()> {
    orch::step_playlist(&app, 1)
}

#[tauri::command]
pub async fn prev_item(app: AppHandle) -> CmdResult<()> {
    orch::step_playlist(&app, -1)
}

#[tauri::command]
pub async fn return_to_playlist(app: AppHandle) -> CmdResult<()> {
    orch::return_to_playlist(&app)
}

#[tauri::command]
pub async fn slide_control(app: AppHandle, action: String) -> CmdResult<()> {
    orch::slide_control(&app, &action)
}

#[tauri::command]
pub async fn video_control(app: AppHandle, action: String, value: Option<f64>) -> CmdResult<()> {
    orch::video_control(&app, &action, value)
}

#[tauri::command]
pub async fn black_screen(app: AppHandle) -> CmdResult<()> {
    orch::black(&app)
}

#[tauri::command]
pub async fn activate_idle(app: AppHandle) -> CmdResult<()> {
    orch::activate_idle(&app)
}

#[tauri::command]
pub async fn stop_all(app: AppHandle) -> CmdResult<()> {
    orch::stop_all(&app)
}

// ================================================================ PowerPoint

#[tauri::command]
pub async fn ppt_detect(state: State<'_, AppState>) -> CmdResult<Value> {
    let r = lk(&state.ppt).detect();
    r
}

#[derive(Serialize)]
pub struct PptThumbs {
    pub position: i64,
    pub count: i64,
    pub current: Option<String>,
    pub next: Option<String>,
    /// True when the built-in viewer is active (thumbnails are drawn by the front end instead).
    pub builtin: bool,
}

#[tauri::command]
pub async fn ppt_thumbs(state: State<'_, AppState>) -> CmdResult<PptThumbs> {
    let mut p = lk(&state.ppt);
    if p.builtin {
        return Ok(PptThumbs { position: 0, count: 0, current: None, next: None, builtin: true });
    }
    let s = p.status()?;
    if !s.running {
        return Err("No slide show is running.".into());
    }
    let current = p.thumb(s.position, "cur").ok();
    let next = if s.position < s.count { p.thumb(s.position + 1, "next").ok() } else { None };
    Ok(PptThumbs { position: s.position, count: s.count, current, next, builtin: false })
}

// ================================================================ speaker sharing

#[tauri::command]
pub fn sharing_interfaces() -> Vec<NetInterface> {
    showflow_sharing::candidate_interfaces()
}

#[tauri::command]
pub async fn sharing_start(state: State<'_, AppState>, ip: String) -> CmdResult<SharingInfo> {
    let parsed: IpAddr = ip.parse().map_err(|_| "Invalid IP address.".to_string())?;
    if !showflow_sharing::server::ip_is_candidate(&ip) {
        return Err("That is not a private network address of this PC.".into());
    }
    let port = lk(&state.settings).share_port;
    let mut g = state.sharing.lock().await;
    if let Some(old) = g.take() {
        old.stop();
    }
    let srv = SharingServer::start(ServerConfig {
        lan_ip: parsed,
        port,
        data_dir: state.data_dir.join("sharing"),
    })
    .await?;
    let info = srv.info();
    *g = Some(srv);
    Ok(info)
}

#[tauri::command]
pub async fn sharing_stop(state: State<'_, AppState>) -> CmdResult<()> {
    let mut g = state.sharing.lock().await;
    if let Some(s) = g.take() {
        s.stop();
    }
    Ok(())
}

#[tauri::command]
pub async fn sharing_status(state: State<'_, AppState>) -> CmdResult<Option<SharingStatus>> {
    let g = state.sharing.lock().await;
    Ok(g.as_ref().map(|s| s.status()))
}

#[tauri::command]
pub async fn sharing_info(state: State<'_, AppState>) -> CmdResult<Option<SharingInfo>> {
    let g = state.sharing.lock().await;
    Ok(g.as_ref().map(|s| s.info()))
}

#[tauri::command]
pub async fn sharing_new_code(state: State<'_, AppState>) -> CmdResult<SharingInfo> {
    let g = state.sharing.lock().await;
    let s = g.as_ref().ok_or("Sharing is not running.")?;
    s.regenerate_code();
    Ok(s.info())
}

#[tauri::command]
pub async fn sharing_admin_conn(state: State<'_, AppState>) -> CmdResult<Option<showflow_sharing::AdminConn>> {
    let g = state.sharing.lock().await;
    Ok(g.as_ref().map(|s| s.admin_conn()))
}

/// Accept the pending share: put the speaker's screen on the projector output.
#[tauri::command]
pub async fn route_share(app: AppHandle) -> CmdResult<()> {
    let st = app.state::<AppState>();
    let conn = {
        let g = st.sharing.lock().await;
        g.as_ref().map(|s| s.admin_conn())
    };
    let conn = conn.ok_or("Sharing is not running.")?;
    orch::show_share(&app, conn.ws_url, conn.token)
}

#[tauri::command]
pub fn firewall_help(state: State<'_, AppState>) -> Value {
    let port = lk(&state.settings).share_port;
    json!({
        "port": port,
        "command": format!("netsh advfirewall firewall add rule name=ShowFlow-SpeakerShare dir=in action=allow protocol=TCP localport={port} profile=private"),
    })
}

#[tauri::command]
pub fn add_firewall_rule(state: State<'_, AppState>) -> CmdResult<()> {
    let port = lk(&state.settings).share_port;
    hotspot::add_firewall_rule(port)
}

// ================================================================ hotspot

#[tauri::command]
pub async fn hotspot_control(state: State<'_, AppState>, action: String) -> CmdResult<Value> {
    let dir = state.data_dir.clone();
    tauri::async_runtime::spawn_blocking(move || hotspot::run(&dir, &action))
        .await
        .map_err(|e| e.to_string())?
}

#[tauri::command]
pub fn open_hotspot_settings() -> CmdResult<()> {
    hotspot::open_settings()
}

// ================================================================ diagnostics

#[tauri::command]
pub fn open_logs_folder(state: State<'_, AppState>) -> CmdResult<()> {
    hotspot::open_path(&state.data_dir.join("logs"))
}

#[tauri::command]
pub async fn get_diagnostics(app: AppHandle) -> CmdResult<Value> {
    let st = app.state::<AppState>();
    let ppt = lk(&st.ppt).detect().unwrap_or_else(|e| json!({ "ok": false, "error": e }));
    let sharing = {
        let g = st.sharing.lock().await;
        g.as_ref().map(|s| {
            let mut v = serde_json::to_value(s.status()).unwrap_or(Value::Null);
            if let Some(o) = v.as_object_mut() {
                o.remove("code"); // never put pairing codes in diagnostics
            }
            v
        })
    };
    let out = lk(&st.output).state().clone();
    Ok(json!({
        "app_version": env!("CARGO_PKG_VERSION"),
        "os": std::env::consts::OS,
        "arch": std::env::consts::ARCH,
        "data_dir": st.data_dir.to_string_lossy(),
        "powerpoint": ppt,
        "displays": display::list_displays(&app),
        "interfaces": showflow_sharing::candidate_interfaces(),
        "sharing": sharing,
        "output": out,
    }))
}

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MediaType {
    Presentation,
    Video,
    Image,
}

impl MediaType {
    pub fn as_str(&self) -> &'static str {
        match self {
            MediaType::Presentation => "presentation",
            MediaType::Video => "video",
            MediaType::Image => "image",
        }
    }
    pub fn parse(s: &str) -> Option<MediaType> {
        match s {
            "presentation" => Some(MediaType::Presentation),
            "video" => Some(MediaType::Video),
            "image" => Some(MediaType::Image),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TypeFilter {
    #[default]
    All,
    Presentations,
    Videos,
    Images,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MediaFile {
    pub id: i64,
    pub path: String,
    pub filename: String,
    pub media_type: MediaType,
    pub size_bytes: i64,
    pub duration_ms: Option<i64>,
    pub modified_at: i64,
    pub folder_root: String,
    /// Computed at read time (file still exists on disk).
    pub available: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Playlist {
    pub id: i64,
    pub name: String,
    pub folder_root: Option<String>,
    pub created_at: i64,
    pub updated_at: i64,
    pub item_count: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlaylistItem {
    pub id: i64,
    pub playlist_id: i64,
    pub media_file_id: i64,
    pub position: i64,
    pub auto_advance: bool,
    pub looped: bool,
    pub volume: f64,
    pub start_position_ms: Option<i64>,
    pub image_duration_secs: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlaylistEntry {
    pub item: PlaylistItem,
    pub media: MediaFile,
}

/// Editable per-item options.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ItemOptions {
    pub auto_advance: bool,
    pub looped: bool,
    pub volume: f64,
    pub start_position_ms: Option<i64>,
    pub image_duration_secs: Option<i64>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EndPolicy {
    #[default]
    Wait,
    AutoAdvance,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AfterStop {
    #[default]
    Idle,
    Black,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ImageFit {
    #[default]
    Fit,
    Fill,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub audience_display: Option<String>,
    pub end_policy: EndPolicy,
    pub after_stop: AfterStop,
    pub image_fit: ImageFit,
    pub scan_depth: u32,
    pub default_image_secs: u32,
    pub share_port: u16,
    /// Slide transition duration override for the built-in viewer in ms (0 = use each presentation's own speed).
    pub transition_ms: u32,
    /// "file" = each presentation's own transitions, "none", or a transition id applied to every slide.
    pub transition_style: String,
    /// Built-in viewer: play the presentation's embedded music automatically when it starts.
    /// Built-in viewer: play the animations stored in the presentation (false = show every slide complete).
    /// Which engine shows presentations: "auto" (PowerPoint when installed, else built-in), "powerpoint" or "builtin".
    pub ppt_engine: String,
    pub animations_enabled: bool,
    /// Built-in viewer slide advance: "file" (presentation timings), "off" (operator only) or "custom" (every slide_advance_secs).
    pub slide_advance: String,
    pub slide_advance_secs: u32,
    /// Embedded music volume, 0-100.
    pub music_volume: u32,
    pub music_enabled: bool,
    /// Seconds to wait after the presentation starts before the music begins.
    pub music_delay_s: u32,
    /// Repeat the music until the presentation ends.
    pub music_loop: bool,
    pub last_folder: Option<String>,
    pub last_playlist_id: Option<i64>,
}

impl Default for Settings {
    fn default() -> Self {
        Settings {
            audience_display: None,
            end_policy: EndPolicy::Wait,
            after_stop: AfterStop::Idle,
            image_fit: ImageFit::Fit,
            scan_depth: 1,
            default_image_secs: 10,
            share_port: 8443,
            transition_ms: 0,
            transition_style: "file".to_string(),
            ppt_engine: "auto".to_string(),
            animations_enabled: true,
            slide_advance: "file".to_string(),
            slide_advance_secs: 10,
            music_volume: 100,
            music_enabled: true,
            music_delay_s: 0,
            music_loop: true,
            last_folder: None,
            last_playlist_id: None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum IdleMode {
    #[default]
    None,
    PowerPoint,
    Video,
    Image,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct IdleConfig {
    pub mode: IdleMode,
    pub path: Option<String>,
    pub loop_video: bool,
    pub muted: bool,
    pub auto_after_minutes: Option<u32>,
}

impl Default for IdleConfig {
    fn default() -> Self {
        IdleConfig {
            mode: IdleMode::None,
            path: None,
            loop_video: true,
            muted: true,
            auto_after_minutes: None,
        }
    }
}
